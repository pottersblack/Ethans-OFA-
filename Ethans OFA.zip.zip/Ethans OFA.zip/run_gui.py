"""Wrapper to run GUI with proper error handling."""
import sys
import traceback

# Add src to path
sys.path.insert(0, 'src')

try:
    print("Starting Optical Flow Analyzer GUI...")
    print("Importing modules...")
    
    from ui import OpticalFlowGUI
    
    print("Creating GUI window...")
    app = OpticalFlowGUI()
    
    print("Starting mainloop...")
    app.mainloop()
    
    print("GUI closed normally.")
    
except Exception as e:
    print(f"\n{'='*60}")
    print("ERROR: Failed to start GUI")
    print(f"{'='*60}")
    print(f"Error: {e}")
    print(f"\nFull traceback:")
    traceback.print_exc()
    print(f"{'='*60}")
    input("\nPress Enter to exit...")
    sys.exit(1)
