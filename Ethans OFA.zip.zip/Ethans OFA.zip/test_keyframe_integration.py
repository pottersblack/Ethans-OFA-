#!/usr/bin/env python
"""
Comprehensive integration test for Key Frame Capture feature.
Run: python test_keyframe_integration.py
"""
import sys
sys.path.insert(0, 'src')

import numpy as np
from pathlib import Path

# Import all key frame modules
from pipeline.keyframe_capture import KeyFrameCapture, FrameScore
from pipeline.keyframe_extract import extract_keyframes_to_dir, create_keyframe_grid
from main import _parse_args, _build_pipeline, process_capture

def test_keyframe_capture():
    print('=' * 60)
    print('KEY FRAME CAPTURE - FULL INTEGRATION TEST')
    print('=' * 60)

    # Test 1: KeyFrameCapture initialization
    print('\n✓ Test 1: KeyFrameCapture initialization')
    kfc = KeyFrameCapture(num_frames=10)
    print(f'  - Created with 10 frames')
    print(f'  - Weights: flow={kfc.weights["flow"]}, particles={kfc.weights["particles"]}')

    # Test 2: Frame scoring
    print('\n✓ Test 2: Frame scoring with multiple metrics')
    for i in range(15):
        flow_uv = np.random.randn(100, 100, 2) * (i * 0.15 + 0.5)
        vorticity = np.random.randn(100, 100) * (i * 0.05)
        score = kfc.score_frame(
            frame_index=i,
            flow_uv=flow_uv,
            particle_count=max(0, i - 3),
            vorticity=vorticity,
        )
        if i % 5 == 0:
            print(f'  - Frame {i}: score={score.score:.4f}, particles={score.particle_count}')

    # Test 3: Top frame selection
    print('\n✓ Test 3: Top frame selection')
    top_frames = kfc.get_top_frames()
    print(f'  - Selected {len(top_frames)} top frames')
    print(f'  - Best frame: #{top_frames[0].frame_index} (score={top_frames[0].score:.4f})')
    print(f'  - Worst frame: #{top_frames[-1].frame_index} (score={top_frames[-1].score:.4f})')

    # Test 4: Report generation
    print('\n✓ Test 4: Report generation')
    report = kfc.report()
    lines = report.split('\n')
    print(f'  - Generated report with {len(lines)} lines')
    print(f'  - First line: {lines[0]}')

    # Test 5: Frame indices extraction
    print('\n✓ Test 5: Frame indices extraction')
    indices = kfc.get_top_frame_indices()
    print(f'  - Extracted indices: {indices}')
    print(f'  - All indices are integers: {all(isinstance(i, int) for i in indices)}')

    # Test 6: FrameScore dataclass
    print('\n✓ Test 6: FrameScore dataclass')
    fs = FrameScore(
        frame_index=5,
        score=0.85,
        flow_magnitude=2.5,
        particle_count=10,
        vorticity_energy=0.15,
        divergence_energy=0.12,
        description='test'
    )
    print(f'  - Created FrameScore: frame={fs.frame_index}, score={fs.score}')

    # Test 7: Grid creation
    print('\n✓ Test 7: Grid creation')
    test_frames = {}
    for i in range(5):
        test_frames[i] = np.random.randint(0, 256, (128, 128, 3), dtype=np.uint8)
    grid = create_keyframe_grid(test_frames, grid_shape=(1, 5), tile_size=(128, 128))
    print(f'  - Created grid shape: {grid.shape}')
    print(f'  - Expected: (128, 640, 3) = 1 row × 5 cols of 128×128 tiles')
    assert grid.shape == (128, 640, 3), 'Grid shape mismatch!'

    # Test 8: Custom weights
    print('\n✓ Test 8: Custom scoring weights')
    custom_weights = {'flow': 0.5, 'particles': 0.3, 'vorticity': 0.15, 'divergence': 0.05}
    kfc_custom = KeyFrameCapture(num_frames=5, score_weights=custom_weights)
    print(f'  - Created with custom weights')
    print(f'  - Flow weight: {kfc_custom.weights["flow"]}')

    # Test 9: Multi-metric bonus detection
    print('\n✓ Test 9: Multi-metric bonus detection')
    kfc_bonus = KeyFrameCapture(num_frames=10)
    # High-value frame
    high_flow = np.ones((100, 100, 2)) * 3.0  # > 1.0
    high_vorticity = np.ones((100, 100)) * 0.2  # > 0.1
    high_divergence = np.ones((100, 100)) * 0.15  # > 0.1
    score_high = kfc_bonus.score_frame(
        frame_index=0,
        flow_uv=high_flow,
        particle_count=20,  # > 5
        vorticity=high_vorticity,
        divergence=high_divergence
    )
    # Low-value frame
    low_flow = np.ones((100, 100, 2)) * 0.1
    score_low = kfc_bonus.score_frame(
        frame_index=1,
        flow_uv=low_flow,
    )
    print(f'  - High-metric frame (4 high): score={score_high.score:.4f}')
    print(f'  - Low-metric frame: score={score_low.score:.4f}')
    print(f'  - High score > Low score: {score_high.score > score_low.score}')

    # Test 10: Report saving
    print('\n✓ Test 10: Report saving')
    test_report_path = Path('test_keyframes_report.txt')
    kfc.save_report(str(test_report_path))
    if test_report_path.exists():
        size = test_report_path.stat().st_size
        print(f'  - Report saved: {test_report_path} ({size} bytes)')
        test_report_path.unlink()  # Clean up
    else:
        print('  - Report save failed!')
        return False

    print('\n' + '=' * 60)
    print('✓ ALL TESTS PASSED - KEY FRAME CAPTURE READY FOR USE')
    print('=' * 60)
    return True


if __name__ == '__main__':
    success = test_keyframe_capture()
    sys.exit(0 if success else 1)
