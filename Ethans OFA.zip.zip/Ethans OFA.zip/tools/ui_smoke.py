import sys
try:
    from ui import OpticalFlowGUI
    app = OpticalFlowGUI()
    app.update()
    app.destroy()
    print('UI_SMOKE_OK')
except Exception as e:
    import traceback
    print('UI_SMOKE_FAIL', type(e).__name__)
    traceback.print_exc()
    sys.exit(2)
