"""Tests for key frame capture functionality."""
import pytest
import numpy as np
from pathlib import Path
from pipeline.keyframe_capture import KeyFrameCapture, FrameScore
from pipeline.keyframe_extract import extract_keyframes_to_dir, create_keyframe_grid


class TestKeyFrameCapture:
    """Test KeyFrameCapture class."""

    def test_initialization(self):
        """Test KeyFrameCapture initialization."""
        kfc = KeyFrameCapture(num_frames=10)
        assert kfc.num_frames == 10
        assert len(kfc.frame_scores) == 0
        assert kfc.weights['flow'] == 0.25

    def test_custom_weights(self):
        """Test custom weight configuration."""
        weights = {'flow': 0.5, 'particles': 0.3, 'vorticity': 0.1, 'divergence': 0.1}
        kfc = KeyFrameCapture(num_frames=5, score_weights=weights)
        assert kfc.weights == weights

    def test_score_frame_with_flow(self):
        """Test scoring a frame with optical flow."""
        kfc = KeyFrameCapture(num_frames=10)
        
        # Create dummy flow
        flow_uv = np.random.randn(100, 100, 2) * 2.0
        
        score = kfc.score_frame(
            frame_index=0,
            flow_uv=flow_uv,
            particle_count=5,
        )
        
        assert score.frame_index == 0
        assert score.score > 0
        assert score.flow_magnitude > 0
        assert score.particle_count == 5
        assert len(kfc.frame_scores) == 1

    def test_score_frame_with_vorticity(self):
        """Test scoring a frame with vorticity."""
        kfc = KeyFrameCapture(num_frames=10)
        
        vorticity = np.random.randn(100, 100) * 0.5
        
        score = kfc.score_frame(
            frame_index=1,
            vorticity=vorticity,
        )
        
        assert score.vorticity_energy > 0
        assert score.score > 0

    def test_score_frame_with_divergence(self):
        """Test scoring a frame with divergence."""
        kfc = KeyFrameCapture(num_frames=10)
        
        divergence = np.random.randn(100, 100) * 0.3
        
        score = kfc.score_frame(
            frame_index=2,
            divergence=divergence,
        )
        
        assert score.divergence_energy > 0

    def test_get_top_frames(self):
        """Test retrieving top N frames."""
        kfc = KeyFrameCapture(num_frames=3)
        
        # Score 10 frames with varying quality
        for i in range(10):
            flow_uv = np.ones((100, 100, 2)) * (i * 0.1)
            kfc.score_frame(
                frame_index=i,
                flow_uv=flow_uv,
                particle_count=i,
            )
        
        top_frames = kfc.get_top_frames()
        assert len(top_frames) == 3
        # Top frame should have highest score
        assert top_frames[0].score >= top_frames[1].score >= top_frames[2].score

    def test_get_top_frame_indices(self):
        """Test getting frame indices of top frames."""
        kfc = KeyFrameCapture(num_frames=5)
        
        for i in range(20):
            flow_uv = np.ones((100, 100, 2)) * (i * 0.05)
            kfc.score_frame(frame_index=i, flow_uv=flow_uv)
        
        indices = kfc.get_top_frame_indices()
        assert len(indices) == 5
        assert all(isinstance(idx, int) for idx in indices)

    def test_report_generation(self):
        """Test report generation."""
        kfc = KeyFrameCapture(num_frames=3)
        
        for i in range(5):
            flow_uv = np.ones((100, 100, 2)) * (i * 0.1)
            kfc.score_frame(frame_index=i, flow_uv=flow_uv, particle_count=i)
        
        report = kfc.report()
        assert "Top 3 Key Frames" in report
        assert "Frame" in report
        assert "Score" in report

    def test_multi_metric_boost(self):
        """Test that frames with multiple high-value metrics get boosted."""
        kfc = KeyFrameCapture(num_frames=10)
        
        # Frame with all metrics
        flow_uv = np.ones((100, 100, 2)) * 2.0
        vorticity = np.ones((100, 100)) * 0.2
        divergence = np.ones((100, 100)) * 0.2
        
        score_multi = kfc.score_frame(
            frame_index=0,
            flow_uv=flow_uv,
            vorticity=vorticity,
            divergence=divergence,
            particle_count=10,
        )
        
        # Frame with only flow
        kfc2 = KeyFrameCapture(num_frames=10)
        score_single = kfc2.score_frame(
            frame_index=0,
            flow_uv=flow_uv,
        )
        
        # Multi-metric should have higher boost
        assert score_multi.score > score_single.score


class TestFrameScore:
    """Test FrameScore dataclass."""

    def test_creation(self):
        """Test FrameScore creation."""
        fs = FrameScore(
            frame_index=5,
            score=0.85,
            flow_magnitude=2.5,
            particle_count=10,
            vorticity_energy=0.15,
            divergence_energy=0.10,
            description="test frame",
        )
        
        assert fs.frame_index == 5
        assert fs.score == 0.85
        assert fs.flow_magnitude == 2.5


class TestKeyFrameGridCreation:
    """Test key frame grid creation."""

    def test_create_grid_basic(self):
        """Test creating a basic grid."""
        frames = {}
        for i in range(10):
            frame = np.random.randint(0, 256, (480, 640, 3), dtype=np.uint8)
            frames[i] = frame
        
        grid = create_keyframe_grid(frames, grid_shape=(2, 5), tile_size=(256, 256))
        
        assert grid.shape == (512, 1280, 3)  # 2 rows x 5 cols of 256x256 tiles

    def test_grid_with_fewer_frames(self):
        """Test grid creation with fewer frames than grid size."""
        frames = {}
        for i in range(3):
            frame = np.random.randint(0, 256, (480, 640, 3), dtype=np.uint8)
            frames[i] = frame
        
        grid = create_keyframe_grid(frames, grid_shape=(2, 5), tile_size=(256, 256))
        
        # Should still create a 2x5 grid, with some tiles empty
        assert grid.shape == (512, 1280, 3)
