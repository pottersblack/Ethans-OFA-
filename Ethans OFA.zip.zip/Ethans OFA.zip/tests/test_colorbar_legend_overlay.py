import numpy as np
from pipeline.channels import ChannelStore
from pipeline.types import RunConfig, ChannelName
from plugins.overlays.colorbar_legend import ColorbarLegendOverlay

def test_colorbar_legend_overlay():
    # Synthetic frame
    frame = np.zeros((64, 128, 3), dtype=np.uint8)
    channels = ChannelStore.empty().with_channel(ChannelName("frame"), frame)
    overlay = ColorbarLegendOverlay(position="bottomright")
    config = RunConfig(mode="preview", scenario="smoke_airflow")
    out_channels = overlay.run(frame_index=0, channels=channels, config=config)
    out_frame = out_channels.get(ChannelName("frame"))
    assert out_frame.shape == frame.shape
    assert np.any(out_frame != frame), "Overlay should modify the frame"
    print("ColorbarLegendOverlay test passed.")

if __name__ == "__main__":
    test_colorbar_legend_overlay()
