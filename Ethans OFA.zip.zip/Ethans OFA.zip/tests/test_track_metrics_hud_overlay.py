import numpy as np
from pipeline.channels import ChannelStore
from pipeline.types import RunConfig, ChannelName
from plugins.overlays.track_metrics_hud import TrackMetricsHUDOverlay

def test_track_metrics_hud_overlay():
    # Synthetic frame and tracks
    frame = np.zeros((64, 64, 3), dtype=np.uint8)
    tracks = [
        {"id": 1, "pts": [(10,10), (20,20), (30,30)]},
        {"id": 2, "pts": [(50,10), (40,20), (30,30)]},
    ]
    channels = ChannelStore.empty().with_channel(ChannelName("frame"), frame).with_channel(ChannelName("tracks"), tracks)
    overlay = TrackMetricsHUDOverlay()
    config = RunConfig(mode="preview", scenario="smoke_airflow")
    out_channels = overlay.run(frame_index=0, channels=channels, config=config)
    out_frame = out_channels.get(ChannelName("frame"))
    assert out_frame.shape == frame.shape
    assert np.any(out_frame != frame), "Overlay should modify the frame"

if __name__ == "__main__":
    test_track_metrics_hud_overlay()
    print("TrackMetricsHUDOverlay test passed.")
