"""Tests for Detection Silhouette Panel overlay."""
import numpy as np
import cv2
from plugins.overlays.detection_silhouette_panel import DetectionSilhouettePanelOverlay
from pipeline.types import RunConfig, Mode, Scenario, ChannelName
from pipeline.channels import ChannelStore


def test_detection_silhouette_panel_basic():
    """Test that panel is created and combined with frame."""
    frame = np.ones((100, 100, 3), dtype=np.uint8) * 128
    
    channels = ChannelStore.empty().with_channel(ChannelName("frame"), frame)
    config = RunConfig(mode=Mode.PREVIEW, scenario=Scenario.BUBBLES)
    
    overlay = DetectionSilhouettePanelOverlay(panel_position="right", panel_width_ratio=0.3)
    result = overlay.run(frame_index=0, channels=channels, config=config)
    out = result.get(ChannelName("frame"))
    
    # Output should be wider than input (frame + panel)
    assert out.shape[0] == frame.shape[0]  # Same height
    assert out.shape[1] > frame.shape[1]   # Wider (frame + panel)


def test_detection_silhouette_with_tracks():
    """Test that tracks are drawn on panel."""
    frame = np.ones((100, 100, 3), dtype=np.uint8) * 128
    tracks = [
        {"id": 1, "pts": [(30, 40), (32, 41), (34, 42)]},
        {"id": 2, "pts": [(60, 70), (62, 71)]}
    ]
    
    channels = (ChannelStore.empty()
                .with_channel(ChannelName("frame"), frame)
                .with_channel(ChannelName("tracks"), tracks))
    config = RunConfig(mode=Mode.PREVIEW, scenario=Scenario.PARTICLES)
    
    overlay = DetectionSilhouettePanelOverlay(colored=True, style="filled")
    result = overlay.run(frame_index=0, channels=channels, config=config)
    out = result.get(ChannelName("frame"))
    
    # Panel should be added
    assert out.shape[1] > frame.shape[1]


def test_detection_silhouette_with_flow():
    """Test that flow-based detections work."""
    frame = np.ones((100, 100, 3), dtype=np.uint8) * 128
    flow = np.random.randn(100, 100, 2).astype(np.float32) * 0.5
    # Add some high-magnitude regions
    flow[20:30, 20:30] = 5.0
    
    channels = (ChannelStore.empty()
                .with_channel(ChannelName("frame"), frame)
                .with_channel(ChannelName("flow_uv"), flow))
    config = RunConfig(mode=Mode.PREVIEW, scenario=Scenario.SMOKE_AIRFLOW)
    
    overlay = DetectionSilhouettePanelOverlay(panel_position="left", background="black")
    result = overlay.run(frame_index=0, channels=channels, config=config)
    out = result.get(ChannelName("frame"))
    
    assert out.shape[1] > frame.shape[1]


def test_detection_silhouette_position_variants():
    """Test left and right panel positions."""
    frame = np.ones((100, 100, 3), dtype=np.uint8) * 128
    channels = ChannelStore.empty().with_channel(ChannelName("frame"), frame)
    config = RunConfig(mode=Mode.PREVIEW, scenario=Scenario.BUBBLES)
    
    # Test right position
    overlay_right = DetectionSilhouettePanelOverlay(panel_position="right")
    result_right = overlay_right.run(frame_index=0, channels=channels, config=config)
    out_right = result_right.get(ChannelName("frame"))
    
    # Test left position
    overlay_left = DetectionSilhouettePanelOverlay(panel_position="left")
    result_left = overlay_left.run(frame_index=0, channels=channels, config=config)
    out_left = result_left.get(ChannelName("frame"))
    
    # Both should produce wider output
    assert out_right.shape[1] > frame.shape[1]
    assert out_left.shape[1] > frame.shape[1]
    assert out_right.shape == out_left.shape
