import numpy as np
from pipeline.channels import ChannelStore
from pipeline.types import RunConfig
from plugins.overlays.region_mask import RegionMaskOverlay

def test_region_mask_overlay():
    # Synthetic frame and region mask
    frame = np.zeros((64, 64, 3), dtype=np.uint8)
    mask = np.zeros((64, 64), dtype=np.int32)
    mask[16:48, 16:48] = 1  # region 1
    mask[0:16, :] = 2       # region 2
    mask[:, 48:64] = 3      # region 3
    channels = ChannelStore.empty().with_channel("frame", frame).with_channel("region_mask", mask)
    overlay = RegionMaskOverlay()
    config = RunConfig(mode="preview", scenario="smoke_airflow")
    out_channels = overlay.run(frame_index=0, channels=channels, config=config)
    out_frame = out_channels.get("frame")
    assert out_frame.shape == frame.shape
    assert np.any(out_frame != frame), "Overlay should modify the frame"

if __name__ == "__main__":
    test_region_mask_overlay()
    print("RegionMaskOverlay test passed.")
