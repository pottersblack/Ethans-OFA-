import numpy as np
import cv2
from plugins.overlays.error_warning_overlay import ErrorWarningOverlay
from pipeline.types import RunConfig, Mode, Scenario, ChannelName
from pipeline.channels import ChannelStore


def test_error_warning_overlay_mask():
    """Test that error mask regions are highlighted."""
    frame = np.ones((100, 100, 3), dtype=np.uint8) * 200
    error_mask = np.zeros((100, 100), dtype=np.uint8)
    error_mask[20:40, 20:40] = 1
    
    channels = (ChannelStore.empty()
                .with_channel(ChannelName("frame"), frame)
                .with_channel(ChannelName("error_mask"), error_mask))
    config = RunConfig(mode=Mode.PREVIEW, scenario=Scenario.SMOKE_AIRFLOW)
    
    overlay = ErrorWarningOverlay(opacity=0.5)
    result = overlay.run(frame_index=0, channels=channels, config=config)
    out = result.get(ChannelName("frame"))
    
    assert out.shape == frame.shape
    assert (out[30, 30] != frame[30, 30]).any()  # Should be red-tinted


def test_error_warning_overlay_icon():
    """Test that error list icons are drawn."""
    frame = np.ones((100, 100, 3), dtype=np.uint8) * 200
    error_list = [{"xy": (50, 50)}]
    
    channels = (ChannelStore.empty()
                .with_channel(ChannelName("frame"), frame)
                .with_channel(ChannelName("error_list"), error_list))
    config = RunConfig(mode=Mode.PREVIEW, scenario=Scenario.SMOKE_AIRFLOW)
    
    overlay = ErrorWarningOverlay(opacity=0.7)
    result = overlay.run(frame_index=0, channels=channels, config=config)
    out = result.get(ChannelName("frame"))
    
    assert out.shape == frame.shape
    # Should have orange circle at (50, 50)
    assert (out[50, 50] != frame[50, 50]).any()
