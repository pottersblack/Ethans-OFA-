import numpy as np
from pipeline.channels import ChannelStore
from pipeline.types import RunConfig, ChannelName
from plugins.overlays.temporal_motion_heatmap import TemporalMotionHeatmapOverlay

def test_temporal_motion_heatmap_overlay():
    # Synthetic frame and flow, simulate 3 frames
    frame = np.zeros((64, 64, 3), dtype=np.uint8)
    overlay = TemporalMotionHeatmapOverlay(opacity=0.6)
    config = RunConfig(mode="preview", scenario="smoke_airflow")
    for i in range(3):
        flow = np.ones((64, 64, 2), dtype=np.float32) * (i+1)
        channels = ChannelStore.empty().with_channel(ChannelName("frame"), frame).with_channel(ChannelName("flow_uv"), flow)
        out_channels = overlay.run(frame_index=i, channels=channels, config=config)
        out_frame = out_channels.get(ChannelName("frame"))
        assert out_frame.shape == frame.shape
    print("TemporalMotionHeatmapOverlay test passed.")

if __name__ == "__main__":
    test_temporal_motion_heatmap_overlay()
