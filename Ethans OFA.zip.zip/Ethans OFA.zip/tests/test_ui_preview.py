"""
Test that the UI overlay application works correctly.
These tests verify the overlay pipeline integration without starting the GUI.
"""
from pipeline.types import RunConfig, Mode, Scenario, ChannelName
from pipeline.channels import ChannelStore
from plugins.flow import FarnebackFlowPlugin
import numpy as np


def test_flow_plugin_produces_flow_uv():
    """Verify that FarnebackFlowPlugin produces flow_uv channel."""
    # Create minimal test frames
    h, w = 64, 64
    prev_frame = np.zeros((h, w, 3), dtype=np.uint8)
    frame = np.zeros((h, w, 3), dtype=np.uint8)
    # Add some motion - a white square that moved
    prev_frame[20:30, 20:30] = 255
    frame[22:32, 22:32] = 255

    channels = (ChannelStore.empty()
                .with_channel(ChannelName("prev_frame"), prev_frame)
                .with_channel(ChannelName("frame"), frame))

    config = RunConfig(mode=Mode.PREVIEW, scenario=Scenario.SMOKE_AIRFLOW)
    plugin = FarnebackFlowPlugin()
    result = plugin.run(frame_index=1, channels=channels, config=config)

    # Flow plugin must produce flow_uv channel
    assert result.has(ChannelName("flow_uv"))
    flow = result.get(ChannelName("flow_uv"))
    assert flow is not None
    assert flow.shape == (h, w, 2)


def test_channels_preserved_through_overlay():
    """Verify overlay processing preserves frame channel."""
    from plugins.overlays.flow_magnitude_heatmap import FlowMagnitudeHeatmapOverlay
    
    h, w = 64, 64
    frame = np.zeros((h, w, 3), dtype=np.uint8)
    flow_uv = np.zeros((h, w, 2), dtype=np.float32)
    
    channels = (ChannelStore.empty()
                .with_channel(ChannelName("frame"), frame)
                .with_channel(ChannelName("flow_uv"), flow_uv))
    
    config = RunConfig(mode=Mode.PREVIEW, scenario=Scenario.SMOKE_AIRFLOW)
    overlay = FlowMagnitudeHeatmapOverlay()
    result = overlay.run(frame_index=1, channels=channels, config=config)
    
    # Result must have frame channel
    assert result.has(ChannelName("frame"))
    out_frame = result.get(ChannelName("frame"))
    assert out_frame.shape == (h, w, 3)
