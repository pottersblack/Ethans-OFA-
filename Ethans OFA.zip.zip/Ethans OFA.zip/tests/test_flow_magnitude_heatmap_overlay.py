import numpy as np
from pipeline.channels import ChannelStore
from pipeline.types import RunConfig
from plugins.overlays.flow_magnitude_heatmap import FlowMagnitudeHeatmapOverlay

def test_flow_magnitude_heatmap_overlay():
    # Create synthetic frame and flow
    frame = np.zeros((64, 64, 3), dtype=np.uint8)
    flow = np.zeros((64, 64, 2), dtype=np.float32)
    flow[..., 0] = np.linspace(0, 10, 64)[None, :]
    flow[..., 1] = np.linspace(0, 10, 64)[:, None]
    channels = ChannelStore.empty().with_channel("frame", frame).with_channel("flow_uv", flow)
    overlay = FlowMagnitudeHeatmapOverlay()
    config = RunConfig(mode="preview", scenario="smoke_airflow")
    out_channels = overlay.run(frame_index=0, channels=channels, config=config)
    out_frame = out_channels.get("frame")
    assert out_frame.shape == frame.shape
    assert np.any(out_frame != frame), "Overlay should modify the frame"

if __name__ == "__main__":
    test_flow_magnitude_heatmap_overlay()
    print("FlowMagnitudeHeatmapOverlay test passed.")
