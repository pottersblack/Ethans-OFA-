from plugins.overlays.detection_cache import get_global_cache, set_global_cache, DetectionCache


def test_global_cache_set_get_clear():
    set_global_cache(None)
    assert get_global_cache() is None
    c = DetectionCache(max_bytes=1024)
    set_global_cache(c)
    assert get_global_cache() is c
    set_global_cache(None)
    assert get_global_cache() is None
