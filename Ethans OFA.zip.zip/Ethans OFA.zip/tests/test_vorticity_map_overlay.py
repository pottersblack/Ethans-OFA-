import numpy as np
from pipeline.channels import ChannelStore
from pipeline.types import RunConfig
from plugins.overlays.vorticity_map import VorticityMapOverlay

def test_vorticity_map_overlay():
    # Synthetic frame and flow: vertical shear
    frame = np.zeros((64, 64, 3), dtype=np.uint8)
    flow = np.zeros((64, 64, 2), dtype=np.float32)
    flow[..., 0] = np.linspace(-5, 5, 64)[None, :]  # horizontal gradient
    flow[..., 1] = 0.0
    channels = ChannelStore.empty().with_channel("frame", frame).with_channel("flow_uv", flow)
    overlay = VorticityMapOverlay()
    config = RunConfig(mode="preview", scenario="smoke_airflow")
    out_channels = overlay.run(frame_index=0, channels=channels, config=config)
    out_frame = out_channels.get("frame")
    assert out_frame.shape == frame.shape
    assert np.any(out_frame != frame), "Overlay should modify the frame"

if __name__ == "__main__":
    test_vorticity_map_overlay()
    print("VorticityMapOverlay test passed.")
