import numpy as np
from pipeline.channels import ChannelStore
from pipeline.types import RunConfig, ChannelName
from plugins.overlays.histogram_overlay import HistogramOverlayOverlay

def test_histogram_overlay():
    # Synthetic frame and flow
    frame = np.zeros((64, 64, 3), dtype=np.uint8)
    flow = np.ones((64, 64, 2), dtype=np.float32) * 2
    channels = ChannelStore.empty().with_channel(ChannelName("frame"), frame).with_channel(ChannelName("flow_uv"), flow)
    overlay = HistogramOverlayOverlay(opacity=0.7)
    config = RunConfig(mode="preview", scenario="smoke_airflow")
    out_channels = overlay.run(frame_index=0, channels=channels, config=config)
    out_frame = out_channels.get(ChannelName("frame"))
    assert out_frame.shape == frame.shape
    assert np.any(out_frame != frame), "Overlay should modify the frame"
    print("HistogramOverlayOverlay test passed.")

if __name__ == "__main__":
    test_histogram_overlay()
