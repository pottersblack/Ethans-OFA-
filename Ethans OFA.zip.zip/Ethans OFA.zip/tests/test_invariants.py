from __future__ import annotations

import os

import pytest

from pipeline.channels import ChannelStore
from pipeline.core import Pipeline
from pipeline.types import RunConfig, Mode, Scenario, ChannelName
from pipeline import gpu


def test_channelstore_returns_new_instances():
    cs = ChannelStore.empty().with_channel(ChannelName("a"), 1)
    cs2 = cs.with_channel(ChannelName("b"), 2)
    # original should remain unchanged
    assert cs.has(ChannelName("a"))
    assert not cs.has(ChannelName("b"))
    # new store should contain both
    assert cs2.has(ChannelName("a")) and cs2.has(ChannelName("b"))


def test_preview_downgrade_is_applied_to_plugins():
    class TestPlugin:
        id = "test.plugin"
        required_channels = (ChannelName("frame"),)

        def preview_downgrade(self, config: RunConfig) -> RunConfig:
            # Produce a distinguishing value so test can detect downgrade
            return RunConfig(mode=config.mode, scenario=config.scenario, device=config.device, preview_downscale=0.25)

        def export_requirements(self, config: RunConfig):
            return ()

        def run(self, *, frame_index: int, channels: ChannelStore, config: RunConfig) -> ChannelStore:
            # Assert that when Pipeline invoked in PREVIEW mode, plugin receives downgraded config
            assert config.preview_downscale == 0.25
            return channels.with_channel(ChannelName("ok"), True)

    plugin = TestPlugin()
    pipeline = Pipeline(plugins=[plugin])
    initial = ChannelStore.empty().with_channel(ChannelName("frame"), object())
    cfg = RunConfig(mode=Mode.PREVIEW, scenario=Scenario.SMOKE_AIRFLOW)
    res = pipeline.run_frame(frame_index=0, initial_channels=initial, config=cfg)
    assert res.channels.has(ChannelName("ok"))


def test_check_gpu_respects_skip_env(monkeypatch):
    monkeypatch.setenv("SKIP_REAL_HW_PROBE", "1")
    info = gpu.check_gpu()
    # If CI requested skipping probes, gpu.check_gpu should record that it skipped
    assert info.get("nvidia_smi") == "skipped"


def test_pipeline_lifecycle_ordering():
    calls: list[str] = []

    class LifecyclePlugin:
        id = "test.lifecycle"
        required_channels = (ChannelName("frame"),)

        def export_requirements(self, config: RunConfig):
            calls.append("export_requirements")
            return ()

        def preview_downgrade(self, config: RunConfig) -> RunConfig:
            calls.append("preview_downgrade")
            return config

        def run(self, *, frame_index: int, channels: ChannelStore, config: RunConfig) -> ChannelStore:
            calls.append("run")
            return channels.with_channel(ChannelName("ok"), True)

    pipeline = Pipeline(plugins=[LifecyclePlugin()])
    initial = ChannelStore.empty().with_channel(ChannelName("frame"), object())
    cfg = RunConfig(mode=Mode.PREVIEW, scenario=Scenario.SMOKE_AIRFLOW)
    res = pipeline.run_frame(frame_index=0, initial_channels=initial, config=cfg)
    assert res.channels.has(ChannelName("ok"))
    assert calls == ["export_requirements", "preview_downgrade", "run"]


def test_export_mode_requires_flow_uv():
    FLOW_UV = ChannelName("flow_uv")

    class ExportFlowChecker:
        id = "test.export_check"
        required_channels = []

        def export_requirements(self, config: RunConfig):
            if config.mode == Mode.EXPORT:
                return ["flow_uv"]
            return []

        def preview_downgrade(self, config: RunConfig):
            return config

        def run(self, *, frame_index: int, channels: ChannelStore, config: RunConfig) -> ChannelStore:
            if config.mode == Mode.EXPORT:
                assert channels.has(FLOW_UV), "Export mode requires flow_uv channel"
            return channels

    pipeline = Pipeline(plugins=[ExportFlowChecker()])
    initial = ChannelStore.empty()

    # In EXPORT mode, missing flow_uv should raise an AssertionError from the checker
    with pytest.raises(AssertionError):
        pipeline.run_frame(frame_index=0, initial_channels=initial, config=RunConfig(mode=Mode.EXPORT, scenario=Scenario.SMOKE_AIRFLOW))

    # In PREVIEW mode, missing flow_uv is allowed
    pipeline.run_frame(frame_index=0, initial_channels=initial, config=RunConfig(mode=Mode.PREVIEW, scenario=Scenario.SMOKE_AIRFLOW))
