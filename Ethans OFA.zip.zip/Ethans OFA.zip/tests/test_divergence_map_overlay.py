import numpy as np
from pipeline.channels import ChannelStore
from pipeline.types import RunConfig
from plugins.overlays.divergence_map import DivergenceMapOverlay

def test_divergence_map_overlay():
    # Synthetic frame and flow: expansion
    frame = np.zeros((64, 64, 3), dtype=np.uint8)
    flow = np.zeros((64, 64, 2), dtype=np.float32)
    flow[..., 0] = np.linspace(0, 5, 64)[None, :]  # horizontal expansion
    flow[..., 1] = np.linspace(0, 5, 64)[:, None]  # vertical expansion
    channels = ChannelStore.empty().with_channel("frame", frame).with_channel("flow_uv", flow)
    overlay = DivergenceMapOverlay()
    config = RunConfig(mode="preview", scenario="smoke_airflow")
    out_channels = overlay.run(frame_index=0, channels=channels, config=config)
    out_frame = out_channels.get("frame")
    assert out_frame.shape == frame.shape
    assert np.any(out_frame != frame), "Overlay should modify the frame"

if __name__ == "__main__":
    test_divergence_map_overlay()
    print("DivergenceMapOverlay test passed.")
