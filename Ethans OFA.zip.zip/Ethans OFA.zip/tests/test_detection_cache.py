import threading
import time
import numpy as np

from plugins.overlays.detection_cache import DetectionCache


def test_set_get_basic():
    c = DetectionCache(max_bytes=1024 * 1024)
    arr = np.zeros((64, 64), dtype=np.uint8)
    c.set("a", arr)
    out = c.get("a")
    assert out is not None
    assert isinstance(out, np.ndarray)
    assert out.shape == arr.shape


def test_lru_eviction_by_size():
    # tiny budget so only last entry remains
    c = DetectionCache(max_bytes=3000)
    a = np.zeros((50, 50), dtype=np.uint8)  # 2500 bytes
    b = np.zeros((50, 50), dtype=np.uint8)
    c.set("a", a)
    c.set("b", b)
    # total > budget -> eviction should have removed oldest ("a")
    assert c.get("a") is None
    assert c.get("b") is not None


def test_get_or_compute_concurrency():
    c = DetectionCache(max_bytes=1024 * 1024)
    counter = {"calls": 0}

    def compute():
        counter["calls"] += 1
        time.sleep(0.1)
        return "done"

    results = []

    def worker():
        res = c.get_or_compute("k", compute)
        results.append(res)

    threads = [threading.Thread(target=worker) for _ in range(6)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert all(r == "done" for r in results)
    # compute should have been called exactly once
    assert counter["calls"] == 1


def test_invalidate_and_clear():
    c = DetectionCache(max_bytes=1024 * 1024)
    c.set("x:1", 123)
    c.set("x:2", 456)
    c.invalidate("x:")
    assert c.get("x:1") is None
    assert c.get("x:2") is None
    c.set("y", 1)
    c.clear()
    assert c.get("y") is None
