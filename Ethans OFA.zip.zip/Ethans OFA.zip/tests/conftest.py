import sys
from pathlib import Path

# Ensure repository root is on sys.path so tests can import the local `src` package
# (tests import using `src.*`, so adding the repo root allows Python to find the `src` package)
# Add both repository root and `src/` to sys.path so tests can import either
# - `from src.plugins...` requires the repo root on sys.path
# - `from pipeline...` requires `src/` on sys.path
ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "src"
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(SRC))
