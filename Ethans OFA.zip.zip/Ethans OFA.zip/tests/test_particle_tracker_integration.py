import numpy as np
from pipeline.channels import ChannelStore
from pipeline.types import RunConfig, ChannelName
from plugins.particle_tracker import ParticleTrackerPlugin
from plugins.overlays.particle_bubble_tracking import ParticleBubbleTrackingOverlay


def test_particle_tracker_basic_tracking():
    # Create plugin with small history and kalman enabled
    plugin = ParticleTrackerPlugin(max_history=8, max_dist=16.0, use_kalman=True)
    # synthetic frames: a single bright dot moving to the right
    h, w = 64, 64
    positions = [(10 + i*3, 20) for i in range(5)]
    tracks_out = None
    for idx, pos in enumerate(positions):
        frame = np.zeros((h, w, 3), dtype=np.uint8)
        cv2 = __import__("cv2")
        cv2.circle(frame, (int(pos[0]), int(pos[1])), 3, (255, 255, 255), -1)
        channels = ChannelStore.empty().with_channel(ChannelName("frame"), frame)
        out = plugin.run(frame_index=idx, channels=channels, config=RunConfig(mode="preview", scenario="smoke_airflow"))
        assert out is not None
        if out.has(ChannelName("tracks")):
            tracks_out = out.get(ChannelName("tracks"))

    assert tracks_out is not None and len(tracks_out) > 0
    # ensure each track has at least 1 point
    for t in tracks_out:
        assert isinstance(t.get("id"), int)
        assert isinstance(t.get("pts"), list) and len(t.get("pts")) >= 1


def test_tracker_with_overlay_integration():
    # ensure overlay consumes tracks emitted by plugin and modifies frame
    plugin = ParticleTrackerPlugin(max_history=8, max_dist=16.0, use_kalman=False)
    overlay = ParticleBubbleTrackingOverlay(opacity=0.6)
    h, w = 64, 64
    # Make two frames with two dots
    frame0 = np.zeros((h, w, 3), dtype=np.uint8)
    frame1 = np.zeros((h, w, 3), dtype=np.uint8)
    cv2 = __import__("cv2")
    cv2.circle(frame0, (15, 20), 3, (255, 255, 255), -1)
    cv2.circle(frame1, (18, 20), 3, (255, 255, 255), -1)

    out0 = plugin.run(frame_index=0, channels=ChannelStore.empty().with_channel(ChannelName("frame"), frame0), config=RunConfig(mode="preview", scenario="smoke_airflow"))
    out1 = plugin.run(frame_index=1, channels=ChannelStore.empty().with_channel(ChannelName("frame"), frame1), config=RunConfig(mode="preview", scenario="smoke_airflow"))

    # combine last tracks into overlay
    channels = ChannelStore.empty().with_channel(ChannelName("frame"), frame1).with_channel(ChannelName("tracks"), out1.get(ChannelName("tracks")))
    result = overlay.run(frame_index=1, channels=channels, config=RunConfig(mode="preview", scenario="smoke_airflow"))
    out_frame = result.get(ChannelName("frame"))
    assert out_frame.shape == frame1.shape
    assert np.any(out_frame != frame1)
