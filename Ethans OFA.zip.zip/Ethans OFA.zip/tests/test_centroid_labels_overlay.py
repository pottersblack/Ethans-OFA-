import numpy as np
from pipeline.channels import ChannelStore
from pipeline.types import RunConfig, ChannelName
from plugins.overlays.centroid_labels import CentroidLabelsOverlay

def test_centroid_labels_overlay():
    # Synthetic frame and region mask
    frame = np.zeros((64, 64, 3), dtype=np.uint8)
    mask = np.zeros((64, 64), dtype=np.int32)
    mask[16:48, 16:48] = 1  # region 1
    mask[0:16, :] = 2       # region 2
    mask[:, 48:64] = 3      # region 3
    channels = ChannelStore.empty().with_channel(ChannelName("frame"), frame).with_channel(ChannelName("region_mask"), mask)
    overlay = CentroidLabelsOverlay()
    config = RunConfig(mode="preview", scenario="smoke_airflow")
    out_channels = overlay.run(frame_index=0, channels=channels, config=config)
    out_frame = out_channels.get(ChannelName("frame"))
    assert out_frame.shape == frame.shape
    assert np.any(out_frame != frame), "Overlay should modify the frame"

if __name__ == "__main__":
    test_centroid_labels_overlay()
    print("CentroidLabelsOverlay test passed.")
