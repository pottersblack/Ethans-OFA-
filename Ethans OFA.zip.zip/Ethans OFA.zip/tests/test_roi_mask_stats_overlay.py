import numpy as np
from pipeline.channels import ChannelStore
from pipeline.types import RunConfig, ChannelName
from plugins.overlays.roi_mask_stats import ROIMaskStatsOverlay

def test_roi_mask_stats_overlay():
    # Synthetic frame, ROI mask, and flow
    frame = np.zeros((64, 64, 3), dtype=np.uint8)
    mask = np.zeros((64, 64), dtype=np.uint8)
    mask[16:48, 16:48] = 1  # ROI
    flow = np.zeros((64, 64, 2), dtype=np.float32)
    flow[..., 0] = 2.0
    flow[..., 1] = 3.0
    channels = ChannelStore.empty().with_channel(ChannelName("frame"), frame).with_channel(ChannelName("roi_mask"), mask).with_channel(ChannelName("flow_uv"), flow)
    overlay = ROIMaskStatsOverlay()
    config = RunConfig(mode="preview", scenario="smoke_airflow")
    out_channels = overlay.run(frame_index=0, channels=channels, config=config)
    out_frame = out_channels.get(ChannelName("frame"))
    assert out_frame.shape == frame.shape
    assert np.any(out_frame != frame), "Overlay should modify the frame"

if __name__ == "__main__":
    test_roi_mask_stats_overlay()
    print("ROIMaskStatsOverlay test passed.")
