import tempfile
from pathlib import Path

import cv2
import pickle
import numpy as np

from pipeline.types import RunConfig, Mode, Scenario
from main import _build_pipeline, process_capture


def _write_test_video(path: Path, frames: int = 6, w: int = 160, h: int = 120):
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    writer = cv2.VideoWriter(str(path), fourcc, 30.0, (w, h))
    for i in range(frames):
        img = np.zeros((h, w, 3), dtype=np.uint8)
        # moving bright dot to generate simple detections/flow
        cx = int(10 + i * (w - 20) / max(1, frames - 1))
        cy = int(h / 2 + 5 * np.sin(i))
        cv2.circle(img, (cx, cy), 4, (255, 255, 255), -1)
        writer.write(img)
    writer.release()


def test_pickle_two_pass_cache(tmp_path: Path):
    video_path = tmp_path / "test_video.mp4"
    _write_test_video(video_path)

    pipeline = _build_pipeline([])
    config = RunConfig(mode=Mode.PREVIEW, scenario=Scenario.SMOKE_AIRFLOW, device="cpu")

    # Dry-run: collect cache_data
    metrics, cache_data = process_capture(video_path, pipeline, config, output_path=None, max_frames=0)
    assert isinstance(cache_data, dict)

    # Write pickle cache with string keys (same behavior as main)
    cache_file = tmp_path / "cache_test.pickle"
    with open(cache_file, "wb") as f:
        norm = {str(k): v for k, v in cache_data.items()}
        pickle.dump(norm, f)

    # Load cache and inject into second pass
    with open(cache_file, "rb") as f:
        loaded = pickle.load(f)
    # Ensure keys are strings
    loaded = {str(k): v for k, v in loaded.items()}

    metrics_injected = process_capture(video_path, pipeline, config, output_path=None, max_frames=0, cache=loaded)

    # metrics from dry-run and injected run should be identical
    assert metrics == metrics_injected
