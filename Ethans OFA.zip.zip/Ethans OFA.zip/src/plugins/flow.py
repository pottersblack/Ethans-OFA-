from __future__ import annotations

import cv2
import numpy as np
from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from pipeline.channels import ChannelStore
from pipeline.types import ChannelName, Plugin, RunConfig, Mode

FRAME = ChannelName("frame")
PREV_FRAME = ChannelName("prev_frame")
FLOW_UV = ChannelName("flow_uv")

@dataclass(frozen=True)
class FarnebackFlowPlugin(Plugin):
    id: str = "flow.farneback"
    name: str = "Farneback Optical Flow"
    required_channels: Sequence[ChannelName] = (PREV_FRAME, FRAME)
    provides_channels: Sequence[ChannelName] = (FLOW_UV,)

    def params_schema(self) -> Mapping[str, Any]:
        return {}

    def run(self, *, frame_index: int, channels: ChannelStore, config: RunConfig) -> ChannelStore:
        prev = channels.get(PREV_FRAME)
        curr = channels.get(FRAME)
        h, w = curr.shape[:2]
        prev_gray = cv2.cvtColor(prev, cv2.COLOR_BGR2GRAY)
        curr_gray = cv2.cvtColor(curr, cv2.COLOR_BGR2GRAY)
        
        # Determine downscaling: Export always 1.0, Preview respects quality settings
        if config.mode == Mode.EXPORT:
            downscale_factor = 1.0  # Always full resolution for export
        elif config.high_quality_flow:
            downscale_factor = 1.0  # User wants high quality preview
        else:
            # Use preview_downscale from config (set by UI quality preset)
            downscale_factor = getattr(config, 'preview_downscale', 0.5)
        
        if downscale_factor < 1.0:
            small_h, small_w = int(h * downscale_factor), int(w * downscale_factor)
            prev_gray = cv2.resize(prev_gray, (small_w, small_h), interpolation=cv2.INTER_AREA)
            curr_gray = cv2.resize(curr_gray, (small_w, small_h), interpolation=cv2.INTER_AREA)
        
        # Accuracy: adjust Farneback parameters
        if config.high_quality_flow:
            # High-quality settings: more pyramid levels, more iterations
            pyr_scale, levels, winsize, iterations = 0.5, 5, 21, 5
            poly_n, poly_sigma = 7, 1.5
        else:
            # Default balanced settings
            pyr_scale, levels, winsize, iterations = 0.5, 3, 15, 3
            poly_n, poly_sigma = 5, 1.2
        
        # Subpixel refinement flag
        flags = 0
        if config.subpixel_refinement:
            poly_n = max(poly_n, 7)
        
        # If user requested CUDA and OpenCV exposes CUDA Farneback, try that first
        use_cuda = getattr(config, "device", "auto") == "cuda"
        flow = None
        if use_cuda:
            try:
                if hasattr(cv2, "cuda") and cv2.cuda.getCudaEnabledDeviceCount() > 0:
                    # Upload to GPU
                    pg = cv2.cuda_GpuMat()
                    cg = cv2.cuda_GpuMat()
                    pg.upload(prev_gray)
                    cg.upload(curr_gray)
                    # Create CUDA Farneback with accuracy parameters
                    fb = cv2.cuda_FarnebackOpticalFlow.create(
                        numLevels=levels,
                        pyrScale=pyr_scale,
                        winSize=winsize,
                        numIters=iterations,
                        polyN=poly_n,
                        polySigma=poly_sigma,
                        flags=flags
                    )
                    flow_gpu = fb.calc(pg, cg, None)
                    flow = flow_gpu.download()
            except Exception:
                # Any failure should fall back to CPU implementation
                flow = None

        # CPU fallback
        if flow is None:
            flow = cv2.calcOpticalFlowFarneback(
                prev_gray, curr_gray, None,
                pyr_scale=pyr_scale, levels=levels, winsize=winsize,
                iterations=iterations, poly_n=poly_n, poly_sigma=poly_sigma,
                flags=flags
            )
        
        # Temporal smoothing: blend with previous flow if available
        if config.temporal_smoothing and hasattr(self, '_prev_flow') and self._prev_flow is not None:
            if self._prev_flow.shape == flow.shape:
                flow = cv2.addWeighted(flow, 0.7, self._prev_flow, 0.3, 0)
        
        # Store for next frame (only if temporal smoothing enabled)
        if config.temporal_smoothing:
            if not hasattr(self, '_prev_flow'):
                object.__setattr__(self, '_prev_flow', None)
            object.__setattr__(self, '_prev_flow', flow.copy())
        
        # Upscale flow back to original resolution if downscaled
        if downscale_factor < 1.0:
            flow = cv2.resize(flow, (w, h), interpolation=cv2.INTER_LINEAR)
            flow = flow / downscale_factor
        
        return channels.with_channel(FLOW_UV, flow)