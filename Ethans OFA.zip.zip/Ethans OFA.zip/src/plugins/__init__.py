"""Plugins (analysis + overlays)."""
