"""
Flow Vector Field Overlay
Quiver/arrow plot of optical flow vectors.
"""
from .base_overlay import OverlayPlugin
import cv2
import numpy as np
from pipeline.types import ChannelName

class FlowVectorFieldOverlay(OverlayPlugin):
    id = "flow_vector_field"
    name = "Flow Vector Field"
    required_channels = (ChannelName("frame"), ChannelName("flow_uv"))
    provides_channels = (ChannelName("frame"),)

    def _run_overlay(self, frame_index, channels, config):
        frame = channels.get("frame")
        flow = channels.get("flow_uv")
        overlay = frame.copy()
        h, w = flow.shape[:2]
        # Grid spacing (auto-scale for preview)
        spacing = max(8, min(h, w) // 32)
        y_idx, x_idx = np.mgrid[spacing//2:h:spacing, spacing//2:w:spacing]
        for y, x in zip(y_idx.flatten(), x_idx.flatten()):
            fx, fy = flow[y, x]
            mag = np.sqrt(fx**2 + fy**2)
            angle = np.arctan2(fy, fx)
            # Color by angle (direction)
            color = tuple(int(c) for c in cv2.applyColorMap(np.array([[int((angle+np.pi)/(2*np.pi)*255)]], dtype=np.uint8), cv2.COLORMAP_HSV)[0,0])
            end_x = int(x + fx * 2)
            end_y = int(y + fy * 2)
            cv2.arrowedLine(overlay, (x, y), (end_x, end_y), color, 1, tipLength=0.3)
        overlay = self.render_legend(overlay, spacing)
        return channels.with_channel("frame", overlay)

    def render_legend(self, frame, spacing):
        # Draw arrow scale legend at bottom left
        h, w = frame.shape[:2]
        x0, y0 = 24, h - 32
        cv2.arrowedLine(frame, (x0, y0), (x0+spacing*2, y0), (255,255,255), 2, tipLength=0.3)
        self.draw_text_with_bg(frame, f"Scale: {spacing*2}px", (x0+spacing*2+8, y0+6), font_scale=0.5, color=None, thickness=1)
        self.draw_text_with_bg(frame, "Direction: HSV", (x0, y0-12), font_scale=0.5, color=None, thickness=1)
        return frame