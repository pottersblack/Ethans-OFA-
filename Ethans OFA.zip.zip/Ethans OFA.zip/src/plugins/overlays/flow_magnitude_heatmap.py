"""Flow Magnitude Heatmap Overlay - Color-coded speed map of optical flow magnitude."""
# pylint: disable=E1101
from .base_overlay import OverlayPlugin
import cv2
import numpy as np
from pipeline.types import ChannelName

class FlowMagnitudeHeatmapOverlay(OverlayPlugin):
    id = "flow_magnitude_heatmap"
    name = "Flow Magnitude Heatmap"
    required_channels = (ChannelName("frame"), ChannelName("flow_uv"))
    provides_channels = (ChannelName("frame"),)

    def _run_overlay(self, frame_index, channels, config):
        frame = channels.get("frame")
        flow = channels.get("flow_uv")
        # Compute magnitude
        mag = np.sqrt(flow[...,0]**2 + flow[...,1]**2)
        # Try to limit rendering to detection regions if available
        mask = None
        try:
            for k in (ChannelName("tracks"), "tracks", ChannelName("detection_mask"), "detection_mask"):
                try:
                    ch = channels.get(k)
                except Exception:
                    ch = None
                if ch is None:
                    continue
                if isinstance(ch, list):
                    mask = np.zeros(mag.shape, dtype=np.uint8)
                    for t in ch:
                        for (x, y) in t.get("pts", []):
                            cv2.circle(mask, (int(x), int(y)), 8, 1, -1)
                    break
                if isinstance(ch, np.ndarray):
                    mask = (ch.astype(np.uint8) > 0).astype(np.uint8)
                    break
        except Exception:
            mask = None

        alpha = 0.65
        if mask is None or mask.sum() == 0:
            mag_norm = cv2.normalize(mag, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
            heatmap = cv2.applyColorMap(mag_norm, cv2.COLORMAP_JET)
            # Blend heatmap but keep base video bright
            overlay = cv2.addWeighted(frame, 1.0, heatmap, alpha, 0)
            overlay = cv2.max(frame, overlay)
        else:
            ys, xs = np.where(mask)
            y0, y1 = max(0, ys.min()), min(mask.shape[0], ys.max() + 1)
            x0, x1 = max(0, xs.min()), min(mask.shape[1], xs.max() + 1)
            mag_crop = mag[y0:y1, x0:x1]
            mag_norm = cv2.normalize(mag_crop, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
            heat_crop = cv2.applyColorMap(mag_norm, cv2.COLORMAP_JET)
            out = frame.copy()
            roi = frame[y0:y1, x0:x1]
            blended = cv2.addWeighted(roi, 1.0, heat_crop, alpha, 0)
            mask_crop = mask[y0:y1, x0:x1].astype(bool)
            out[y0:y1, x0:x1][mask_crop] = blended[mask_crop]
            overlay = out
        # Optionally add legend
        overlay = self.render_legend(overlay)
        return channels.with_channel("frame", overlay)

    def render_legend(self, frame):
        # Draw a simple colorbar legend at the bottom right, sized to the frame
        h, w = frame.shape[:2]
        max_bar_w = max(4, w - 32)
        max_bar_h = max(1, h - 32)
        bar_h = min(16, max_bar_h)
        bar_w = min(160, max_bar_w)
        if bar_w <= 0 or bar_h <= 0:
            return frame
        bar = np.linspace(0, 255, bar_w).astype(np.uint8)
        bar_img = cv2.applyColorMap(bar[None, :], cv2.COLORMAP_JET)
        bar_img = cv2.resize(bar_img, (bar_w, bar_h), interpolation=cv2.INTER_LINEAR)
        y0, x0 = max(0, h - bar_h - 8), max(0, w - bar_w - 16)
        frame[y0:y0+bar_h, x0:x0+bar_w] = bar_img
        label_y = y0 + bar_h + 12
        if label_y < h:
            self.draw_text_with_bg(frame, "Low", (x0, label_y), font_scale=0.4, color=None, thickness=1)
            self.draw_text_with_bg(frame, "High", (x0+bar_w-36, label_y), font_scale=0.4, color=None, thickness=1)
        return frame