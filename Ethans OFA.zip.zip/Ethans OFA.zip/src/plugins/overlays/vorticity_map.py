"""
Vorticity Map Overlay
Color-coded curl (rotation) of flow field.
"""
from .base_overlay import OverlayPlugin
import cv2
import numpy as np
from pipeline.types import ChannelName

class VorticityMapOverlay(OverlayPlugin):
    id = "vorticity_map"
    name = "Vorticity Map"
    required_channels = (ChannelName("frame"), ChannelName("flow_uv"))
    provides_channels = (ChannelName("frame"),)

    def _run_overlay(self, frame_index, channels, config):
        frame = channels.get("frame")
        flow = channels.get("flow_uv")
        # Compute vorticity (curl): dVy/dx - dVx/dy
        fx = flow[..., 0]
        fy = flow[..., 1]
        dvy_dx = np.gradient(fy, axis=1)
        dvx_dy = np.gradient(fx, axis=0)
        vorticity = dvy_dx - dvx_dy
        vort_norm = cv2.normalize(vorticity, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        vort_map = cv2.applyColorMap(vort_norm, cv2.COLORMAP_TURBO)
        overlay = cv2.addWeighted(frame, 1.0, vort_map, 0.65, 0)
        overlay = cv2.max(frame, overlay)
        overlay = self.render_legend(overlay)
        return channels.with_channel("frame", overlay)

    def render_legend(self, frame):
        # Draw colorbar legend at bottom right (fit to frame)
        h, w = frame.shape[:2]
        max_bar_w = max(4, w - 32)
        max_bar_h = max(1, h - 32)
        bar_h = min(16, max_bar_h)
        bar_w = min(160, max_bar_w)
        if bar_w <= 0 or bar_h <= 0:
            return frame
        bar = np.linspace(0, 255, bar_w).astype(np.uint8)
        bar_img = cv2.applyColorMap(bar[None, :], cv2.COLORMAP_TURBO)
        bar_img = cv2.resize(bar_img, (bar_w, bar_h), interpolation=cv2.INTER_LINEAR)
        y0, x0 = max(0, h - bar_h - 8), max(0, w - bar_w - 16)
        frame[y0:y0+bar_h, x0:x0+bar_w] = bar_img
        label_y = y0 + bar_h + 12
        if label_y < h:
            self.draw_text_with_bg(frame, "Low", (x0, label_y), font_scale=0.4, color=None, thickness=1)
            self.draw_text_with_bg(frame, "High", (x0+bar_w-36, label_y), font_scale=0.4, color=None, thickness=1)
            self.draw_text_with_bg(frame, "Vorticity", (x0+bar_w//2-32, label_y), font_scale=0.4, color=None, thickness=1)
        return frame