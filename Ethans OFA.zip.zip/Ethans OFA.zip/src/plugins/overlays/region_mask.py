"""
Region Mask Overlay
Segmentation, colored regions.
"""
from .base_overlay import OverlayPlugin
import cv2
import numpy as np
from pipeline.types import ChannelName

class RegionMaskOverlay(OverlayPlugin):
    id = "region_mask"
    name = "Region Mask"
    required_channels = (ChannelName("frame"), ChannelName("region_mask"))
    provides_channels = (ChannelName("frame"),)

    def _run_overlay(self, frame_index, channels, config):
        frame = channels.get("frame")
        mask = channels.get("region_mask")  # mask: HxW, int labels
        # Assign random color to each region label
        labels = np.unique(mask)
        color_map = {lbl: tuple(np.random.randint(0,255,3).tolist()) for lbl in labels}
        color_mask = np.zeros_like(frame)
        for lbl in labels:
            color_mask[mask == lbl] = color_map[lbl]
        overlay = cv2.addWeighted(frame, 1.0, color_mask, 0.5, 0)
        overlay = cv2.max(frame, overlay)
        overlay = self.render_legend(overlay, color_map)
        return channels.with_channel("frame", overlay)

    def render_legend(self, frame, color_map):
        # Draw color squares for each region label
        h, w = frame.shape[:2]
        x0, y0 = 16, h - 24
        for i, (lbl, color) in enumerate(color_map.items()):
            cv2.rectangle(frame, (x0 + i*32, y0), (x0 + i*32 + 24, y0 + 16), color, -1)
            self.draw_text_with_bg(frame, str(lbl), (x0 + i*32, y0-4), font_scale=0.5, color=None, thickness=1)
        return frame