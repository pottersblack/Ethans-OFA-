"""
Particle/Bubble Tracking Overlay
Shows counts and tracks of detected particles/bubbles.
"""
from .base_overlay import OverlayPlugin
import cv2
import numpy as np
from pipeline.types import ChannelName, RunConfig

class ParticleBubbleTrackingOverlay(OverlayPlugin):
    id = "particle_bubble_tracking"
    name = "Particle/Bubble Tracking"
    required_channels = (ChannelName("frame"), ChannelName("tracks"))
    provides_channels = (ChannelName("frame"),)

    def __init__(self, opacity: float = 0.5):
        self.opacity = opacity

    def _run_overlay(self, frame_index, channels, config: RunConfig):
        frame = channels.get(ChannelName("frame"))
        tracks = channels.get(ChannelName("tracks"))  # List of dicts: {"pts": [(x0,y0),...], "id": int, "type": str}
        overlay = np.zeros_like(frame)
        count = 0
        for i, track in enumerate(tracks):
            tid = track.get("id", i)
            pts = track.get("pts", [])
            ttype = track.get("type", "particle")
            if not pts:
                continue
            color = (0,255,0) if ttype == "bubble" else (255,255,0)
            pos = tuple(map(int, pts[-1]))
            cv2.circle(overlay, pos, 8, color, 2)
            self.draw_text_with_bg(overlay, f"{ttype[0].upper()}{tid}", (pos[0]+10, pos[1]), font_scale=0.5, color=color, thickness=1)
            count += 1
        # Blend overlay with adjustable opacity
        out = cv2.addWeighted(frame, 1.0 - self.opacity, overlay, self.opacity, 0)
        # Draw count
        self.draw_text_with_bg(out, f"Count: {count}", (16, 32), font_scale=0.8, color=None, thickness=1)
        out = self.render_legend(out)
        return channels.with_channel(ChannelName("frame"), out)

    def render_legend(self, frame):
        h, w = frame.shape[:2]
        x0, y0 = 16, h - 56
        cv2.circle(frame, (x0+12, y0+8), 8, (0,255,0), 2)
        self.draw_text_with_bg(frame, "Bubble", (x0+28, y0+14), font_scale=0.5, color=None, thickness=1)
        cv2.circle(frame, (x0+100, y0+8), 8, (255,255,0), 2)
        self.draw_text_with_bg(frame, "Particle", (x0+116, y0+14), font_scale=0.5, color=None, thickness=1)
        return frame