from __future__ import annotations

# Flow heatmap overlay (preview).
# pylint: disable=E1101
import cv2
import numpy as np
from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from pipeline.channels import ChannelStore
from pipeline.types import ChannelName, Plugin, RunConfig

FRAME = ChannelName("frame")
FLOW_UV = ChannelName("flow_uv")

@dataclass(frozen=True)
class FlowHeatmapOverlay(Plugin):
    id: str = "overlay.heatmap"
    name: str = "Flow Magnitude Heatmap"
    required_channels: Sequence[ChannelName] = (FRAME, FLOW_UV)
    provides_channels: Sequence[ChannelName] = (FRAME,)

    def params_schema(self) -> Mapping[str, Any]:
        return {}

    def run(self, *, frame_index: int, channels: ChannelStore, config: RunConfig) -> ChannelStore:
        frame = channels.get(FRAME)
        flow = channels.get(FLOW_UV)
        mag = np.linalg.norm(flow, axis=2)

        # Try to build a detection mask (tracks or explicit mask) so we only
        # draw the heatmap where detections exist. Fall back to full-frame.
        mask = None
        try:
            for k in (ChannelName("tracks"), "tracks", ChannelName("detection_mask"), "detection_mask"):
                try:
                    ch = channels.get(k)
                except Exception:
                    ch = None
                if ch is None:
                    continue
                # If tracks list, draw small filled circles at track points
                if isinstance(ch, list):
                    mask = np.zeros(mag.shape, dtype=np.uint8)
                    for t in ch:
                        for (x, y) in t.get("pts", []):
                            cv2.circle(mask, (int(x), int(y)), 8, 1, -1)
                    break
                # If already a mask array
                if isinstance(ch, np.ndarray):
                    mask = (ch.astype(np.uint8) > 0).astype(np.uint8)
                    break
        except Exception:
            mask = None

        alpha = 0.4
        if mask is None or mask.sum() == 0:
            mag_norm = cv2.normalize(mag, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
            heatmap = cv2.applyColorMap(mag_norm, cv2.COLORMAP_JET)
            overlay = cv2.addWeighted(frame, 0.6, heatmap, alpha, 0)
            return channels.with_channel(FRAME, overlay)

        # Only compute/apply colormap on the bounding region of the mask
        ys, xs = np.where(mask)
        y0, y1 = max(0, ys.min()), min(mask.shape[0], ys.max() + 1)
        x0, x1 = max(0, xs.min()), min(mask.shape[1], xs.max() + 1)
        mag_crop = mag[y0:y1, x0:x1]
        mag_norm = cv2.normalize(mag_crop, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        heat_crop = cv2.applyColorMap(mag_norm, cv2.COLORMAP_JET)

        out = frame.copy()
        frame_roi = frame[y0:y1, x0:x1]
        blended = cv2.addWeighted(frame_roi, 1.0, heat_crop, alpha, 0)
        mask_crop = mask[y0:y1, x0:x1].astype(bool)
        out[y0:y1, x0:x1][mask_crop] = blended[mask_crop]
        return channels.with_channel(FRAME, out)