"""
Centroid Labels Overlay
Labels region centers.
"""
from .base_overlay import OverlayPlugin
import cv2
import numpy as np
from pipeline.types import ChannelName

class CentroidLabelsOverlay(OverlayPlugin):
    id = "centroid_labels"
    name = "Centroid Labels"
    required_channels = (ChannelName("frame"), ChannelName("region_mask"))
    provides_channels = (ChannelName("frame"),)

    def _run_overlay(self, frame_index, channels, config):
        from pipeline.types import ChannelName
        frame = channels.get(ChannelName("frame"))
        mask = channels.get(ChannelName("region_mask"))
        overlay = frame.copy()
        labels = np.unique(mask)
        def _color_for_label(lbl):
            base = np.array([29, 101, 199], dtype=np.int32)
            v = ((int(lbl) + 2) * base) % 256
            if np.all(v == 0):
                v = (v + 64) % 256
            return tuple(int(x) for x in v.tolist())
        color_map = {lbl: _color_for_label(lbl) for lbl in labels}
        for lbl in labels:
            ys, xs = np.where(mask == lbl)
            if ys.size == 0 or xs.size == 0:
                continue
            cy = int(np.mean(ys))
            cx = int(np.mean(xs))
            # draw filled circle with thin black border for contrast
            cv2.circle(overlay, (cx, cy), 6, color_map[lbl], -1, cv2.LINE_AA)
            cv2.circle(overlay, (cx, cy), 6, (0,0,0), 1, cv2.LINE_AA)
            self.draw_text_with_bg(overlay, str(lbl), (cx-8, cy-8), font_scale=0.45, color=color_map[lbl], thickness=1)
        overlay = self.render_legend(overlay)
        # Store color_map for legend rendering
        self._last_color_map = color_map
        return channels.with_channel(ChannelName("frame"), overlay)

    def render_legend(self, frame):
        # Draw color squares for each region label
        color_map = getattr(self, "_last_color_map", {})
        h, w = frame.shape[:2]
        x0, y0 = 16, h - 24
        for i, (lbl, color) in enumerate(color_map.items()):
            cv2.rectangle(frame, (x0 + i*32, y0), (x0 + i*32 + 24, y0 + 16), color, -1)
            self.draw_text_with_bg(frame, str(lbl), (x0 + i*32, y0-4), font_scale=0.5, thickness=1, color=(255,255,255))
        return frame