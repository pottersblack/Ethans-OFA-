"""
Pull-up Colorbar/Legend Overlay
Shows colorbar/legend for overlays.
"""
from .base_overlay import OverlayPlugin
import cv2
import numpy as np
from pipeline.types import ChannelName, RunConfig

class ColorbarLegendOverlay(OverlayPlugin):
    id = "colorbar_legend"
    name = "Colorbar/Legend"
    required_channels = (ChannelName("frame"),)
    provides_channels = (ChannelName("frame"),)

    def __init__(self, position: str = "bottomright"):
        self.position = position

    def _run_overlay(self, frame_index, channels, config: RunConfig):
        # Use base helper to draw the colorbar consistently
        frame = channels.get(ChannelName("frame"))
        out = frame.copy()
        out = self.draw_colorbar(out, colormap=cv2.COLORMAP_JET, bar_w=200, bar_h=24, position=self.position)
        # Add labels if space permits
        h, w = out.shape[:2]
        # calculate label positions relative to the drawn bar
        if self.position == "bottomright":
            y0 = max(0, h - 24 - 12)
            x0 = max(0, w - 200 - 16)
        elif self.position == "topleft":
            y0, x0 = 12, 16
        else:
            y0 = max(0, h - 24 - 12)
            x0 = max(0, w - 200 - 16)
        label_y = y0 + 24 + 16
        if label_y < h:
            self.draw_text_with_bg(out, "Low", (x0, label_y), font_scale=0.5, color=(255,255,255), thickness=1)
            self.draw_text_with_bg(out, "High", (x0 + 200 - 48, label_y), font_scale=0.5, color=(255,255,255), thickness=1)
            self.draw_text_with_bg(out, "Colorbar", (x0 + 200//2 - 36, label_y), font_scale=0.5, color=(255,255,255), thickness=1)
        return channels.with_channel(ChannelName("frame"), out)