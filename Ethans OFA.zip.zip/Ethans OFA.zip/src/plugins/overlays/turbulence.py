from .base_overlay import OverlayPlugin
import cv2
import numpy as np
from typing import Sequence
from pipeline.types import ChannelName, RunConfig

FRAME = ChannelName("frame")
FLOW_UV = ChannelName("flow_uv")


class TurbulenceOverlay(OverlayPlugin):
    id = "overlay.turbulence"
    name = "Turbulence Overlay"
    required_channels: Sequence[ChannelName] = (FRAME, FLOW_UV)
    provides_channels: Sequence[ChannelName] = (FRAME,)

    def _run_overlay(self, frame_index: int, channels, config: RunConfig):
        frame = channels.get(FRAME).copy()
        flow = channels.get(FLOW_UV)
        # Compute vorticity (curl) of the flow field
        fx = flow[..., 0]
        fy = flow[..., 1]
        dfx_dy = cv2.Sobel(fx, cv2.CV_64F, 0, 1, ksize=3)
        dfy_dx = cv2.Sobel(fy, cv2.CV_64F, 1, 0, ksize=3)
        vorticity = dfy_dx - dfx_dy
        vorticity_norm = cv2.normalize(np.abs(vorticity), None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        color = cv2.applyColorMap(vorticity_norm, cv2.COLORMAP_TURBO)
        overlay = cv2.addWeighted(frame, 1.0, color, 0.65, 0)
        overlay = cv2.max(frame, overlay)
        # add small legend
        overlay = self.draw_colorbar(overlay, colormap=cv2.COLORMAP_TURBO, bar_w=120, bar_h=12, position="bottomright", label="Turbulence")
        return channels.with_channel(FRAME, overlay)