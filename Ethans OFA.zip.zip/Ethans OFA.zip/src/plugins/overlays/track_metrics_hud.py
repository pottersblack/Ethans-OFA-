"""
Track Metrics HUD Overlay
Shows speed/direction per track.
"""
from .base_overlay import OverlayPlugin
import cv2
import numpy as np
from pipeline.types import ChannelName

class TrackMetricsHUDOverlay(OverlayPlugin):
    id = "track_metrics_hud"
    name = "Track Metrics HUD"
    required_channels = (ChannelName("frame"), ChannelName("tracks"))
    provides_channels = (ChannelName("frame"),)

    def _run_overlay(self, frame_index, channels, config):
        frame = channels.get(ChannelName("frame"))
        tracks = channels.get(ChannelName("tracks"))  # List of dicts: {"pts": [(x0,y0),...], "id": int}
        overlay = frame.copy()
        color_map = {}
        for i, track in enumerate(tracks):
            tid = track.get("id", i)
            pts = track.get("pts", [])
            if not pts or len(pts) < 2:
                continue
            color = color_map.setdefault(tid, tuple(np.random.randint(0,255,3).tolist()))
            # Compute speed and direction for last segment
            pt1 = np.array(pts[-2])
            pt2 = np.array(pts[-1])
            delta = pt2 - pt1
            speed = np.linalg.norm(delta)
            angle = np.degrees(np.arctan2(delta[1], delta[0]))
            label = f"ID:{tid} V:{speed:.1f} θ:{angle:.0f}°"
            pos = tuple(map(int, pt2))
            # Use helper for better readability
            self.draw_text_with_bg(overlay, label, (pos[0]+8, pos[1]), font_scale=0.5, color=color, thickness=1)
        overlay = self.render_legend(overlay)
        return channels.with_channel(ChannelName("frame"), overlay)

    def render_legend(self, frame):
        h, w = frame.shape[:2]
        x0, y0 = 16, h - 56
        self.draw_text_with_bg(frame, "Track Metrics HUD: V=speed, θ=angle", (x0, y0), font_scale=0.55, color=(255,255,255), thickness=1)
        return frame