"""
ROI Mask with Stats Overlay
Shows ROI mask and stats (area, mean flow).
"""
from .base_overlay import OverlayPlugin
import cv2
import numpy as np
from pipeline.types import ChannelName

class ROIMaskStatsOverlay(OverlayPlugin):
    id = "roi_mask_stats"
    name = "ROI Mask + Stats"
    required_channels = (ChannelName("frame"), ChannelName("roi_mask"), ChannelName("flow_uv"))
    provides_channels = (ChannelName("frame"),)

    def _run_overlay(self, frame_index, channels, config):
        frame = channels.get(ChannelName("frame"))
        mask = channels.get(ChannelName("roi_mask"))
        flow = channels.get(ChannelName("flow_uv"))
        overlay = frame.copy()
        # Color ROI mask
        roi_color = (0, 255, 128)
        # Build a color image and blend only inside the mask to avoid shape mismatches
        color_img = np.zeros_like(frame)
        color_img[mask > 0] = roi_color
        overlay = cv2.addWeighted(frame, 0.3, color_img, 0.7, 0)
        # Compute stats inside mask
        area = np.sum(mask > 0)
        mean_flow = np.mean(np.sqrt(np.sum(flow[mask > 0]**2, axis=-1))) if area > 0 else 0.0
        # Display stats
        h, w = overlay.shape[:2]
        stats_text = f"ROI Area: {area} px | Mean Flow: {mean_flow:.2f}"
        self.draw_text_with_bg(overlay, stats_text, (16, h - 32), font_scale=0.7, color=None, thickness=1)
        overlay = self.render_legend(overlay)
        return channels.with_channel(ChannelName("frame"), overlay)

    def render_legend(self, frame):
        # Draw ROI color legend
        h, w = frame.shape[:2]
        x0, y0 = 16, h - 56
        roi_color = (0, 255, 128)
        cv2.rectangle(frame, (x0, y0), (x0+32, y0+16), roi_color, -1)
        self.draw_text_with_bg(frame, "ROI", (x0+36, y0+12), font_scale=0.6, color=None, thickness=1)
        return frame