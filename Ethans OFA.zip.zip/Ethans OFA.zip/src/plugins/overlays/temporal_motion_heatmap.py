"""Temporal motion heatmap overlay."""
# pylint: disable=E1101
from .base_overlay import OverlayPlugin
import cv2
import numpy as np
from pipeline.types import ChannelName, RunConfig

class TemporalMotionHeatmapOverlay(OverlayPlugin):
    id = "temporal_motion_heatmap"
    name = "Temporal Motion Heatmap"
    required_channels = (ChannelName("frame"), ChannelName("flow_uv"))
    provides_channels = (ChannelName("frame"),)

    def __init__(self, opacity: float = 0.7):
        self.opacity = opacity
        self._accum = None

    def _run_overlay(self, frame_index, channels, config: RunConfig):
        frame = channels.get(ChannelName("frame"))
        flow = channels.get(ChannelName("flow_uv"))
        mag = np.sqrt(flow[...,0]**2 + flow[...,1]**2)
        if self._accum is None or self._accum.shape != mag.shape:
            self._accum = np.zeros_like(mag, dtype=np.float32)
        self._accum += mag
        accum_norm_full = cv2.normalize(self._accum, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)

        # Build detection mask if available and only render heatmap there
        mask = None
        try:
            for k in (ChannelName("tracks"), "tracks", ChannelName("detection_mask"), "detection_mask"):
                try:
                    ch = channels.get(k)
                except Exception:
                    ch = None
                if ch is None:
                    continue
                if isinstance(ch, list):
                    mask = np.zeros(accum_norm_full.shape, dtype=np.uint8)
                    for t in ch:
                        for (x, y) in t.get("pts", []):
                            cv2.circle(mask, (int(x), int(y)), 8, 1, -1)
                    break
                if isinstance(ch, np.ndarray):
                    mask = (ch.astype(np.uint8) > 0).astype(np.uint8)
                    break
        except Exception:
            mask = None

        if mask is None or mask.sum() == 0:
            heatmap = cv2.applyColorMap(accum_norm_full, cv2.COLORMAP_HOT)
            out = cv2.addWeighted(frame, 1.0, heatmap, 0.6, 0)
            out = cv2.max(frame, out)
        else:
            ys, xs = np.where(mask)
            y0, y1 = max(0, ys.min()), min(mask.shape[0], ys.max() + 1)
            x0, x1 = max(0, xs.min()), min(mask.shape[1], xs.max() + 1)
            accum_norm = accum_norm_full[y0:y1, x0:x1]
            heat_crop = cv2.applyColorMap(accum_norm, cv2.COLORMAP_HOT)
            out = frame.copy()
            roi = frame[y0:y1, x0:x1]
            blended = cv2.addWeighted(roi, 1.0, heat_crop, 0.6, 0)
            mask_crop = mask[y0:y1, x0:x1].astype(bool)
            out[y0:y1, x0:x1][mask_crop] = blended[mask_crop]
        out = self.render_legend(out)
        return channels.with_channel(ChannelName("frame"), out)

    def render_legend(self, frame):
        # Use standard colorbar helper with HOT colormap
        frame = self.draw_colorbar(frame, colormap=cv2.COLORMAP_HOT, bar_w=160, bar_h=16, position="bottomright", label="Accum Motion")
        return frame