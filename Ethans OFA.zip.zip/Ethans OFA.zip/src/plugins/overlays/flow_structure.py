from __future__ import annotations

import cv2
import numpy as np
from dataclasses import dataclass, field
from typing import Any, Dict, Mapping, Sequence

from pipeline.channels import ChannelStore
from pipeline.types import ChannelName, Plugin, RunConfig

FRAME = ChannelName("frame")
FLOW_UV = ChannelName("flow_uv")
FLOW_FIELDS = ChannelName("flow_fields")
FLOW_METRICS = ChannelName("flow_metrics")

def compute_fields(flow: np.ndarray) -> Dict[str, np.ndarray]:
    fx = flow[..., 0]
    fy = flow[..., 1]
    # Vorticity (curl)
    dfx_dy = cv2.Sobel(fx, cv2.CV_64F, 0, 1, ksize=3)
    dfy_dx = cv2.Sobel(fy, cv2.CV_64F, 1, 0, ksize=3)
    vorticity = dfy_dx - dfx_dy
    # Divergence
    dfx_dx = cv2.Sobel(fx, cv2.CV_64F, 1, 0, ksize=3)
    dfy_dy = cv2.Sobel(fy, cv2.CV_64F, 0, 1, ksize=3)
    divergence = dfx_dx + dfy_dy
    # Shear (symmetric gradient norm)
    shear = np.sqrt((dfx_dx - dfy_dy) ** 2 + (dfy_dx + dfx_dy) ** 2)
    return {"vorticity": vorticity, "divergence": divergence, "shear": shear}

def extract_regions(vort: np.ndarray, thresh: float) -> list[dict]:
    import scipy.ndimage as ndi
    mask = np.abs(vort) > thresh
    labeled, n = ndi.label(mask)
    regions = []
    for i in range(1, n+1):
        region_mask = labeled == i
        if np.sum(region_mask) == 0:
            continue
        yx = np.argwhere(region_mask)
        y0, x0 = yx.min(axis=0)
        y1, x1 = yx.max(axis=0)
        centroid = yx.mean(axis=0)
        mean_curl = float(np.mean(vort[region_mask]))
        regions.append({
            "bbox": [int(x0), int(y0), int(x1), int(y1)],
            "centroid": [float(centroid[1]), float(centroid[0])],
            "area": int(np.sum(region_mask)),
            "mean_curl": mean_curl,
        })
    return regions

def compute_metrics(fields: Dict[str, np.ndarray], vort_ema: np.ndarray | None = None) -> Dict[str, Any]:
    vort = fields["vorticity"]
    vort_abs = np.abs(vort)
    area = vort.size
    thresh = np.percentile(vort_abs, 95)
    turbulent_mask = vort_abs > thresh
    regions = extract_regions(vort, thresh)
    metrics = {
        "vorticity_mean": float(np.mean(vort)),
        "vorticity_std": float(np.std(vort)),
        "max_vorticity": float(np.max(vort_abs)),
        "turbulent_area_ratio": float(np.sum(turbulent_mask)) / area,
        "dominant_rotation": "CW" if np.mean(vort) < 0 else "CCW",
        "regions": regions,
    }
    if vort_ema is not None:
        metrics["vorticity_ema_mean"] = float(np.mean(vort_ema))
        metrics["vorticity_ema_std"] = float(np.std(vort_ema))
    return metrics

def render_overlay(frame: np.ndarray, fields: Dict[str, np.ndarray], mode: str = "vorticity") -> np.ndarray:
    if mode == "vorticity":
        v = fields["vorticity"]
        v_norm = cv2.normalize(np.abs(v), None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        color = cv2.applyColorMap(v_norm, cv2.COLORMAP_TURBO)
        return cv2.addWeighted(frame, 0.7, color, 0.3, 0)
    elif mode == "divergence":
        d = fields["divergence"]
        d_norm = cv2.normalize(np.abs(d), None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        color = cv2.applyColorMap(d_norm, cv2.COLORMAP_BONE)
        return cv2.addWeighted(frame, 0.7, color, 0.3, 0)
    elif mode == "shear":
        s = fields["shear"]
        s_norm = cv2.normalize(np.abs(s), None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        color = cv2.applyColorMap(s_norm, cv2.COLORMAP_HOT)
        return cv2.addWeighted(frame, 0.7, color, 0.3, 0)
    elif mode == "combined":
        # Hue: vorticity sign, Saturation: magnitude, Value: divergence
        v = fields["vorticity"]
        d = fields["divergence"]
        s = fields["shear"]
        h = ((v > 0).astype(np.uint8) * 120).astype(np.uint8)  # 0=red (CW), 120=blue (CCW)
        sat = cv2.normalize(np.abs(v), None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        val = cv2.normalize(np.abs(d), None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        hsv = np.stack([h, sat, val], axis=-1)
        color = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)
        return cv2.addWeighted(frame, 0.6, color, 0.4, 0)
    else:
        return frame


class FlowStructure(Plugin):
    id: str = "overlay.flow_structure"
    name: str = "Flow Structure Analyzer/Overlay"
    required_channels: Sequence[ChannelName] = (FRAME, FLOW_UV)
    provides_channels: Sequence[ChannelName] = (FRAME, FLOW_FIELDS, FLOW_METRICS)
    mode: str = "vorticity"  # vorticity, divergence, shear, combined
    alpha: float = 0.2  # EMA smoothing factor

    def __init__(self, mode: str = "vorticity", alpha: float = 0.2):
        object.__setattr__(self, "mode", mode)
        object.__setattr__(self, "alpha", alpha)
        self._vort_ema = None  # type: np.ndarray | None

    def params_schema(self) -> Mapping[str, Any]:
        return {"mode": {"type": "str", "default": self.mode, "enum": ["vorticity", "divergence", "shear", "combined"]},
                "alpha": {"type": "float", "default": self.alpha, "description": "EMA smoothing factor"}}

    def run(self, *, frame_index: int, channels: ChannelStore, config: RunConfig) -> ChannelStore:
        frame = channels.get(FRAME)
        flow = channels.get(FLOW_UV)
        fields = compute_fields(flow)
        vort = fields["vorticity"]
        # Temporal EMA
        if self._vort_ema is None:
            self._vort_ema = vort.copy()
        else:
            self._vort_ema = self.alpha * vort + (1 - self.alpha) * self._vort_ema
        metrics = compute_metrics(fields, self._vort_ema)
        overlay = render_overlay(frame, fields, mode=self.mode)
        return channels.with_channels({FLOW_FIELDS: fields, FLOW_METRICS: metrics, FRAME: overlay})