"""
Field Vector Density Plot Overlay
2D bins colored by local magnitude/density.
"""
from .base_overlay import OverlayPlugin
import cv2
import numpy as np
from pipeline.types import ChannelName, RunConfig

class FieldVectorDensityOverlay(OverlayPlugin):
    id = "field_vector_density"
    name = "Field Vector Density Plot"
    required_channels = (ChannelName("frame"), ChannelName("flow_uv"))
    provides_channels = (ChannelName("frame"),)

    def __init__(self, opacity: float = 0.6, bins: int = 16):
        self.opacity = opacity
        self.bins = bins

    def _run_overlay(self, frame_index, channels, config: RunConfig):
        frame = channels.get(ChannelName("frame"))
        flow = channels.get(ChannelName("flow_uv"))
        h, w = frame.shape[:2]
        mag = np.sqrt(flow[...,0]**2 + flow[...,1]**2)
        # Bin the field
        bin_h, bin_w = h // self.bins, w // self.bins
        density_map = np.zeros((self.bins, self.bins), dtype=np.float32)
        for i in range(self.bins):
            for j in range(self.bins):
                y0, y1 = i*bin_h, min((i+1)*bin_h, h)
                x0, x1 = j*bin_w, min((j+1)*bin_w, w)
                region = mag[y0:y1, x0:x1]
                density_map[i, j] = np.mean(region) if region.size > 0 else 0
        # Normalize and color
        norm = cv2.normalize(density_map, np.zeros_like(density_map, dtype=np.uint8), 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        color_map = cv2.applyColorMap(norm, cv2.COLORMAP_JET)
        # Upscale to frame size
        color_map_up = cv2.resize(color_map, (w, h), interpolation=cv2.INTER_NEAREST)
        out = cv2.addWeighted(frame, 1.0 - self.opacity, color_map_up, self.opacity, 0)
        out = self.render_legend(out)
        return channels.with_channel(ChannelName("frame"), out)

    def render_legend(self, frame):
        h, w = frame.shape[:2]
        max_bar_w = max(4, w - 32)
        max_bar_h = max(1, h - 32)
        bar_h = min(16, max_bar_h)
        bar_w = min(160, max_bar_w)
        if bar_w <= 0 or bar_h <= 0:
            return frame
        bar = np.linspace(0, 255, bar_w).astype(np.uint8)
        bar_img = cv2.applyColorMap(bar[None, :], cv2.COLORMAP_JET)
        bar_img = cv2.resize(bar_img, (bar_w, bar_h), interpolation=cv2.INTER_LINEAR)
        y0, x0 = max(0, h - bar_h - 8), max(0, w - bar_w - 16)
        frame[y0:y0+bar_h, x0:x0+bar_w] = bar_img
        label_y = y0 + bar_h + 12
        if label_y < h:
            self.draw_text_with_bg(frame, "Low", (x0, label_y), font_scale=0.4, color=None, thickness=1)
            self.draw_text_with_bg(frame, "High", (x0+bar_w-36, label_y), font_scale=0.4, color=None, thickness=1)
            self.draw_text_with_bg(frame, "Vector Density", (x0+bar_w//2-36, label_y), font_scale=0.4, color=None, thickness=1)
        return frame