from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from pipeline.channels import ChannelStore
from pipeline.types import ChannelName, Plugin, RunConfig


FRAME = ChannelName("frame")


@dataclass(frozen=True)
class PassthroughOverlay(Plugin):
    id: str = "overlay.passthrough"
    name: str = "Passthrough"

    required_channels: Sequence[ChannelName] = (FRAME,)
    provides_channels: Sequence[ChannelName] = ()

    def params_schema(self) -> Mapping[str, Any]:
        return {}

    def run(self, *, frame_index: int, channels: ChannelStore, config: RunConfig) -> ChannelStore:
        # No modifications yet; scaffolding-only.
        return channels
