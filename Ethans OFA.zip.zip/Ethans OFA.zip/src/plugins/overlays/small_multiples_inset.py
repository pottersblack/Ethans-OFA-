"""
Small Multiples/Inset Views Overlay
Shows derived field insets.
"""
from .base_overlay import OverlayPlugin
import cv2
import numpy as np
from pipeline.types import ChannelName, RunConfig

class SmallMultiplesInsetOverlay(OverlayPlugin):
    id = "small_multiples_inset"
    name = "Small Multiples/Inset Views"
    required_channels = (ChannelName("frame"), ChannelName("flow_uv"))
    provides_channels = (ChannelName("frame"),)

    def __init__(self, opacity: float = 0.7):
        self.opacity = opacity

    def _run_overlay(self, frame_index, channels, config: RunConfig):
        frame = channels.get(ChannelName("frame"))
        flow = channels.get(ChannelName("flow_uv"))
        h, w = frame.shape[:2]
        insets = []
        # Magnitude inset
        mag = np.sqrt(flow[...,0]**2 + flow[...,1]**2)
        mag_norm = cv2.normalize(mag, np.zeros_like(mag, dtype=np.uint8), 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        mag_img = cv2.applyColorMap(mag_norm, cv2.COLORMAP_JET)
        insets.append((mag_img, "|V|"))
        # Vorticity inset
        fx, fy = flow[...,0], flow[...,1]
        dvy_dx = np.gradient(fy, axis=1)
        dvx_dy = np.gradient(fx, axis=0)
        vorticity = dvy_dx - dvx_dy
        vort_norm = cv2.normalize(vorticity, np.zeros_like(vorticity, dtype=np.uint8), 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        vort_img = cv2.applyColorMap(vort_norm, cv2.COLORMAP_TURBO)
        insets.append((vort_img, "curl"))
        # Place insets in corners
        overlay = frame.copy()
        inset_h, inset_w = h//4, w//4
        for i, (img, label) in enumerate(insets):
            img_resized = cv2.resize(img, (inset_w, inset_h))
            y, x = 8, 8 + i*(inset_w+8)
            roi = overlay[y:y+inset_h, x:x+inset_w]
            blended = cv2.addWeighted(roi, 1.0-self.opacity, img_resized, self.opacity, 0)
            overlay[y:y+inset_h, x:x+inset_w] = blended
            # Use helper for readable inset labels
            self.draw_text_with_bg(overlay, label, (x+6, y+inset_h-8), font_scale=0.55, color=(255,255,255), thickness=1)
        overlay = self.render_legend(overlay)
        return channels.with_channel(ChannelName("frame"), overlay)

    def render_legend(self, frame):
        h, w = frame.shape[:2]
        x0, y0 = 16, h - 56
        self.draw_text_with_bg(frame, "Insets: |V|=magnitude, curl=vorticity", (x0, y0), font_scale=0.55, color=(255,255,255), thickness=1)
        return frame