"""
Feature Track Trails Overlay
Shows sparse/dense feature tracks with history.
"""
from .base_overlay import OverlayPlugin
import cv2
import numpy as np
from pipeline.types import ChannelName

class FeatureTrackTrailsOverlay(OverlayPlugin):
    id = "feature_track_trails"
    name = "Feature Track Trails"
    required_channels = (ChannelName("frame"), ChannelName("tracks"))
    provides_channels = (ChannelName("frame"),)

    def _run_overlay(self, frame_index, channels, config):
        frame = channels.get(ChannelName("frame"))
        tracks = channels.get(ChannelName("tracks"))  # List of dicts: {"pts": [(x0,y0), (x1,y1), ...], "id": int}
        overlay = frame.copy()
        color_map = {}
        for i, track in enumerate(tracks):
            tid = track.get("id", i)
            pts = track.get("pts", [])
            if not pts or len(pts) < 2:
                continue
            color = color_map.setdefault(tid, tuple(np.random.randint(0,255,3).tolist()))
            for j in range(1, len(pts)):
                pt1 = tuple(map(int, pts[j-1]))
                pt2 = tuple(map(int, pts[j]))
                cv2.line(overlay, pt1, pt2, color, 2)
            # Draw current point
            cv2.circle(overlay, tuple(map(int, pts[-1])), 4, color, -1)
        overlay = self.render_legend(overlay)
        return channels.with_channel(ChannelName("frame"), overlay)

    def render_legend(self, frame):
        # Draw legend for track trails
        h, w = frame.shape[:2]
        x0, y0 = 16, h - 56
        self.draw_text_with_bg(frame, "Feature Track Trails", (x0, y0), font_scale=0.7, color=None, thickness=1)
        return frame