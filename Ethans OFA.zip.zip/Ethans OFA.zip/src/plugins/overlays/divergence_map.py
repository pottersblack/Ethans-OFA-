"""
Divergence Map Overlay
Expansion/contraction of flow field.
"""
from .base_overlay import OverlayPlugin
import cv2
import numpy as np
from pipeline.types import ChannelName

class DivergenceMapOverlay(OverlayPlugin):
    id = "divergence_map"
    name = "Divergence Map"
    required_channels = (ChannelName("frame"), ChannelName("flow_uv"))
    provides_channels = (ChannelName("frame"),)

    def _run_overlay(self, frame_index, channels, config):
        frame = channels.get("frame")
        flow = channels.get("flow_uv")
        fx = flow[..., 0]
        fy = flow[..., 1]
        dfx_dx = np.gradient(fx, axis=1)
        dfy_dy = np.gradient(fy, axis=0)
        divergence = dfx_dx + dfy_dy
        div_norm = cv2.normalize(divergence, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        div_map = cv2.applyColorMap(div_norm, cv2.COLORMAP_TURBO)
        overlay = cv2.addWeighted(frame, 1.0, div_map, 0.65, 0)
        overlay = cv2.max(frame, overlay)
        overlay = self.render_legend(overlay)
        return channels.with_channel("frame", overlay)

    def render_legend(self, frame):
        h, w = frame.shape[:2]
        max_bar_w = max(4, w - 32)
        max_bar_h = max(1, h - 32)
        bar_h = min(16, max_bar_h)
        bar_w = min(160, max_bar_w)
        if bar_w <= 0 or bar_h <= 0:
            return frame
        bar = np.linspace(0, 255, bar_w).astype(np.uint8)
        bar_img = cv2.applyColorMap(bar[None, :], cv2.COLORMAP_TURBO)
        bar_img = cv2.resize(bar_img, (bar_w, bar_h), interpolation=cv2.INTER_LINEAR)
        y0, x0 = max(0, h - bar_h - 8), max(0, w - bar_w - 16)
        frame[y0:y0+bar_h, x0:x0+bar_w] = bar_img
        label_y = y0 + bar_h + 12
        if label_y < h:
            self.draw_text_with_bg(frame, "Low", (x0, label_y), font_scale=0.4, thickness=1, color=(255,255,255))
            self.draw_text_with_bg(frame, "High", (x0+bar_w-36, label_y), font_scale=0.4, thickness=1, color=(255,255,255))
            self.draw_text_with_bg(frame, "Divergence", (x0+bar_w//2-36, label_y), font_scale=0.4, thickness=1, color=(255,255,255))
        return frame