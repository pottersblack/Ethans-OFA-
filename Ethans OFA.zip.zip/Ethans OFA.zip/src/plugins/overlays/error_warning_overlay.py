"""
Error/Warning Overlay
Displays on-frame error/warning regions or pipeline status as a visual mask or icon overlay.
Shows VRAM, threshold, or pipeline errors as colored regions or icons.
"""
import numpy as np
import cv2
from .base_overlay import OverlayPlugin
from pipeline.types import ChannelName, RunConfig

class ErrorWarningOverlay(OverlayPlugin):
    id = "error_warning"
    name = "Error/Warning Overlay"
    required_channels = (ChannelName("frame"),)
    provides_channels = (ChannelName("frame"),)

    def __init__(self, opacity: float = 0.7):
        self.opacity = opacity

    def _run_overlay(self, frame_index, channels, config: RunConfig):
        frame = channels.get(ChannelName("frame"))
        error_mask = channels.get(ChannelName("error_mask")) if channels.has(ChannelName("error_mask")) else None
        error_list = channels.get(ChannelName("error_list")) if channels.has(ChannelName("error_list")) else []
        
        overlay = frame.copy()
        h, w = frame.shape[:2]
        
        # Draw error mask if present
        if error_mask is not None:
            mask_rgba = np.zeros((h, w, 4), dtype=np.uint8)
            mask_rgba[error_mask > 0] = [255, 0, 0, int(255 * self.opacity)]  # Red for error
            overlay = self._alpha_blend(overlay, mask_rgba)
        
        # Draw warning icons for each error in error_list
        if error_list:
            for err in error_list:
                if isinstance(err, dict) and "xy" in err:
                    x, y = err["xy"]
                    cv2.circle(overlay, (int(x), int(y)), 12, (0, 165, 255), -1)  # Orange warning
                    self.draw_text_with_bg(overlay, "!", (int(x)-7, int(y)+7), font_scale=0.7, color=None, thickness=1)
        
        # If no errors present, just show a status indicator
        if error_mask is None and not error_list:
            self.draw_text_with_bg(overlay, "No errors detected", (16, h - 24), 
                                    font_scale=0.5, color=(0, 255, 0), thickness=1)
        
        return channels.with_channel(ChannelName("frame"), overlay)

    def _alpha_blend(self, img, overlay_rgba):
        if overlay_rgba.shape[2] == 4:
            alpha = overlay_rgba[..., 3:4] / 255.0
            img = img.astype(np.float32)
            overlay_rgb = overlay_rgba[..., :3].astype(np.float32)
            out = img * (1 - alpha) + overlay_rgb * alpha
            return out.astype(np.uint8)
        return img

    def render_legend(self, frame):
        h, w = frame.shape[:2]
        self.draw_text_with_bg(frame, "Error/Warning Overlay Active", (16, 24), 
                                font_scale=0.5, color=None, thickness=1)
        return frame