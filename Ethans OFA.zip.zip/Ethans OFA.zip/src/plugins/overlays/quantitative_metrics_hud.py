"""
Quantitative Metrics HUD Overlay
Shows mean/max per frame/region as on-frame labels.
"""
from .base_overlay import OverlayPlugin
import cv2
import numpy as np
from pipeline.types import ChannelName, RunConfig

class QuantitativeMetricsHUDOverlay(OverlayPlugin):
    id = "quantitative_metrics_hud"
    name = "Quantitative Metrics HUD"
    required_channels = (ChannelName("frame"), ChannelName("flow_uv"))
    provides_channels = (ChannelName("frame"),)

    def _run_overlay(self, frame_index, channels, config: RunConfig):
        frame = channels.get(ChannelName("frame"))
        flow = channels.get(ChannelName("flow_uv"))
        mag = np.sqrt(flow[...,0]**2 + flow[...,1]**2)
        mean_mag = np.mean(mag)
        max_mag = np.max(mag)
        h, w = frame.shape[:2]
        out = frame.copy()
        self.draw_text_with_bg(out, f"Mean |V|: {mean_mag:.2f}", (16, 32), font_scale=0.8, color=None, thickness=1)
        self.draw_text_with_bg(out, f"Max |V|: {max_mag:.2f}", (16, 64), font_scale=0.8, color=None, thickness=1)
        # If region_mask is present, show per-region mean
        try:
            mask = channels.get(ChannelName("region_mask"))
            labels = np.unique(mask)
            for i, lbl in enumerate(labels):
                if lbl == 0:
                    continue
                region_mag = mag[mask == lbl]
                if region_mag.size == 0:
                    continue
                mean_region = np.mean(region_mag)
                self.draw_text_with_bg(out, f"Region {lbl}: {mean_region:.2f}", (16, 96+24*i), font_scale=0.7, color=(200,255,200), thickness=1)
        except Exception:
            pass
        out = self.render_legend(out)
        return channels.with_channel(ChannelName("frame"), out)

    def render_legend(self, frame):
        h, w = frame.shape[:2]
        x0, y0 = 16, h - 56
        self.draw_text_with_bg(frame, "Quantitative Metrics: |V|=flow mag", (x0, y0), font_scale=0.6, color=None, thickness=1)
        return frame