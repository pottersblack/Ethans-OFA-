from __future__ import annotations

import cv2
import numpy as np
from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from pipeline.channels import ChannelStore
from pipeline.types import ChannelName, Plugin, RunConfig

FRAME = ChannelName("frame")
FLOW_UV = ChannelName("flow_uv")

@dataclass(frozen=True)
class FlowVectorOverlay(Plugin):
    id: str = "overlay.vectors"
    name: str = "Flow Vector Overlay"
    required_channels: Sequence[ChannelName] = (FRAME, FLOW_UV)
    provides_channels: Sequence[ChannelName] = (FRAME,)

    def params_schema(self) -> Mapping[str, Any]:
        return {"step": {"type": "int", "default": 16, "description": "Grid step in pixels"}}

    def run(self, *, frame_index: int, channels: ChannelStore, config: RunConfig) -> ChannelStore:
        frame = channels.get(FRAME).copy()
        flow = channels.get(FLOW_UV)
        h, w = flow.shape[:2]
        step = 16  # Could be parameterized
        y, x = np.mgrid[step//2:h:step, step//2:w:step].astype(int)
        fx, fy = flow[y, x, 0], flow[y, x, 1]
        for (x0, y0, dx, dy) in zip(x.flat, y.flat, fx.flat, fy.flat):
            x1 = int(round(x0 + dx))
            y1 = int(round(y0 + dy))
            cv2.arrowedLine(frame, (x0, y0), (x1, y1), (0, 255, 0), 1, tipLength=0.3)
        return channels.with_channel(FRAME, frame)