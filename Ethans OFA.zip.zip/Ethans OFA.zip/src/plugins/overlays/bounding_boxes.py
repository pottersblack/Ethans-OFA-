"""
Bounding Boxes Overlay
Draws boxes around motion/turbulent regions.
"""
from .base_overlay import OverlayPlugin
import cv2
import numpy as np
from pipeline.types import ChannelName

class BoundingBoxesOverlay(OverlayPlugin):
    id = "bounding_boxes"
    name = "Bounding Boxes"
    required_channels = (ChannelName("frame"), ChannelName("region_mask"))
    provides_channels = (ChannelName("frame"),)

    def _run_overlay(self, frame_index, channels, config):
        frame = channels.get(ChannelName("frame"))
        mask = channels.get(ChannelName("region_mask"))
        overlay = frame.copy()
        labels = np.unique(mask)
        # Deterministic color mapping per label for consistent visuals
        def _color_for_label(lbl):
            base = np.array([37, 73, 151], dtype=np.int32)
            v = ((int(lbl) + 1) * base) % 256
            # ensure not pure black
            if np.all(v == 0):
                v = (v + 64) % 256
            return tuple(int(x) for x in v.tolist())
        color_map = {lbl: _color_for_label(lbl) for lbl in labels}
        for lbl in labels:
            ys, xs = np.where(mask == lbl)
            if ys.size == 0 or xs.size == 0:
                continue
            y0, y1 = ys.min(), ys.max()
            x0, x1 = xs.min(), xs.max()
            cv2.rectangle(overlay, (x0, y0), (x1, y1), color_map[lbl], 2, cv2.LINE_AA)
            # label with background for readability
            self.draw_text_with_bg(overlay, str(lbl), (x0, y0 - 4), font_scale=0.45, color=color_map[lbl], thickness=1)
        overlay = self.render_legend(overlay, color_map)
        return channels.with_channel(ChannelName("frame"), overlay)

    def render_legend(self, frame, color_map):
        # Draw color squares for each region label
        h, w = frame.shape[:2]
        x0, y0 = 16, h - 24
        for i, (lbl, color) in enumerate(color_map.items()):
            cv2.rectangle(frame, (x0 + i*32, y0), (x0 + i*32 + 24, y0 + 16), color, -1)
            self.draw_text_with_bg(frame, str(lbl), (x0 + i*32, y0-4), font_scale=0.5, thickness=1, color=(255,255,255))
        return frame