"""
Histogram Overlay
Shows scalar field distribution as an inset.
"""
from .base_overlay import OverlayPlugin
import cv2
import numpy as np
from pipeline.types import ChannelName, RunConfig

class HistogramOverlayOverlay(OverlayPlugin):
    id = "histogram_overlay"
    name = "Histogram Overlay"
    required_channels = (ChannelName("frame"), ChannelName("flow_uv"))
    provides_channels = (ChannelName("frame"),)

    def __init__(self, opacity: float = 0.7):
        self.opacity = opacity

    def _run_overlay(self, frame_index, channels, config: RunConfig):
        frame = channels.get(ChannelName("frame"))
        flow = channels.get(ChannelName("flow_uv"))
        mag = np.sqrt(flow[...,0]**2 + flow[...,1]**2)
        hist = cv2.calcHist([mag.astype(np.float32)], [0], None, [32], [0, np.max(mag)+1])
        hist = hist.flatten()
        hist_img = np.zeros((64, 128, 3), dtype=np.uint8)
        if np.max(hist) > 0:
            hist = hist / np.max(hist)
        for i in range(len(hist)):
            hval = int(hist[i] * 60)
            cv2.rectangle(hist_img, (i*4, 63-hval), (i*4+3, 63), (255,255,0), -1)
        # Place histogram as inset
        h, w = frame.shape[:2]
        x0, y0 = max(0, w-144), max(0, 8)
        roi_h = min(64, h - y0)
        roi_w = min(128, w - x0)
        if roi_h <= 0 or roi_w <= 0:
            out = frame.copy()
        else:
            roi = frame[y0:y0+roi_h, x0:x0+roi_w]
            hist_resized = cv2.resize(hist_img, (roi_w, roi_h), interpolation=cv2.INTER_AREA)
            blended = cv2.addWeighted(roi, 1.0-self.opacity, hist_resized, self.opacity, 0)
            out = frame.copy()
            out[y0:y0+roi_h, x0:x0+roi_w] = blended
        self.draw_text_with_bg(out, "|V| hist", (x0+8, y0+16), font_scale=0.5, color=None, thickness=1)
        out = self.render_legend(out)
        return channels.with_channel(ChannelName("frame"), out)

    def render_legend(self, frame):
        h, w = frame.shape[:2]
        x0, y0 = w-144, 80
        self.draw_text_with_bg(frame, "Histogram: |V|", (x0, y0), font_scale=0.5, color=None, thickness=1)
        return frame