from __future__ import annotations

import threading
import time
import platform
import ctypes
import os
from collections import OrderedDict
from typing import Any, Callable, Optional
import importlib.util

import numpy as np


class CacheEntry:
    __slots__ = ("payload", "size", "entry_type", "created_at", "last_access", "ttl")

    def __init__(self, payload: Any, size: int, entry_type: str = "detection", ttl: Optional[float] = None):
        self.payload = payload
        self.size = size
        self.entry_type = entry_type
        self.created_at = time.time()
        self.last_access = self.created_at
        self.ttl = ttl


class DetectionCache:
    """A simple size-aware LRU cache for numeric detection artifacts and downscaled frames.

    This implementation is intentionally small and safe for preview usage. It stores
    entries in-memory and evicts least-recently-used items when the total size exceeds
    `max_bytes`.
    """

    def __init__(self, max_bytes: int = 2 * 1024 ** 3, per_type_caps: Optional[dict] = None):
        self.max_bytes = int(max_bytes)
        self.per_type_caps = per_type_caps or {}
        self._lock = threading.RLock()
        self._map: "OrderedDict[str, CacheEntry]" = OrderedDict()
        self._total = 0
        self._inflight: dict[str, threading.Event] = {}
        # Remember user-requested cap so we can auto-throttle relative to system
        self._requested_max_bytes = int(max_bytes)

    # --- system helpers for auto-throttle ---
    @staticmethod
    def _get_system_memory():
        """Return (total_bytes, available_bytes). Tries psutil, falls back to platform APIs."""
        try:
            # Import psutil only if it's available; avoid static import errors in environments
            if importlib.util.find_spec("psutil") is not None:
                psutil = __import__("psutil")
                vm = psutil.virtual_memory()
                return int(vm.total), int(vm.available)
        except Exception:
            pass

        # Windows fallback
        try:
            if platform.system() == "Windows":
                class _MEMORYSTATUSEX(ctypes.Structure):
                    _fields_ = [("dwLength", ctypes.c_uint), ("dwMemoryLoad", ctypes.c_uint), ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong), ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong), ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong), ("sullAvailExtendedVirtual", ctypes.c_ulonglong)]

                stat = _MEMORYSTATUSEX()
                stat.dwLength = ctypes.sizeof(_MEMORYSTATUSEX)
                ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat))
                return int(stat.ullTotalPhys), int(stat.ullAvailPhys)
        except Exception:
            pass

        # POSIX fallback
        try:
            if hasattr(os, 'sysconf'):
                pages = os.sysconf('SC_PHYS_PAGES')
                page_size = os.sysconf('SC_PAGE_SIZE')
                total = pages * page_size
                # Available is trickier; approximate with free + cached if available
                if os.path.exists('/proc/meminfo'):
                    with open('/proc/meminfo', 'r', encoding='utf-8') as fh:
                        meminfo = fh.read()
                    def _find(k):
                        for line in meminfo.splitlines():
                            if line.startswith(k):
                                return int(line.split()[1]) * 1024
                        return 0
                    free = _find('MemAvailable:') or _find('MemFree:')
                    return int(total), int(free)
        except Exception:
            pass

        # Conservative fallback
        return (8 * 1024 ** 3, 1 * 1024 ** 3)

    def adjust_for_system(self, min_reserved_mb: int = 2048):
        """Adjust `self.max_bytes` so that at least `min_reserved_mb` are kept free on the system.

        If available memory is low, this will reduce the cache size; if plenty of RAM
        is free, it will restore up to the originally requested cap.
        """
        try:
            _total, avail = self._get_system_memory()
            min_reserved = int(min_reserved_mb) * 1024 ** 2
            # Compute safe budget: ensure after allocating cache we still have min_reserved free
            safe_budget = max(0, avail - min_reserved)
            # Allow up to requested cap but not more than safe_budget
            new_cap = min(self._requested_max_bytes, safe_budget) if safe_budget > 0 else 0
            # Soft cap: never set below 64MB unless forced
            if new_cap == 0:
                new_cap = 0
            elif new_cap < 64 * 1024 ** 2:
                new_cap = 64 * 1024 ** 2

            with self._lock:
                if new_cap != self.max_bytes:
                    self.max_bytes = int(new_cap)
                    # Evict if necessary
                    self._evict_if_needed_nolock()
            return True
        except Exception:
            return False

    # --- basic ops ---
    def get(self, key: str) -> Optional[Any]:
        with self._lock:
            e = self._map.get(key)
            if e is None:
                return None
            # TTL check
            if e.ttl is not None and (time.time() - e.created_at) > e.ttl:
                self._delete_nolock(key)
                return None
            e.last_access = time.time()
            # move to end (most recent)
            self._map.move_to_end(key)
            return e.payload

    def set(self, key: str, payload: Any, size_bytes: Optional[int] = None, entry_type: str = "detection", ttl: Optional[float] = None):
        size = int(size_bytes) if size_bytes is not None else self.estimate_size(payload)
        with self._lock:
            if key in self._map:
                self._delete_nolock(key)
            e = CacheEntry(payload=payload, size=size, entry_type=entry_type, ttl=ttl)
            self._map[key] = e
            self._total += size
            self._map.move_to_end(key)
            self._evict_if_needed_nolock()

    def get_or_compute(self, key: str, compute_fn: Callable[[], Any], entry_type: str = "detection", ttl: Optional[float] = None) -> Any:
        # Fast path
        existing = self.get(key)
        if existing is not None:
            return existing

        # Single-flight: if another thread is computing, wait on its event
        with self._lock:
            if key in self._inflight:
                ev = self._inflight[key]
        if key in self._inflight:
            # wait for the compute to finish
            ev.wait()
            return self.get(key)

        # We will compute
        ev = threading.Event()
        with self._lock:
            self._inflight[key] = ev

        try:
            payload = compute_fn()
            size = self.estimate_size(payload)
            with self._lock:
                # store only if still missing
                if key not in self._map:
                    self.set(key, payload, size_bytes=size, entry_type=entry_type, ttl=ttl)
        finally:
            with self._lock:
                ev.set()
                if key in self._inflight:
                    del self._inflight[key]

        return self.get(key)

    def touch(self, key: str):
        with self._lock:
            e = self._map.get(key)
            if e:
                e.last_access = time.time()
                self._map.move_to_end(key)

    def invalidate(self, prefix_or_key: str):
        with self._lock:
            keys = list(self._map.keys())
            for k in keys:
                if k == prefix_or_key or k.startswith(prefix_or_key):
                    self._delete_nolock(k)

    def clear(self):
        with self._lock:
            self._map.clear()
            self._total = 0

    # --- internal helpers ---
    def _delete_nolock(self, key: str):
        e = self._map.pop(key, None)
        if e is not None:
            self._total -= e.size

    def _evict_if_needed_nolock(self):
        # Evict until under budget
        while self._total > self.max_bytes and self._map:
            # pop oldest
            _, e = self._map.popitem(last=False)
            self._total -= e.size

    def estimate_size(self, item: Any) -> int:
        # NumPy arrays -> nbytes
        try:
            if isinstance(item, np.ndarray):
                return int(item.nbytes * 1.1)
        except Exception:
            pass
        # Strings/bytes
        if isinstance(item, (bytes, bytearray)):
            return len(item)
        if isinstance(item, str):
            return len(item.encode("utf-8"))
        # Lists/dicts: rough estimate via repr
        try:
            return len(repr(item).encode("utf-8"))
        except Exception:
            return 1024


# Global default cache instance and helpers
_GLOBAL_CACHE: Optional[DetectionCache] = None


def get_global_cache() -> Optional[DetectionCache]:
    # Return the currently configured global cache instance, or None if caching
    # has been explicitly disabled by `set_global_cache(None)`.
    return _GLOBAL_CACHE


def set_global_cache(cache: Optional[DetectionCache]) -> None:
    # Intentionally use a module-global to hold the cache singleton.
    global _GLOBAL_CACHE  # pylint: disable=W0603
    _GLOBAL_CACHE = cache
