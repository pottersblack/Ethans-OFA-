"""
Detection Silhouette Panel Overlay
Shows a clean white panel next to the video with simplified black/colored outlines
or filled shadows of detected particles, bubbles, and motion regions.
Makes detection data more interpretable by removing visual clutter.
"""
import cv2
import numpy as np
from .base_overlay import OverlayPlugin
from pipeline.types import ChannelName, RunConfig


class DetectionSilhouettePanelOverlay(OverlayPlugin):
    id = "detection_silhouette_panel"
    name = "Detection Silhouette Panel"
    required_channels = (ChannelName("frame"),)
    provides_channels = (ChannelName("frame"),)

    def __init__(self, panel_position: str = "right", panel_width_ratio: float = 1.0,
                 style: str = "outline", colored: bool = False, background: str = "white"):
        """
        Args:
            panel_position: "right" or "left" - where to place the silhouette panel
            panel_width_ratio: ratio of panel width to video width (default 1.0 = same size)
            style: "outline" or "filled" - draw outlines or filled shadows
            colored: if True, use colors; if False, use black
            background: "white", "black", or "gray" for panel background
        """
        self.panel_position = panel_position
        self.panel_width_ratio = max(0.1, min(panel_width_ratio, 1.0))
        self.style = style
        self.colored = colored
        self.background = background

    def _run_overlay(self, frame_index, channels, config: RunConfig):
        frame = channels.get(ChannelName("frame"))
        h, w = frame.shape[:2]
        
        # Determine panel dimensions
        panel_w = int(w * self.panel_width_ratio)
        panel_h = h
        
        # Create panel background
        bg_colors = {
            "white": (255, 255, 255),
            "black": (0, 0, 0),
            "gray": (200, 200, 200)
        }
        bg_color = bg_colors.get(self.background, (255, 255, 255))
        panel = np.full((panel_h, panel_w, 3), bg_color, dtype=np.uint8)
        
        # Collect detections from available channels
        detections = self._collect_detections(channels, frame.shape)
        
        # Draw detections on panel
        if detections:
            self._draw_detections_on_panel(panel, detections, (h, w))
        
        # Add label
        self.draw_text_with_bg(panel, "Detections", (10, 24), 
                                font_scale=0.6, color=(0, 0, 0) if bg_color[0] > 127 else (255, 255, 255), 
                                thickness=2)
        
        # Combine frame and panel
        if self.panel_position == "right":
            combined = np.hstack([frame, panel])
        else:  # left
            combined = np.hstack([panel, frame])
        
        return channels.with_channel(ChannelName("frame"), combined)

    def _collect_detections(self, channels, frame_shape):
        """Collect all available detection data from channels."""
        detections = []
        h, w = frame_shape[:2]
        
        # Priority 1: Particle tracks (most accurate)
        if channels.has(ChannelName("tracks")):
            tracks = channels.get(ChannelName("tracks"))
            for track in tracks:
                pts = track.get("pts", [])
                if pts:
                    # Get current position and create a circular detection
                    x, y = pts[-1]
                    color = self._get_color_for_track(track.get("id", 0))
                    detections.append({
                        "type": "circle",
                        "center": (int(x), int(y)),
                        "radius": 8,
                        "color": color,
                        "label": f"T{track.get('id', 0)}"
                    })
        
        # Priority 2: Region mask (connected components)
        elif channels.has(ChannelName("region_mask")):
            mask = channels.get(ChannelName("region_mask"))
            labels = np.unique(mask)
            for lbl in labels:
                if lbl == 0:  # Skip background
                    continue
                ys, xs = np.where(mask == lbl)
                if ys.size > 0:
                    # Get bounding box
                    y0, y1 = ys.min(), ys.max()
                    x0, x1 = xs.min(), xs.max()
                    color = self._get_color_for_label(lbl)
                    detections.append({
                        "type": "rect",
                        "bbox": (x0, y0, x1, y1),
                        "color": color,
                        "label": f"R{lbl}"
                    })
        
        # Priority 3: Flow magnitude (high-motion areas)
        elif channels.has(ChannelName("flow_uv")):
            flow = channels.get(ChannelName("flow_uv"))
            mag = np.sqrt(flow[..., 0]**2 + flow[..., 1]**2)
            
            # Threshold to find significant motion
            threshold = np.percentile(mag, 85)  # Top 15% motion
            binary = (mag > threshold).astype(np.uint8) * 255
            
            # Find contours
            contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            for i, cnt in enumerate(contours):
                area = cv2.contourArea(cnt)
                if area < 20:  # Skip tiny regions
                    continue
                x, y, cw, ch = cv2.boundingRect(cnt)
                color = self._get_color_for_label(i)
                detections.append({
                    "type": "contour",
                    "contour": cnt,
                    "bbox": (x, y, x+cw, y+ch),
                    "color": color,
                    "label": f"M{i}"
                })
        
        return detections

    def _draw_detections_on_panel(self, panel, detections, original_shape):
        """Draw simplified detection shapes on the panel."""
        h_orig, w_orig = original_shape
        h_panel, w_panel = panel.shape[:2]
        
        # Scale factor to fit original frame into panel
        scale_x = w_panel / w_orig
        scale_y = h_panel / h_orig
        
        for det in detections:
            color = det["color"] if self.colored else (0, 0, 0)
            
            if det["type"] == "circle":
                # Draw particle as circle
                cx, cy = det["center"]
                cx_scaled = int(cx * scale_x)
                cy_scaled = int(cy * scale_y)
                radius = max(3, int(det["radius"] * min(scale_x, scale_y)))
                
                if self.style == "filled":
                    cv2.circle(panel, (cx_scaled, cy_scaled), radius, color, -1)
                else:
                    cv2.circle(panel, (cx_scaled, cy_scaled), radius, color, 2)
                
                # Optionally add label
                if len(detections) < 50:  # Don't label if too many
                    label_pos = (cx_scaled + radius + 3, cy_scaled + 5)
                    cv2.putText(panel, det["label"], label_pos, cv2.FONT_HERSHEY_SIMPLEX,
                                0.35, color, 1, cv2.LINE_AA)
            
            elif det["type"] == "rect":
                # Draw region as rectangle
                x0, y0, x1, y1 = det["bbox"]
                x0_s = int(x0 * scale_x)
                y0_s = int(y0 * scale_y)
                x1_s = int(x1 * scale_x)
                y1_s = int(y1 * scale_y)
                
                if self.style == "filled":
                    cv2.rectangle(panel, (x0_s, y0_s), (x1_s, y1_s), color, -1)
                else:
                    cv2.rectangle(panel, (x0_s, y0_s), (x1_s, y1_s), color, 2)
                
                # Add label
                if len(detections) < 30:
                    label_pos = (x0_s + 2, y0_s + 12)
                    cv2.putText(panel, det["label"], label_pos, cv2.FONT_HERSHEY_SIMPLEX,
                                0.4, color, 1, cv2.LINE_AA)
            
            elif det["type"] == "contour":
                # Draw contour outline
                contour = det["contour"]
                contour_scaled = (contour * [scale_x, scale_y]).astype(np.int32)
                
                if self.style == "filled":
                    cv2.drawContours(panel, [contour_scaled], -1, color, -1)
                else:
                    cv2.drawContours(panel, [contour_scaled], -1, color, 2)

    def _get_color_for_track(self, track_id):
        """Generate consistent color for a track ID."""
        if not self.colored:
            return (0, 0, 0)
        np.random.seed(track_id)
        return tuple(np.random.randint(50, 255, 3).tolist())

    def _get_color_for_label(self, label):
        """Generate consistent color for a region label."""
        if not self.colored:
            return (0, 0, 0)
        np.random.seed(int(label) + 1000)
        return tuple(np.random.randint(50, 255, 3).tolist())

    def render_legend(self, frame):
        """Optional: could add legend explaining colors/shapes."""
        return frame
