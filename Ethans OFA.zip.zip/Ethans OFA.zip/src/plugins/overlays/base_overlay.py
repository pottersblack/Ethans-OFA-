"""
Base class and utilities for overlay plugins.
All overlays must inherit from this and implement render_overlay().
"""
"""Overlay helpers (drawing utilities).

Pylint/type-checkers sometimes can't see OpenCV's runtime members; disable that
check for this module so CV2 drawing calls don't raise false positives.
"""
# pylint: disable=E1101
from pipeline.types import Plugin, RunConfig
from pipeline.channels import ChannelStore
from typing import Any
import cv2
import numpy as np
from .detection_cache import get_global_cache

class OverlayPlugin(Plugin):
    legend_required: bool = True
    # Centralized palettes
    PALETTES = {
        "dark": {
            "text": (255, 255, 255),
            "bg": (0, 0, 0),
            "accent": (29, 101, 199),
        },
        "light": {
            "text": (0, 0, 0),
            "bg": (255, 255, 255),
            "accent": (37, 73, 151),
        },
    }
    def render_legend(self, frame):
        """Render a legend/colorbar/label on the frame (optional, override if needed)."""
        return frame

    def run(self, *, frame_index: int, channels: ChannelStore, config: RunConfig) -> ChannelStore:
        # Set theme/palette from config for helpers
        self._theme = getattr(config, "theme", "dark") or "dark"
        self._palette = self.PALETTES.get(self._theme, self.PALETTES["dark"])
        # Provide overlays access to global preview cache (may be None)
        try:
            self._cache = get_global_cache()
        except Exception:
            self._cache = None
        # Let exceptions propagate so they're visible during debugging
        return self._run_overlay(frame_index=frame_index, channels=channels, config=config)

    def _run_overlay(self, frame_index: int, channels: ChannelStore, config: RunConfig) -> ChannelStore:
        raise NotImplementedError

    # --- Drawing helpers for overlays ---
    def draw_text_with_bg(self, frame, text: str, pos: tuple[int, int], font_scale: float = 0.5, color=(255,255,255), thickness: int = 1):
        x, y = pos
        font = cv2.FONT_HERSHEY_SIMPLEX
        (tw, th), _ = cv2.getTextSize(text, font, font_scale, thickness)
        # Background rectangle for contrast
        pad = 4
        x0, y0 = max(0, x - pad), max(0, y - th - pad)
        x1, y1 = min(frame.shape[1], x + tw + pad), min(frame.shape[0], y + pad)
        bg_color = getattr(self, "_palette", self.PALETTES["dark"])["bg"]
        text_color = color if color is not None else getattr(self, "_palette", self.PALETTES["dark"])["text"]
        cv2.rectangle(frame, (x0, y0), (x1, y1), tuple(map(int, bg_color)), -1)
        cv2.putText(frame, text, (x, y), font, font_scale, tuple(map(int, text_color)), thickness, cv2.LINE_AA)
        return frame

    def draw_colorbar(self, frame, colormap=cv2.COLORMAP_JET, bar_w: int = 200, bar_h: int = 24, position: str = "bottomright", label: str | None = None):
        h, w = frame.shape[:2]
        max_bar_w = max(4, w - 32)
        max_bar_h = max(1, h - 32)
        bar_h = min(bar_h, max_bar_h)
        bar_w = min(bar_w, max_bar_w)
        if bar_w <= 0 or bar_h <= 0:
            return frame
        bar = np.linspace(0, 255, bar_w).astype(np.uint8)
        bar_img = cv2.applyColorMap(bar[None, :], colormap)
        bar_img = cv2.resize(bar_img, (bar_w, bar_h), interpolation=cv2.INTER_LINEAR)
        if position == "bottomright":
            y0, x0 = max(0, h - bar_h - 12), max(0, w - bar_w - 16)
        elif position == "topleft":
            y0, x0 = 12, 16
        else:
            y0, x0 = max(0, h - bar_h - 12), max(0, w - bar_w - 16)
        frame[y0:y0+bar_h, x0:x0+bar_w] = bar_img
        if label is not None:
            ly = y0 + bar_h + 14
            if ly < h:
                self.draw_text_with_bg(frame, label, (x0 + 4, ly), font_scale=0.45, color=None, thickness=1)
        return frame