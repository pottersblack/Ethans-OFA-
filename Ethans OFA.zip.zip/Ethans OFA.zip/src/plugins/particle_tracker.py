"""Simple particle/bubble tracker plugin with optional CUDA preprocessing.

This plugin is intentionally lightweight: it detects bright blobs via
thresholding + contour centroiding, then links detections across frames
using nearest-neighbor assignment to produce simple `tracks` channel.

If `config.device == 'cuda'` and OpenCV CUDA is available, it will use
`cv2.cuda` for Gaussian blur and thresholding to demonstrate device-aware
paths. All heavy operations are guarded with try/except to fall back to CPU.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence, Mapping, Any

import cv2
import numpy as np
try:
    from scipy.optimize import linear_sum_assignment
    _HAS_SCIPY = True
except Exception:
    _HAS_SCIPY = False

from pipeline.types import Plugin, ChannelName, RunConfig
from pipeline.channels import ChannelStore


FRAME = ChannelName("frame")
PREV_FRAME = ChannelName("prev_frame")
TRACKS = ChannelName("tracks")


@dataclass
class ParticleTrackerPlugin(Plugin):
    id: str = "tracker.particles"
    name: str = "Particle/Bubble Tracker"
    required_channels: Sequence[ChannelName] = (FRAME,)
    provides_channels: Sequence[ChannelName] = (TRACKS,)

    def __init__(self, max_history: int = 16, max_dist: float = 24.0, use_kalman: bool = True, process_var: float = 1.0, meas_var: float = 4.0):
        self.max_history = max_history
        self.max_dist = max_dist
        self._next_id = 1
        # active tracks: id -> {'pts': [(x,y), ...], 'last_seen': frame_index}
        self._active: dict[int, dict] = {}
        self._use_kalman = bool(use_kalman)
        # Kalman states: id -> dict(state vector 'x' and covariance 'P')
        self._kalman: dict[int, dict] = {}
        # Kalman noise parameters
        self._proc_var = float(process_var)
        self._meas_var = float(meas_var)

    def _kalman_matrices(self, dt: float = 1.0):
        # State: [x, y, vx, vy]
        F = np.array([[1, 0, dt, 0], [0, 1, 0, dt], [0, 0, 1, 0], [0, 0, 0, 1]], dtype=float)
        q = self._proc_var
        # Process noise covariance (simple model)
        Q = q * np.array([[dt**4/4, 0, dt**3/2, 0], [0, dt**4/4, 0, dt**3/2], [dt**3/2, 0, dt**2, 0], [0, dt**3/2, 0, dt**2]], dtype=float)
        # Measurement model: position only
        H = np.array([[1, 0, 0, 0], [0, 1, 0, 0]], dtype=float)
        R = (self._meas_var) * np.eye(2, dtype=float)
        return F, Q, H, R

    def _kalman_predict(self, tid: int, dt: float = 1.0):
        F, Q, H, R = self._kalman_matrices(dt)
        s = self._kalman[tid]
        x = np.asarray(s["x"], dtype=float)
        P = np.asarray(s.get("P", np.eye(4) * 500.0), dtype=float)
        x_pred = F.dot(x)
        P_pred = F.dot(P).dot(F.T) + Q
        s["x"] = x_pred.tolist()
        s["P"] = P_pred.tolist()
        return x_pred, P_pred

    def _kalman_update(self, tid: int, meas: np.ndarray):
        F, Q, H, R = self._kalman_matrices()
        s = self._kalman[tid]
        x_pred = np.asarray(s["x"], dtype=float)
        P_pred = np.asarray(s["P"], dtype=float)
        z = np.asarray(meas, dtype=float)
        y = z - H.dot(x_pred)
        S = H.dot(P_pred).dot(H.T) + R
        K = P_pred.dot(H.T).dot(np.linalg.inv(S))
        x_upd = x_pred + K.dot(y)
        P_upd = (np.eye(4) - K.dot(H)).dot(P_pred)
        s["x"] = x_upd.tolist()
        s["P"] = P_upd.tolist()
        return x_upd, P_upd

    def params_schema(self) -> Mapping[str, Any]:
        return {}

    def run(self, *, frame_index: int, channels: ChannelStore, config: RunConfig) -> ChannelStore:
        frame = channels.get(FRAME)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        use_cuda = getattr(config, "device", "auto") == "cuda"
        thresh = None
        if use_cuda:
            try:
                if hasattr(cv2, "cuda") and cv2.cuda.getCudaEnabledDeviceCount() > 0:
                    g = cv2.cuda_GpuMat()
                    g.upload(gray)
                    g = cv2.cuda_GaussianBlur(g, (7, 7), 1.5)
                    _, gth = cv2.cuda.threshold(g, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
                    thresh = gth.download()
            except Exception:
                thresh = None

        if thresh is None:
            # CPU fallback: blur + thresholding
            blur = cv2.GaussianBlur(gray, (7, 7), 1.5)
            
            # Accuracy boost: adaptive threshold instead of global Otsu
            if config.adaptive_threshold:
                thresh = cv2.adaptiveThreshold(
                    blur, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                    cv2.THRESH_BINARY, blockSize=11, C=2
                )
            else:
                _, thresh = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

        # Find contours and centroids
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        detections: list[tuple[int, int]] = []
        for c in contours:
            area = cv2.contourArea(c)
            if area < 4.0:
                continue
            M = cv2.moments(c)
            if M.get("m00", 0) == 0:
                continue
            cx = int(M["m10"] / M["m00"])
            cy = int(M["m01"] / M["m00"])
            detections.append((cx, cy))

        # Assignment: construct detection points and try global assignment
        unmatched = set(range(len(detections)))
        det_pts = [np.array(d, dtype=float) for d in detections]

        # Build list of track ids and their predicted positions.
        # If Kalman is enabled, run predict for each state and use the predicted position.
        track_ids = list(self._active.keys())
        preds = []
        if self._use_kalman:
            for tid in track_ids:
                if tid in self._kalman:
                    x_pred, _ = self._kalman_predict(tid)
                    preds.append(np.array([x_pred[0], x_pred[1]], dtype=float))
                else:
                    last_pt = np.array(self._active[tid]["pts"][-1], dtype=float)
                    preds.append(last_pt)
        else:
            for tid in track_ids:
                last_pt = np.array(self._active[tid]["pts"][-1], dtype=float)
                preds.append(last_pt)

        # If scipy is available, run Hungarian (linear_sum_assignment) for global optimal matching
        if det_pts and preds and _HAS_SCIPY:
            cost = np.zeros((len(preds), len(det_pts)), dtype=float)
            for i, p in enumerate(preds):
                for j, d in enumerate(det_pts):
                    cost[i, j] = np.linalg.norm(p - d)
            row_ind, col_ind = linear_sum_assignment(cost)
            for r, c in zip(row_ind, col_ind):
                if cost[r, c] <= self.max_dist:
                    tid = track_ids[r]
                    self._active[tid]["pts"].append(tuple(map(float, det_pts[c].tolist())))
                    self._active[tid]["last_seen"] = frame_index
                    if len(self._active[tid]["pts"]) > self.max_history:
                        self._active[tid]["pts"] = self._active[tid]["pts"][-self.max_history:]
                    # update kalman if present (full update step)
                    if self._use_kalman:
                        if tid not in self._kalman:
                            x, y = det_pts[c]
                            self._kalman[tid] = {"x": [float(x), float(y), 0.0, 0.0], "P": (np.eye(4) * 500.0).tolist()}
                        # perform Kalman update with measurement
                        self._kalman[tid]["P"] = self._kalman.get(tid, {}).get("P", (np.eye(4) * 500.0).tolist())
                        self._kalman_update(tid, det_pts[c])
                    unmatched.discard(c)
        else:
            # Fallback: if kalman predictions exist, greedily match them first
            if self._use_kalman and self._kalman:
                preds_map = {}
                for tid, k in self._kalman.items():
                    x, y, vx, vy = k["x"]
                    preds_map[tid] = np.array([x + vx, y + vy], dtype=float)
                for tid, pred in preds_map.items():
                    if not unmatched:
                        break
                    best_i = None
                    best_d = float("inf")
                    for i in list(unmatched):
                        d = np.linalg.norm(det_pts[i] - pred)
                        if d < best_d:
                            best_d = d
                            best_i = i
                    if best_i is not None and best_d <= self.max_dist:
                        self._active[tid]["pts"].append(tuple(map(float, det_pts[best_i].tolist())))
                        self._active[tid]["last_seen"] = frame_index
                        if len(self._active[tid]["pts"]) > self.max_history:
                            self._active[tid]["pts"] = self._active[tid]["pts"][-self.max_history:]
                        # Update kalman state
                        self._kalman[tid]["x"][0:2] = det_pts[best_i].tolist()
                        self._kalman[tid]["x"][2:4] = (det_pts[best_i] - pred).tolist()
                        unmatched.remove(best_i)

            # Final fallback: greedy NN for remaining tracks
            for tid, tr in list(self._active.items()):
                if not unmatched:
                    break
                last_pt = np.array(tr["pts"][-1], dtype=float)
                best_i = None
                best_d = float("inf")
                for i in list(unmatched):
                    d = np.linalg.norm(det_pts[i] - last_pt)
                    if d < best_d:
                        best_d = d
                        best_i = i
                if best_i is not None and best_d <= self.max_dist:
                    self._active[tid]["pts"].append(tuple(map(float, det_pts[best_i].tolist())))
                    self._active[tid]["last_seen"] = frame_index
                    if len(self._active[tid]["pts"]) > self.max_history:
                        self._active[tid]["pts"] = self._active[tid]["pts"][-self.max_history:]
                    unmatched.remove(best_i)

        # Create new tracks for remaining detections
        for i in sorted(unmatched):
            tid = self._next_id
            self._next_id += 1
            self._active[tid] = {"pts": [tuple(map(float, det_pts[i].tolist()))], "last_seen": frame_index}
            # initialize kalman state
            if self._use_kalman:
                x, y = det_pts[i]
                self._kalman[tid] = {"x": [float(x), float(y), 0.0, 0.0]}

        # Prune tracks not seen recently
        stale = [tid for tid, tr in self._active.items() if frame_index - tr.get("last_seen", frame_index) > self.max_history]
        for tid in stale:
            del self._active[tid]

        # Build tracks list in the expected format
        tracks_list = []
        for tid, tr in self._active.items():
            tracks_list.append({"id": int(tid), "pts": [(float(x), float(y)) for (x, y) in tr["pts"]], "type": "particle"})

        return channels.with_channel(TRACKS, tracks_list)
