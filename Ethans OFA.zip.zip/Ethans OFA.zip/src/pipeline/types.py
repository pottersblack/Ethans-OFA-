from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Mapping, NewType, Sequence


ChannelName = NewType("ChannelName", str)


class Mode(str, Enum):
    PREVIEW = "preview"
    EXPORT = "export"


class Scenario(str, Enum):
    SMOKE_AIRFLOW = "smoke_airflow"
    WATER_TURBULENCE = "water_turbulence"
    BUBBLES = "bubbles"
    PARTICLES = "particles"


@dataclass(frozen=True)
class RunConfig:
    mode: Mode
    scenario: Scenario

    # Preferred compute device: 'auto', 'cpu', or 'cuda'
    device: str = "auto"

    # Preview-only knobs (must not leak into Export behavior)
    preview_downscale: float = 1.0
    preview_fps_cap: float | None = None
    preview_frame_skip: int = 0
    # Visual theme for overlays: 'dark' or 'light'
    theme: str = "dark"
    
    # Accuracy boosting options (work in both Preview and Export)
    high_quality_flow: bool = False      # Use full resolution + more iterations
    temporal_smoothing: bool = False      # Apply temporal filtering to reduce noise
    subpixel_refinement: bool = False     # Enable subpixel accuracy in flow
    adaptive_threshold: bool = False      # Use adaptive thresholding for particle detection



class Plugin:
    """
    Base plugin contract for pipeline nodes.
    Plugins declare required and provided channels, and implement run().
    Plugins must not mutate upstream data; all outputs are new channels.
    """
    id: str
    name: str
    required_channels: Sequence[ChannelName] = ()
    provides_channels: Sequence[ChannelName] = ()

    def params_schema(self) -> Mapping[str, Any]:
        """Return a schema for plugin parameters (for UI/config)."""
        return {}

    def preview_downgrade(self, config: RunConfig) -> RunConfig:
        """Return a downgraded config for Preview mode (e.g., lower res/fps)."""
        return config

    def export_requirements(self, config: RunConfig) -> Sequence[str]:
        """Return warnings if Export requirements are not met (e.g., needs full-res flow)."""
        return ()

    def run(self, *, frame_index: int, channels: "ChannelStore", config: RunConfig) -> "ChannelStore":
        """Run plugin logic for a single frame. Must return a new ChannelStore with new outputs."""
        raise NotImplementedError("Plugin must implement run()")
