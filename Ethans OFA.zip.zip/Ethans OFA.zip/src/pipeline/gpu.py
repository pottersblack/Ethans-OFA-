"""GPU detection helpers.

Provides a lightweight `check_gpu()` that attempts to detect CUDA-capable
devices using common backends (`torch`, `cv2.cuda`) and `nvidia-smi` when
available. Designed to be safe on systems without GPU libraries installed.
"""
from __future__ import annotations

import os
import shutil
import subprocess
from typing import Any


def check_gpu() -> dict[str, Any]:
    info: dict[str, Any] = {
        "cuda_available": False,
        "torch": False,
        "cv2_cuda": False,
        "device_count": 0,
        "devices": [],
        "nvidia_smi": None,
    }

    # Allow CI to opt out of running real hardware probes. Set
    # `SKIP_REAL_HW_PROBE=1` in CI to skip `nvidia-smi` and other
    # expensive/unsafe probes.
    if os.environ.get("SKIP_REAL_HW_PROBE") in ("1", "true", "True"):
        info["nvidia_smi"] = "skipped"
        return info

    # torch (if installed)
    try:
        import torch

        info["torch"] = True
        try:
            if torch.cuda.is_available():
                info["cuda_available"] = True
                n = torch.cuda.device_count()
                info["device_count"] = max(info["device_count"], n)
                for i in range(n):
                    try:
                        name = torch.cuda.get_device_name(i)
                    except Exception:
                        name = f"cuda:{i}"
                    props = None
                    try:
                        props = torch.cuda.get_device_properties(i)
                    except Exception:
                        props = None
                    mem = getattr(props, "total_memory", None) if props is not None else None
                    info["devices"].append({"backend": "torch", "index": i, "name": name, "memory_bytes": mem})
        except Exception:
            pass
    except Exception:
        pass

    # OpenCV cuda (if available)
    try:
        import cv2

        if hasattr(cv2, "cuda"):
            try:
                cnt = cv2.cuda.getCudaEnabledDeviceCount()
                if isinstance(cnt, int) and cnt > 0:
                    info["cv2_cuda"] = True
                    info["cuda_available"] = True
                    info["device_count"] = max(info["device_count"], cnt)
                    for i in range(cnt):
                        info["devices"].append({"backend": "cv2", "index": i, "name": f"cuda:{i}", "memory_bytes": None})
            except Exception:
                pass
    except Exception:
        pass

    # nvidia-smi probe for additional details (if available)
    if shutil.which("nvidia-smi"):
        try:
            res = subprocess.run([
                "nvidia-smi",
                "--query-gpu=index,name,memory.total,driver_version",
                "--format=csv,noheader,nounits",
            ], capture_output=True, text=True, check=True)
            out = res.stdout.strip()
            info["nvidia_smi"] = out
            lines = [l for l in out.splitlines() if l.strip()]
            info["device_count"] = max(info["device_count"], len(lines))
            for line in lines:
                parts = [p.strip() for p in line.split(",")]
                if len(parts) >= 3:
                    idx = int(parts[0])
                    name = parts[1]
                    try:
                        mem_mb = int(parts[2])
                        mem_bytes = mem_mb * 1024 * 1024
                    except Exception:
                        mem_bytes = None
                    info["devices"].append({"backend": "nvidia-smi", "index": idx, "name": name, "memory_bytes": mem_bytes})
        except Exception:
            pass

    return info


def pretty_print_gpu_info(info: dict[str, Any]) -> None:
    print("GPU probe:")
    print(f"  CUDA available: {info.get('cuda_available')}")
    print(f"  torch support: {info.get('torch')}, cv2.cuda: {info.get('cv2_cuda')}")
    print(f"  Detected device count: {info.get('device_count')}")
    for d in info.get("devices", []):
        name = d.get("name")
        mem = d.get("memory_bytes")
        mem_str = f"{mem//(1024*1024)} MB" if isinstance(mem, int) else "unknown"
        print(f"    - [{d.get('backend')}] idx={d.get('index')} name={name} mem={mem_str}")
