"""Pipeline core (channels + plugin execution)."""
