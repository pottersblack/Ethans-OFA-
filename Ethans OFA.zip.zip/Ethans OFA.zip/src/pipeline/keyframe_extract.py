"""
Key frame extraction utilities - save selected frames to disk.
"""
from __future__ import annotations

from pathlib import Path
import cv2
import numpy as np

from .keyframe_capture import FrameScore


def extract_keyframes_to_dir(
    input_video: Path,
    keyframe_indices: list[int],
    output_dir: Path,
    frame_scores: list[FrameScore] | None = None,
) -> list[Path]:
    """
    Extract key frames from video and save to output directory.
    
    Args:
        input_video: Path to input video file
        keyframe_indices: List of frame indices to extract
        output_dir: Directory to save extracted frames
        frame_scores: Optional list of FrameScore objects for naming/info
        
    Returns:
        List of paths to saved frame files
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    cap = cv2.VideoCapture(str(input_video))
    if not cap.isOpened():
        raise RuntimeError(f"Failed to open video: {input_video}")
    
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    
    # Create a lookup for scores if provided
    score_map = {}
    if frame_scores:
        score_map = {fs.frame_index: fs for fs in frame_scores}
    
    saved_paths = []
    sorted_indices = sorted(set(keyframe_indices))
    
    current_frame_idx = 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        
        if current_frame_idx in sorted_indices:
            # Prepare filename
            fs = score_map.get(current_frame_idx)
            score_str = f"_{fs.score:.3f}" if fs else ""
            filename = output_dir / f"keyframe_{current_frame_idx:06d}{score_str}.jpg"
            
            # Save frame
            cv2.imwrite(str(filename), frame)
            saved_paths.append(filename)
            
            # Also save metadata if score available
            if fs:
                meta_path = filename.with_suffix('.txt')
                with open(meta_path, 'w') as f:
                    f.write(f"Frame Index: {fs.frame_index}\n")
                    f.write(f"Score: {fs.score:.6f}\n")
                    f.write(f"Flow Magnitude: {fs.flow_magnitude:.4f}\n")
                    f.write(f"Particle Count: {fs.particle_count}\n")
                    f.write(f"Vorticity Energy: {fs.vorticity_energy:.6f}\n")
                    f.write(f"Divergence Energy: {fs.divergence_energy:.6f}\n")
                    f.write(f"Metrics: {fs.description}\n")
        
        current_frame_idx += 1
    
    cap.release()
    return saved_paths


def create_keyframe_grid(
    frames: dict[int, np.ndarray],
    grid_shape: tuple[int, int] = (2, 5),
    tile_size: tuple[int, int] = (256, 256),
) -> np.ndarray:
    """
    Create a grid of key frames for visualization.
    
    Args:
        frames: Dict mapping frame_index to frame image
        grid_shape: (rows, cols) for grid layout
        tile_size: (height, width) to resize each frame to
        
    Returns:
        Composite grid image
    """
    rows, cols = grid_shape
    th, tw = tile_size
    
    # Prepare frame array
    frame_indices = sorted(frames.keys())[:rows * cols]
    
    grid = np.zeros((rows * th, cols * tw, 3), dtype=np.uint8)
    
    for idx, frame_num in enumerate(frame_indices):
        row = idx // cols
        col = idx % cols
        
        frame = frames[frame_num]
        # Resize frame to tile size
        resized = cv2.resize(frame, (tw, th))
        
        # Place in grid
        y_start = row * th
        x_start = col * tw
        grid[y_start:y_start + th, x_start:x_start + tw] = resized
    
    return grid


def save_keyframe_grid(
    frames: dict[int, np.ndarray],
    output_path: Path,
    grid_shape: tuple[int, int] = (2, 5),
    tile_size: tuple[int, int] = (256, 256),
) -> None:
    """
    Create and save a composite grid of key frames.
    
    Args:
        frames: Dict mapping frame_index to frame image
        output_path: Where to save the grid image
        grid_shape: (rows, cols) for grid layout
        tile_size: (height, width) for each tile
    """
    grid = create_keyframe_grid(frames, grid_shape, tile_size)
    cv2.imwrite(str(output_path), grid)
