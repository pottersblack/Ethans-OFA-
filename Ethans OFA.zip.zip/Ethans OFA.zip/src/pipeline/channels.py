from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Iterable, Iterator, Mapping, MutableMapping

from .types import ChannelName


class ChannelAlreadySetError(RuntimeError):
    pass


@dataclass(frozen=True)

class ChannelStore:
    """
    Immutable channel mapping for pipeline data.
    Once a channel is set, it cannot be overwritten (enforces immutability).
    """
    _data: Mapping[ChannelName, Any]

    @staticmethod
    def empty() -> "ChannelStore":
        """Create an empty channel store."""
        return ChannelStore(_data={})

    def has(self, name: ChannelName) -> bool:
        return name in self._data

    def get(self, name: ChannelName) -> Any:
        return self._data[name]

    def items(self) -> Iterable[tuple[ChannelName, Any]]:
        return self._data.items()

    def with_channel(self, name: ChannelName, value: Any) -> "ChannelStore":
        """Return a new ChannelStore with one additional channel (error if already set)."""
        # Allow replacing existing channels to let plugins emit updated outputs
        merged: Dict[ChannelName, Any] = dict(self._data)
        merged[name] = value
        return ChannelStore(_data=merged)

    def with_channels(self, updates: MutableMapping[ChannelName, Any]) -> "ChannelStore":
        """Return a new ChannelStore with multiple new channels (error if any already set)."""
        # Allow bulk replacement of channels: updates overwrite existing keys
        merged: Dict[ChannelName, Any] = dict(self._data)
        for name, value in updates.items():
            merged[name] = value
        return ChannelStore(_data=merged)
