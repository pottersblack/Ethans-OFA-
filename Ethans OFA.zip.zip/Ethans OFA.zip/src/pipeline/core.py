from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Sequence

from .channels import ChannelStore
from .types import Plugin, RunConfig


@dataclass(frozen=True)
class PipelineResult:
    channels: ChannelStore
    warnings: Sequence[str]


class Pipeline:
    def __init__(self, *, plugins: Sequence[Plugin]) -> None:
        self._plugins = list(plugins)

    def run_frame(self, *, frame_index: int, initial_channels: ChannelStore, config: RunConfig) -> PipelineResult:
        channels = initial_channels
        warnings: list[str] = []

        for plugin in self._plugins:
            for req in plugin.required_channels:
                if not channels.has(req):
                    raise KeyError(f"Missing required channel {req} for plugin {plugin.id}")

            warnings.extend(plugin.export_requirements(config))

            effective_config = config
            if config.mode.value == "preview":
                effective_config = plugin.preview_downgrade(config)

            channels = plugin.run(frame_index=frame_index, channels=channels, config=effective_config)

        return PipelineResult(channels=channels, warnings=tuple(warnings))
