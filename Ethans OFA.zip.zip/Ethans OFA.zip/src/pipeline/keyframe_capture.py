"""
Key Frame Capture - identifies and tracks the most valuable frames based on metrics.
Scores frames by: flow magnitude, particle count, and motion complexity.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional
import numpy as np


@dataclass
class FrameScore:
    """Scored frame with metrics."""
    frame_index: int
    score: float
    flow_magnitude: float = 0.0
    particle_count: int = 0
    vorticity_energy: float = 0.0
    divergence_energy: float = 0.0
    description: str = ""


class KeyFrameCapture:
    """Tracks and identifies top N key frames based on motion and detection metrics."""

    def __init__(self, num_frames: int = 10, score_weights: Optional[dict] = None):
        """
        Args:
            num_frames: Number of key frames to capture
            score_weights: Dict with keys 'flow', 'particles', 'vorticity', 'divergence'
                          (default: equal weight of 0.25 each)
        """
        self.num_frames = num_frames
        self.frame_scores: list[FrameScore] = []
        
        # Default equal weights
        self.weights = {
            'flow': 0.25,
            'particles': 0.25,
            'vorticity': 0.25,
            'divergence': 0.25,
        }
        if score_weights:
            self.weights.update(score_weights)

    def score_frame(
        self,
        frame_index: int,
        flow_uv: Optional[np.ndarray] = None,
        particle_count: int = 0,
        tracks: Optional[list] = None,
        vorticity: Optional[np.ndarray] = None,
        divergence: Optional[np.ndarray] = None,
    ) -> FrameScore:
        """
        Score a frame based on available metrics.
        
        Args:
            frame_index: Frame number
            flow_uv: Optical flow (H, W, 2)
            particle_count: Number of detected particles
            tracks: Particle tracks (optional)
            vorticity: Vorticity field (H, W)
            divergence: Divergence field (H, W)
            
        Returns:
            FrameScore with computed score and metrics
        """
        score = 0.0
        metrics = {
            'flow_magnitude': 0.0,
            'particle_count': particle_count,
            'vorticity_energy': 0.0,
            'divergence_energy': 0.0,
        }
        
        # Score 1: Flow magnitude (higher motion = more interesting)
        if flow_uv is not None:
            mag = np.sqrt(flow_uv[..., 0]**2 + flow_uv[..., 1]**2)
            flow_mean = float(np.mean(mag))
            flow_std = float(np.std(mag))
            # Normalize: mean + std gives us both activity level and turbulence
            flow_score = (flow_mean + flow_std * 0.5) / 100.0  # normalize to roughly [0, 1]
            flow_score = min(1.0, flow_score)  # clamp
            metrics['flow_magnitude'] = flow_mean
            score += self.weights['flow'] * flow_score
        
        # Score 2: Particle detection (more particles = more data)
        if particle_count > 0:
            # Normalize: expect 0-100 particles in a frame, so divide by 100
            particle_score = min(1.0, particle_count / 100.0)
            score += self.weights['particles'] * particle_score
        
        # Score 3: Vorticity energy (turbulent regions)
        if vorticity is not None:
            vort_energy = float(np.mean(np.abs(vorticity)))
            # Normalize: expect 0-1.0 range for vorticity
            vort_score = min(1.0, vort_energy)
            metrics['vorticity_energy'] = vort_energy
            score += self.weights['vorticity'] * vort_score
        
        # Score 4: Divergence energy (expansion/compression)
        if divergence is not None:
            div_energy = float(np.mean(np.abs(divergence)))
            div_score = min(1.0, div_energy)
            metrics['divergence_energy'] = div_energy
            score += self.weights['divergence'] * div_score
        
        # Bonus for frames with multiple high-value metrics
        high_metrics = sum([
            flow_uv is not None and metrics['flow_magnitude'] > 1.0,
            particle_count > 5,
            vorticity is not None and metrics['vorticity_energy'] > 0.1,
            divergence is not None and metrics['divergence_energy'] > 0.1,
        ])
        if high_metrics >= 3:
            score *= 1.2  # boost multi-signal frames
        
        # Create description
        desc_parts = []
        if metrics['flow_magnitude'] > 0:
            desc_parts.append(f"flow={metrics['flow_magnitude']:.2f}")
        if particle_count > 0:
            desc_parts.append(f"particles={particle_count}")
        if metrics['vorticity_energy'] > 0:
            desc_parts.append(f"vort={metrics['vorticity_energy']:.3f}")
        if metrics['divergence_energy'] > 0:
            desc_parts.append(f"div={metrics['divergence_energy']:.3f}")
        description = " | ".join(desc_parts) if desc_parts else "no metrics"
        
        frame_score = FrameScore(
            frame_index=frame_index,
            score=float(score),
            flow_magnitude=metrics['flow_magnitude'],
            particle_count=particle_count,
            vorticity_energy=metrics['vorticity_energy'],
            divergence_energy=metrics['divergence_energy'],
            description=description,
        )
        
        self.frame_scores.append(frame_score)
        return frame_score

    def get_top_frames(self) -> list[FrameScore]:
        """Get top N frames sorted by score (highest first)."""
        sorted_scores = sorted(self.frame_scores, key=lambda x: x.score, reverse=True)
        return sorted_scores[:self.num_frames]

    def get_top_frame_indices(self) -> list[int]:
        """Get frame indices of top N frames."""
        return [fs.frame_index for fs in self.get_top_frames()]

    def report(self) -> str:
        """Return a human-readable report of top frames."""
        top = self.get_top_frames()
        if not top:
            return "No frames scored yet."
        
        lines = [f"Top {self.num_frames} Key Frames:"]
        lines.append("-" * 80)
        for i, fs in enumerate(top, 1):
            lines.append(f"{i:2}. Frame {fs.frame_index:6} | Score: {fs.score:.4f} | {fs.description}")
        return "\n".join(lines)

    def save_report(self, output_path: str) -> None:
        """Save report to text file."""
        with open(output_path, 'w') as f:
            f.write(self.report())
