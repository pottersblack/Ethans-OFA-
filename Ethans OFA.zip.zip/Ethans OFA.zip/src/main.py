from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
import json
from typing import Optional

import cv2

from pipeline.channels import ChannelStore
from pipeline.core import Pipeline
from pipeline.types import ChannelName, Mode, RunConfig, Scenario
from pipeline.gpu import check_gpu, pretty_print_gpu_info
from pipeline.keyframe_capture import KeyFrameCapture
from pipeline.keyframe_extract import extract_keyframes_to_dir, save_keyframe_grid


from plugins.flow import FarnebackFlowPlugin
from plugins.overlays import (
    FlowMagnitudeHeatmapOverlay,
    FlowVectorFieldOverlay,
    VorticityMapOverlay,
    DivergenceMapOverlay,
    ShearStrainMapOverlay,
    RegionMaskOverlay,
    BoundingBoxesOverlay,
    CentroidLabelsOverlay,
    ROIMaskStatsOverlay,
    FeatureTrackTrailsOverlay,
    TrackMetricsHUDOverlay,
    ParticleBubbleTrackingOverlay,
    TemporalMotionHeatmapOverlay,
    SmallMultiplesInsetOverlay,
    FieldVectorDensityOverlay,
    HistogramOverlayOverlay,
    QuantitativeMetricsHUDOverlay,
    ColorbarLegendOverlay,
    ErrorWarningOverlay,
)
from plugins.particle_tracker import ParticleTrackerPlugin
 


FRAME = ChannelName("frame")


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Optical Flow Analyzer (scaffold)")
    parser.add_argument("--input", type=Path, required=True, help="Path to input video")
    parser.add_argument("--output", type=Path, required=False, help="Path to output video")
    parser.add_argument("--metrics-out", type=Path, required=False, help="Path to output per-frame metrics as JSON")
    parser.add_argument("--mode", choices=[m.value for m in Mode], default=Mode.PREVIEW.value)
    parser.add_argument(
        "--scenario",
        choices=[s.value for s in Scenario],
        default=Scenario.SMOKE_AIRFLOW.value,
    )
    parser.add_argument("--max-frames", type=int, default=0, help="Process only N frames (0 = all)")
    parser.add_argument("--device", choices=["auto", "cpu", "cuda"], default="auto", help="Preferred compute device")
    parser.add_argument("--two-pass", action="store_true", help="Run a two-pass export: dry-run then write")
    parser.add_argument("--cache-format", choices=["json", "pickle"], default="json", help="Format for two-pass cache files")
    parser.add_argument("--enable-particle-tracker", action="store_true", help="Enable particle tracker plugin")
    parser.add_argument("--tracker-max-history", type=int, default=16, help="Max history length for tracker")
    parser.add_argument("--tracker-max-dist", type=float, default=24.0, help="Max association distance for tracker")
    parser.add_argument("--tracker-kalman", action="store_true", help="Enable Kalman filtering in tracker")
    parser.add_argument("--capture-keyframes", action="store_true", help="Enable key frame capture (saves 10 most valuable frames)")
    parser.add_argument("--keyframes-dir", type=Path, required=False, help="Directory to save extracted key frames")
    parser.add_argument("--keyframes-count", type=int, default=10, help="Number of key frames to capture (default: 10)")
    parser.add_argument("--keyframes-grid", action="store_true", help="Save key frames as a composite grid image")
    return parser.parse_args()


def _build_pipeline(selected_overlays: list[str]) -> Pipeline:
    OVERLAY_REGISTRY = {
        "flow_magnitude_heatmap": FlowMagnitudeHeatmapOverlay,
        "flow_vector_field": FlowVectorFieldOverlay,
        "vorticity_map": VorticityMapOverlay,
        "divergence_map": DivergenceMapOverlay,
        "shear_strain_map": ShearStrainMapOverlay,
        "region_mask": RegionMaskOverlay,
        "bounding_boxes": BoundingBoxesOverlay,
        "centroid_labels": CentroidLabelsOverlay,
        "roi_mask_stats": ROIMaskStatsOverlay,
        "feature_track_trails": FeatureTrackTrailsOverlay,
        "track_metrics_hud": TrackMetricsHUDOverlay,
        "particle_bubble_tracking": ParticleBubbleTrackingOverlay,
        "temporal_motion_heatmap": TemporalMotionHeatmapOverlay,
        "small_multiples_inset": SmallMultiplesInsetOverlay,
        "field_vector_density": FieldVectorDensityOverlay,
        "histogram_overlay": HistogramOverlayOverlay,
        "quantitative_metrics_hud": QuantitativeMetricsHUDOverlay,
        "colorbar_legend": ColorbarLegendOverlay,
        "error_warning_overlay": ErrorWarningOverlay,
    }
    plugins = [FarnebackFlowPlugin()]
    # Insert particle tracker plugin if requested via overlays list key
    if "particle_bubble_tracking" in selected_overlays:
        # default params; main() may replace instance after creation if needed
        plugins.append(ParticleTrackerPlugin())
    plugins += [OVERLAY_REGISTRY[k]() for k in selected_overlays if k in OVERLAY_REGISTRY]
    return Pipeline(plugins=plugins)


def process_capture(
    input_path: Path,
    pipeline: Pipeline,
    config: RunConfig,
    output_path: Optional[Path] = None,
    max_frames: int = 0,
    cache: dict | None = None,
    keyframe_capture: KeyFrameCapture | None = None,
) -> list[dict]:
    cap = cv2.VideoCapture(str(input_path))
    if not cap.isOpened():
        raise RuntimeError(f"Failed to open input video: {input_path}")

    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    writer = None
    if output_path is not None:
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        writer = cv2.VideoWriter(str(output_path), fourcc, fps, (width, height))
        if not writer.isOpened():
            raise RuntimeError(f"Failed to open output writer: {output_path}")

    metrics_out: list[dict] = []
    cache_out: dict[int, dict] = {} if cache is None else None
    frame_index = 0
    prev_frame = None
    while True:
        ok, frame = cap.read()
        if not ok:
            break

        if prev_frame is None:
            prev_frame = frame
            frame_index += 1
            continue

        channels = ChannelStore.empty().with_channel("prev_frame", prev_frame).with_channel("frame", frame)
        # If cache provided (read mode), inject cached channels for this frame
        if isinstance(cache, dict):
            frame_cache = cache.get(str(frame_index), {})
            for k, v in frame_cache.items():
                channels = channels.with_channel(k, v)
        result = pipeline.run_frame(frame_index=frame_index, initial_channels=channels, config=config)

        out_frame = result.channels.get("frame")
        if writer is not None:
            writer.write(out_frame)

        if result.channels.has("flow_metrics"):
            metrics = result.channels.get("flow_metrics")
            metrics_out.append({"frame": frame_index, **metrics})

        # Score frame for key frame capture if enabled
        if keyframe_capture is not None:
            flow_uv = result.channels.get(ChannelName("flow_uv")) if result.channels.has(ChannelName("flow_uv")) else None
            vorticity = result.channels.get(ChannelName("vorticity")) if result.channels.has(ChannelName("vorticity")) else None
            divergence = result.channels.get(ChannelName("divergence")) if result.channels.has(ChannelName("divergence")) else None
            
            # Count particles from tracks if available
            particle_count = 0
            if result.channels.has(ChannelName("tracks")):
                tracks = result.channels.get(ChannelName("tracks"))
                if tracks:
                    particle_count = len(tracks)
            
            keyframe_capture.score_frame(
                frame_index=frame_index,
                flow_uv=flow_uv,
                particle_count=particle_count,
                tracks=None,
                vorticity=vorticity,
                divergence=divergence,
            )

        # If collecting cache (dry-run), stash interesting channels
        if cache_out is not None:
            frame_cache: dict = {}
            if result.channels.has("tracks"):
                frame_cache["tracks"] = result.channels.get("tracks")
            if result.channels.has("flow_metrics"):
                frame_cache["flow_metrics"] = result.channels.get("flow_metrics")
            if frame_cache:
                cache_out[frame_index] = frame_cache

        prev_frame = frame
        frame_index += 1
        if max_frames and frame_index >= max_frames:
            break

    cap.release()
    if writer is not None:
        writer.release()
    # If cache_out was collected, return it via a special key
    if cache_out is not None:
        return metrics_out, cache_out
    return metrics_out


def main() -> int:
    args = _parse_args()

    gpu_info = check_gpu()
    pretty_print_gpu_info(gpu_info)
    device_choice = getattr(args, "device", "auto")
    if device_choice == "auto":
        selected_device = "cuda" if gpu_info.get("cuda_available") else "cpu"
    else:
        selected_device = device_choice
    print(f"Selected device: {selected_device}")

    config = RunConfig(mode=Mode(args.mode), scenario=Scenario(args.scenario), device=selected_device)

    # Default overlays for now
    selected_overlays = ["flow_magnitude_heatmap", "flow_vector_field"]
    if getattr(args, "enable_particle_tracker", False):
        selected_overlays.append("particle_bubble_tracking")
        # store tracker params on a small dict to be consumed by pipeline builder
        tracker_params = {
            "max_history": args.tracker_max_history,
            "max_dist": args.tracker_max_dist,
            "use_kalman": args.tracker_kalman,
        }
    else:
        tracker_params = None
    pipeline = _build_pipeline(selected_overlays)
    # If custom tracker params provided, replace default tracker instance in pipeline
    if tracker_params is not None:
        new_plugins = []
        for p in pipeline._plugins:
            if getattr(p, "id", "") == "tracker.particles":
                new_plugins.append(ParticleTrackerPlugin(max_history=tracker_params["max_history"], max_dist=tracker_params["max_dist"], use_kalman=tracker_params["use_kalman"]))
            else:
                new_plugins.append(p)
        pipeline._plugins = new_plugins

    # If two-pass flow requested, run a dry run (no writer) first and persist cache
    cache_file: Optional[Path] = None
    cache_format = getattr(args, "cache_format", "json")
    
    # Initialize key frame capture if enabled
    keyframe_capture = None
    if getattr(args, "capture_keyframes", False):
        keyframe_count = getattr(args, "keyframes_count", 10)
        keyframe_capture = KeyFrameCapture(num_frames=keyframe_count)
        print(f"Key frame capture enabled (capturing {keyframe_count} frames)")
    
    if args.two_pass and args.output is not None:
        print("Running dry-run pass (no writer) to prepare caches/detections...")
        metrics, cache_data = process_capture(args.input, pipeline, config, output_path=None, max_frames=args.max_frames, keyframe_capture=keyframe_capture)
        # Persist cache next to output
        if cache_format == "pickle":
            cache_file = args.output.with_suffix(args.output.suffix + ".cache.pickle")
            try:
                import pickle as _pickle
                # normalize keys to strings for consistent lookup during injection
                norm = {str(k): v for k, v in cache_data.items()}
                with open(cache_file, "wb") as f:
                    _pickle.dump(norm, f, protocol=_pickle.HIGHEST_PROTOCOL)
                print(f"Wrote dry-run cache to: {cache_file}")
            except Exception as e:
                print(f"Warning: failed to write cache file: {e}")
        else:
            cache_file = args.output.with_suffix(args.output.suffix + ".cache.json")
            try:
                import json as _json
                with open(cache_file, "w", encoding="utf-8") as f:
                    # keys must be strings for JSON
                    _json.dump({str(k): v for k, v in cache_data.items()}, f)
                print(f"Wrote dry-run cache to: {cache_file}")
            except Exception as e:
                print(f"Warning: failed to write cache file: {e}")

    # Second (or single) pass: write output if requested
    # If cache file exists, load it for injection
    cache_dict = None
    if cache_file is not None and cache_file.exists():
        try:
            if cache_format == "pickle":
                import pickle as _pickle
                with open(cache_file, "rb") as f:
                    cache_dict = _pickle.load(f)
                # ensure keys are strings for process_capture lookup
                cache_dict = {str(k): v for k, v in cache_dict.items()}
            else:
                import json as _json
                with open(cache_file, "r", encoding="utf-8") as f:
                    cache_dict = {k: v for k, v in _json.load(f).items()}
        except Exception:
            cache_dict = None

    if cache_dict is not None:
        metrics = process_capture(args.input, pipeline, config, output_path=args.output, max_frames=args.max_frames, cache=cache_dict, keyframe_capture=keyframe_capture)
    else:
        metrics = process_capture(args.input, pipeline, config, output_path=args.output, max_frames=args.max_frames, keyframe_capture=keyframe_capture)

    # Save key frame capture results if enabled
    if keyframe_capture is not None:
        print("\n" + keyframe_capture.report())
        
        # Save key frames report
        report_path = Path(args.input).stem + "_keyframes_report.txt"
        keyframe_capture.save_report(str(report_path))
        print(f"Saved key frames report to: {report_path}")
        
        # Extract and save key frames to directory if specified
        keyframes_dir = getattr(args, "keyframes_dir", None)
        if keyframes_dir is None and getattr(args, "capture_keyframes", False):
            # Default directory: next to input video
            keyframes_dir = Path(args.input).parent / (Path(args.input).stem + "_keyframes")
        
        if keyframes_dir is not None:
            print(f"Extracting key frames to: {keyframes_dir}")
            try:
                saved_frames = extract_keyframes_to_dir(
                    args.input,
                    keyframe_capture.get_top_frame_indices(),
                    keyframes_dir,
                    keyframe_capture.get_top_frames(),
                )
                print(f"Saved {len(saved_frames)} key frame images")
                
                # Create composite grid if requested
                if getattr(args, "keyframes_grid", False):
                    print("Creating key frames composite grid...")
                    grid_path = keyframes_dir.parent / (keyframes_dir.name + "_grid.jpg")
                    # Load the saved frames for grid
                    frames_dict = {}
                    cap = cv2.VideoCapture(str(args.input))
                    frame_idx = 0
                    for target_idx in keyframe_capture.get_top_frame_indices():
                        while frame_idx < target_idx:
                            ret, _ = cap.read()
                            if not ret:
                                break
                            frame_idx += 1
                        if frame_idx == target_idx:
                            ret, frame = cap.read()
                            if ret:
                                frames_dict[target_idx] = frame
                            frame_idx += 1
                    cap.release()
                    
                    if frames_dict:
                        save_keyframe_grid(frames_dict, grid_path, grid_shape=(2, 5), tile_size=(256, 256))
                        print(f"Saved key frames grid to: {grid_path}")
            except Exception as e:
                print(f"Warning: failed to extract key frames: {e}")

    if args.metrics_out is not None:
        with open(args.metrics_out, "w", encoding="utf-8") as f:
            json.dump(metrics, f, indent=2)
    elif metrics:
        print(json.dumps(metrics, indent=2))

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
