"""
Optical Flow Analyzer GUI - Full featured with overlay conflicts, GPU boost, and export.
"""
import tkinter as tk
from tkinter import filedialog, ttk, messagebox
import cv2  # type: ignore
from typing import Any, cast

# Tell type-checkers that `cv2` should be treated as dynamic/unknown so attribute
# access (e.g., `cv2.resize`) doesn't produce false positive diagnostics.
cv2 = cast(Any, cv2)
import numpy as np
import os
import sys
import threading
import time
from pathlib import Path

# Some linters/type-checkers can't see OpenCV runtime members; disable no-member warnings here
# pylint: disable=E1101

try:
    from PIL import Image, ImageTk
    _PIL_OK = True
except ImportError:
    _PIL_OK = False

from pipeline.channels import ChannelStore
from pipeline.types import RunConfig, Mode, Scenario, ChannelName
from pipeline.keyframe_capture import KeyFrameCapture
from pipeline.keyframe_extract import extract_keyframes_to_dir, save_keyframe_grid
from plugins.flow import FarnebackFlowPlugin
from plugins.particle_tracker import ParticleTrackerPlugin
from plugins.overlays import (
    FlowMagnitudeHeatmapOverlay,
    FlowVectorFieldOverlay,
    VorticityMapOverlay,
    DivergenceMapOverlay,
    ShearStrainMapOverlay,
    RegionMaskOverlay,
    BoundingBoxesOverlay,
    CentroidLabelsOverlay,
    ROIMaskStatsOverlay,
    FeatureTrackTrailsOverlay,
    TrackMetricsHUDOverlay,
    ParticleBubbleTrackingOverlay,
    TemporalMotionHeatmapOverlay,
    SmallMultiplesInsetOverlay,
    FieldVectorDensityOverlay,
    HistogramOverlayOverlay,
    QuantitativeMetricsHUDOverlay,
    ColorbarLegendOverlay,
    ErrorWarningOverlay,
    DetectionSilhouettePanelOverlay,
)
from plugins.overlays.detection_cache import get_global_cache, set_global_cache, DetectionCache


def compute_region_mask(flow_uv, threshold=2.0, adaptive=False, percentile=90):
    """Compute region mask from optical flow magnitude.

    If `adaptive` is True, threshold is computed as the given percentile of magnitudes.
    Returns labeled components (0 = background).
    """
    mag = np.sqrt(flow_uv[..., 0]**2 + flow_uv[..., 1]**2)
    if adaptive:
        thresh_val = float(np.percentile(mag, percentile))
    else:
        thresh_val = float(threshold)

    binary = (mag > thresh_val).astype(np.uint8) * 255
    # Clean small speckle with morphological ops
    if binary.max() > 0:
        # pylint: disable=E1101
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        binary = cv2.morphologyEx(binary, cv2.MORPH_OPEN, kernel)
        binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel)

    # Find connected components (labels)
    # pylint: disable=E1101
    _num_labels, labels = cv2.connectedComponents(binary)
    return labels


def compute_roi_mask(frame_shape, flow_uv, threshold=2.0, adaptive=False, percentile=90):
    """Compute ROI mask from optical flow (areas with significant motion).

    Returns a binary uint8 mask (0/1). If adaptive=True, threshold uses percentile.
    """
    mag = np.sqrt(flow_uv[..., 0]**2 + flow_uv[..., 1]**2)
    if adaptive:
        thresh_val = float(np.percentile(mag, percentile))
    else:
        thresh_val = float(threshold)

    roi = (mag > thresh_val).astype(np.uint8)
    if roi.sum() > 0:
        # pylint: disable=E1101
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        roi = cv2.morphologyEx(roi * 255, cv2.MORPH_OPEN, kernel)
        roi = cv2.morphologyEx(roi, cv2.MORPH_CLOSE, kernel)
        roi = (roi > 0).astype(np.uint8)

    return roi

# Overlay categories and dependencies:
# "base" = replaces frame content (heatmaps, colormaps) - only ONE allowed at a time
# "additive" = draws on top of frame - multiple allowed
# deps = list of extra channels needed beyond frame and flow_uv
OVERLAY_REGISTRY = {
    # Base overlays (mutually exclusive) - these work with just flow
    "flow_magnitude_heatmap": ("Flow Magnitude Heatmap", FlowMagnitudeHeatmapOverlay, "base", []),
    "vorticity_map": ("Vorticity Map", VorticityMapOverlay, "base", []),
    "divergence_map": ("Divergence Map", DivergenceMapOverlay, "base", []),
    "shear_strain_map": ("Shear/Strain Rate Map", ShearStrainMapOverlay, "base", []),
    "temporal_motion_heatmap": ("Temporal Motion Heatmap", TemporalMotionHeatmapOverlay, "base", []),
    # Additive overlays - flow only
    "flow_vector_field": ("Flow Vector Field", FlowVectorFieldOverlay, "additive", []),
    "histogram_overlay": ("Histogram Overlay", HistogramOverlayOverlay, "additive", []),
    "quantitative_metrics_hud": ("Quantitative Metrics HUD", QuantitativeMetricsHUDOverlay, "additive", []),
    "colorbar_legend": ("Colorbar/Legend", ColorbarLegendOverlay, "additive", []),
    "error_warning_overlay": ("Error/Warning Overlay", ErrorWarningOverlay, "additive", []),
    # Additive overlays - need region_mask (auto-computed from flow)
    "region_mask": ("Region Mask", RegionMaskOverlay, "additive", ["region_mask"]),
    "bounding_boxes": ("Bounding Boxes", BoundingBoxesOverlay, "additive", ["region_mask"]),
    "centroid_labels": ("Centroid Labels", CentroidLabelsOverlay, "additive", ["region_mask"]),
    "roi_mask_stats": ("ROI Mask + Stats", ROIMaskStatsOverlay, "additive", ["roi_mask"]),
    # Additive overlays - need tracks (from particle tracker)
    "feature_track_trails": ("Feature Track Trails", FeatureTrackTrailsOverlay, "additive", ["tracks"]),
    "track_metrics_hud": ("Track Metrics HUD", TrackMetricsHUDOverlay, "additive", ["tracks"]),
    "particle_bubble_tracking": ("Particle/Bubble Tracking", ParticleBubbleTrackingOverlay, "additive", ["tracks"]),
    # Other
    "small_multiples_inset": ("Small Multiples/Inset Views", SmallMultiplesInsetOverlay, "additive", []),
    "field_vector_density": ("Field Vector Density Plot", FieldVectorDensityOverlay, "additive", []),
    "detection_silhouette_panel": ("Detection Panel (Black Outlines)", lambda: DetectionSilhouettePanelOverlay(style="outline", colored=False, background="white"), "additive", []),
    "detection_silhouette_colored": ("Detection Panel (Colored Filled)", lambda: DetectionSilhouettePanelOverlay(style="filled", colored=True, background="white"), "additive", []),
    "detection_silhouette_dark": ("Detection Panel (Dark Mode)", lambda: DetectionSilhouettePanelOverlay(style="filled", colored=True, background="black"), "additive", []),
}

SCENARIOS = {
    "Smoke/Airflow": Scenario.SMOKE_AIRFLOW,
    "Water": Scenario.WATER_TURBULENCE,
    "Bubbles": Scenario.BUBBLES,
    "Particles": Scenario.PARTICLES,
}


class OpticalFlowGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Optical Flow Analyzer")
        self.geometry("1400x800")
        self.minsize(1000, 700)
        self.configure(bg="#1a1a1a")

        # State
        self.cap = None
        self.video_path = None
        self.frame_count = 0
        self.current_idx = 0
        self.fps = 30.0
        self.playing = False
        self.prev_frame = None
        self.current_frame = None
        self.photo_image = None
        self.exporting = False
        self.export_cancel = False

        # Overlay state
        self.overlay_vars = {key: tk.BooleanVar(value=False) for key in OVERLAY_REGISTRY}
        self.overlay_checkbuttons = {}  # key -> Checkbutton widget
        self.scenario_var = tk.StringVar(value="Smoke/Airflow")
        self.preview_quality_var = tk.StringVar(value="Balanced")
        self.gpu_boost_var = tk.BooleanVar(value=False)
        
        # Accuracy boost options    
        self.high_quality_flow_var = tk.BooleanVar(value=False)
        self.temporal_smoothing_var = tk.BooleanVar(value=False)
        self.subpixel_refinement_var = tk.BooleanVar(value=False)
        self.adaptive_threshold_var = tk.BooleanVar(value=False)
        
        # Key frame capture options
        self.keyframe_var = tk.BooleanVar(value=False)
        self.keyframe_count_var = tk.StringVar(value="10")
        self.keyframe_grid_var = tk.BooleanVar(value=False)
        self.keyframe_capture = None
        
        # Track which base overlay is active (only one allowed)
        self.active_base_overlay = None

        self._build_ui()
        self._check_gpu()
        # Initialize global cache with default if enabled
        try:
            if getattr(self, "cache_enabled_var", None) is None or self.cache_enabled_var.get():
                mb = int(getattr(self, "cache_size_var", tk.StringVar(value="2048")).get()) if getattr(self, "cache_size_var", None) is not None else 2048
                cache = DetectionCache(max_bytes=mb * 1024 ** 2)
                # adjust to system right away
                try:
                    cache.adjust_for_system()
                except Exception:
                    pass
                set_global_cache(cache)
            else:
                set_global_cache(None)
        except Exception:
            try:
                c = DetectionCache()
                c.adjust_for_system()
                set_global_cache(c)
            except Exception:
                set_global_cache(None)
        # Start periodic monitor for cache vs system memory
        try:
            self.after(5000, self._cache_monitor)
        except Exception:
            pass

    def _check_gpu(self):
        """Check if CUDA is available and update status."""
        try:
            if hasattr(cv2, 'cuda') and cv2.cuda.getCudaEnabledDeviceCount() > 0:
                self.gpu_available = True
                self.gpu_label.config(text="GPU: Available ✓", fg="#4CAF50")
            else:
                self.gpu_available = False
                self.gpu_label.config(text="GPU: Not available", fg="#888")
        except Exception:
            self.gpu_available = False
            self.gpu_label.config(text="GPU: Not available", fg="#888")

    def _build_ui(self):
        main_frame = tk.Frame(self, bg="#1a1a1a")
        main_frame.pack(fill=tk.BOTH, expand=True)

        # Sidebar
        sidebar = tk.Frame(main_frame, width=300, bg="#252525")
        sidebar.pack(side=tk.LEFT, fill=tk.Y)
        sidebar.pack_propagate(False)

        # Scrollable area
        self.sidebar_canvas = tk.Canvas(sidebar, bg="#252525", highlightthickness=0)
        scrollbar = tk.Scrollbar(sidebar, orient=tk.VERTICAL, command=self.sidebar_canvas.yview)
        self.sidebar_canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.sidebar_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        controls = tk.Frame(self.sidebar_canvas, bg="#252525")
        self.sidebar_canvas.create_window((0, 0), window=controls, anchor="nw", width=280)
        controls.bind("<Configure>", lambda e: self.sidebar_canvas.configure(scrollregion=self.sidebar_canvas.bbox("all")))

        self.sidebar_canvas.bind("<Enter>", lambda e: self._bind_mousewheel())
        self.sidebar_canvas.bind("<Leave>", lambda e: self._unbind_mousewheel())

        # Header
        tk.Label(controls, text="Optical Flow Analyzer", bg="#252525", fg="white",
                 font=("Segoe UI", 14, "bold")).pack(pady=(15, 5))

        # GPU status
        self.gpu_label = tk.Label(controls, text="GPU: Checking...", bg="#252525", fg="#888",
                                   font=("Segoe UI", 9))
        self.gpu_label.pack(pady=(0, 10))

        # Scenario
        tk.Label(controls, text="Scenario", bg="#252525", fg="#ccc",
                 font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=15, pady=(10, 2))
        ttk.Combobox(controls, textvariable=self.scenario_var, values=list(SCENARIOS.keys()),
                     state="readonly", width=28).pack(padx=15, pady=2)

        # Preview Quality
        tk.Label(controls, text="Preview Quality", bg="#252525", fg="#ccc",
                 font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=15, pady=(10, 2))
        tk.Label(controls, text="Lower = faster on old hardware", bg="#252525", fg="#666",
                 font=("Segoe UI", 8)).pack(anchor="w", padx=15)
        quality_combo = ttk.Combobox(controls, textvariable=self.preview_quality_var,
                                      values=["Ultra Fast", "Fast", "Balanced", "High Quality"],
                                      state="readonly", width=28)
        quality_combo.pack(padx=15, pady=2)
        quality_combo.bind("<<ComboboxSelected>>", lambda e: self._on_quality_change())

        # GPU Boost
        gpu_frame = tk.Frame(controls, bg="#252525")
        gpu_frame.pack(fill=tk.X, padx=15, pady=(15, 5))
        tk.Checkbutton(gpu_frame, text="GPU Boost (CUDA)", variable=self.gpu_boost_var,
                       bg="#252525", fg="white", selectcolor="#444", activebackground="#252525",
                       font=("Segoe UI", 10)).pack(anchor="w")

        # Preview cache controls
        tk.Label(controls, text="Preview Cache", bg="#252525", fg="#ccc",
             font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=15, pady=(12, 2))
        cache_frame = tk.Frame(controls, bg="#252525")
        cache_frame.pack(fill=tk.X, padx=15, pady=2)
        self.cache_enabled_var = tk.BooleanVar(value=True)
        tk.Checkbutton(cache_frame, text="Enable Preview Cache", variable=self.cache_enabled_var,
                   bg="#252525", fg="white", selectcolor="#444", activebackground="#252525",
                   font=("Segoe UI", 9), command=self._on_cache_change).pack(anchor="w")

        size_frame = tk.Frame(controls, bg="#252525")
        size_frame.pack(fill=tk.X, padx=15, pady=2)
        tk.Label(size_frame, text="Cache (MB)", bg="#252525", fg="#ccc", font=("Segoe UI", 9)).pack(side=tk.LEFT)
        self.cache_size_var = tk.StringVar(value="2048")
        self.cache_size_entry = tk.Entry(size_frame, textvariable=self.cache_size_var, width=8)
        self.cache_size_entry.pack(side=tk.LEFT, padx=(8, 0))
        tk.Button(size_frame, text="Apply", command=self._on_cache_change, width=8).pack(side=tk.LEFT, padx=6)
        tk.Button(size_frame, text="Clear Cache", command=self._clear_cache, width=10).pack(side=tk.LEFT, padx=6)

        # Accuracy Boost Section
        tk.Label(controls, text="Accuracy Boost", bg="#252525", fg="#FFD700",
                 font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=15, pady=(15, 2))
        tk.Label(controls, text="Trade speed for quality (slower)", bg="#252525", fg="#666",
                 font=("Segoe UI", 8)).pack(anchor="w", padx=15)

        acc_frame = tk.Frame(controls, bg="#252525")
        acc_frame.pack(fill=tk.X, padx=15, pady=5)

        tk.Checkbutton(acc_frame, text="High-Quality Flow", variable=self.high_quality_flow_var,
                       bg="#252525", fg="white", selectcolor="#444", activebackground="#252525",
                       font=("Segoe UI", 9), command=self._on_accuracy_change).pack(anchor="w")

        tk.Checkbutton(acc_frame, text="Temporal Smoothing", variable=self.temporal_smoothing_var,
                       bg="#252525", fg="white", selectcolor="#444", activebackground="#252525",
                       font=("Segoe UI", 9), command=self._on_accuracy_change).pack(anchor="w")

        tk.Checkbutton(acc_frame, text="Subpixel Refinement", variable=self.subpixel_refinement_var,
                       bg="#252525", fg="white", selectcolor="#444", activebackground="#252525",
                       font=("Segoe UI", 9), command=self._on_accuracy_change).pack(anchor="w")

        tk.Checkbutton(acc_frame, text="Adaptive Threshold", variable=self.adaptive_threshold_var,
                       bg="#252525", fg="white", selectcolor="#444", activebackground="#252525",
                       font=("Segoe UI", 9), command=self._on_accuracy_change).pack(anchor="w")

        # Key Frame Capture Section
        tk.Label(controls, text="Key Frame Capture", bg="#252525", fg="#E91E63",
                 font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=15, pady=(15, 2))
        tk.Label(controls, text="Extract frames with most valuable data", bg="#252525", fg="#666",
                 font=("Segoe UI", 8)).pack(anchor="w", padx=15)
        
        keyframe_frame = tk.Frame(controls, bg="#252525")
        keyframe_frame.pack(fill=tk.X, padx=15, pady=5)
        
        self.keyframe_var = tk.BooleanVar(value=False)
        tk.Checkbutton(keyframe_frame, text="Enable Key Frame Capture", variable=self.keyframe_var,
                       bg="#252525", fg="white", selectcolor="#444", activebackground="#252525",
                       font=("Segoe UI", 9)).pack(anchor="w")
        
        self.keyframe_count_var = tk.StringVar(value="10")
        count_frame = tk.Frame(controls, bg="#252525")
        count_frame.pack(fill=tk.X, padx=15, pady=2)
        tk.Label(count_frame, text="Num. Frames", bg="#252525", fg="#ccc",
                 font=("Segoe UI", 9)).pack(side=tk.LEFT)
        tk.Spinbox(count_frame, from_=1, to=50, textvariable=self.keyframe_count_var,
                   width=5, bg="#3d3d3d", fg="white").pack(side=tk.LEFT, padx=(5, 0))
        
        self.keyframe_grid_var = tk.BooleanVar(value=False)
        tk.Checkbutton(controls, text="Save Composite Grid", variable=self.keyframe_grid_var,
                       bg="#252525", fg="white", selectcolor="#444", activebackground="#252525",
                       font=("Segoe UI", 9)).pack(anchor="w", padx=25, pady=1)

        # Base overlays section
        tk.Label(controls, text="Base Overlay (pick one)", bg="#252525", fg="#ccc",
                 font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=15, pady=(15, 5))
        tk.Label(controls, text="These replace the video with a colormap", bg="#252525", fg="#666",
                 font=("Segoe UI", 8)).pack(anchor="w", padx=15)

        for key, (name, _, cat, _) in OVERLAY_REGISTRY.items():
            if cat == "base":
                cb = tk.Checkbutton(controls, text=name, variable=self.overlay_vars[key],
                                    bg="#252525", fg="white", selectcolor="#444",
                                    activebackground="#252525", activeforeground="white",
                                    disabledforeground="#666",
                                    command=lambda k=key: self._on_base_overlay_change(k))
                cb.pack(anchor="w", padx=25, pady=1)
                self.overlay_checkbuttons[key] = cb

        # Additive overlays section
        tk.Label(controls, text="Additive Overlays (stack on top)", bg="#252525", fg="#ccc",
                 font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=15, pady=(15, 5))
        tk.Label(controls, text="These draw on top of video or base overlay", bg="#252525", fg="#666",
                 font=("Segoe UI", 8)).pack(anchor="w", padx=15)

        for key, (name, _, cat, deps) in OVERLAY_REGISTRY.items():
            if cat == "additive":
                # Show dependency hint
                hint = ""
                if "tracks" in deps:
                    hint = " [tracking]"
                elif "region_mask" in deps or "roi_mask" in deps:
                    hint = " [regions]"
                    
                cb = tk.Checkbutton(controls, text=name + hint, variable=self.overlay_vars[key],
                                    bg="#252525", fg="white", selectcolor="#444",
                                    activebackground="#252525", activeforeground="white",
                                    command=self._on_overlay_change)
                cb.pack(anchor="w", padx=25, pady=1)
                self.overlay_checkbuttons[key] = cb

        # Buttons
        btn_frame = tk.Frame(controls, bg="#252525")
        btn_frame.pack(fill=tk.X, padx=15, pady=(25, 5))

        tk.Button(btn_frame, text="Load Video", command=self._load_video, width=15,
                  bg="#3d3d3d", fg="white", relief=tk.FLAT).pack(side=tk.LEFT, padx=(0, 5))
        self.export_btn = tk.Button(btn_frame, text="Export", command=self._export_video, width=15,
                                     bg="#2196F3", fg="white", relief=tk.FLAT, state=tk.DISABLED)
        self.export_btn.pack(side=tk.RIGHT)

        # Export passes selector (1-5)
        passes_frame = tk.Frame(controls, bg="#252525")
        passes_frame.pack(fill=tk.X, padx=15, pady=(6, 2))
        tk.Label(passes_frame, text="Export Passes", bg="#252525", fg="#ccc",
             font=("Segoe UI", 9)).pack(anchor="w")
        self.num_passes_var = tk.StringVar(value="2")
        self.passes_combo = ttk.Combobox(passes_frame, textvariable=self.num_passes_var,
                values=["1", "2", "3", "4", "5"], state="readonly", width=5)
        self.passes_combo.pack(anchor="w", pady=2)

        # Playback controls
        play_frame = tk.Frame(controls, bg="#252525")
        play_frame.pack(fill=tk.X, padx=15, pady=10)

        self.play_btn = tk.Button(play_frame, text="▶ Play", command=self._toggle_play, width=10,
                                   bg="#4CAF50", fg="white", relief=tk.FLAT, state=tk.DISABLED)
        self.play_btn.pack(side=tk.LEFT)

        self.slider = tk.Scale(play_frame, from_=0, to=0, orient=tk.HORIZONTAL, length=150,
                               command=self._on_slider, state=tk.DISABLED, bg="#252525", fg="white",
                               troughcolor="#444", highlightthickness=0, showvalue=False)
        self.slider.pack(side=tk.RIGHT, fill=tk.X, expand=True, padx=(10, 0))

        # Frame counter
        self.frame_label = tk.Label(controls, text="Frame: -/-", bg="#252525", fg="#888")
        self.frame_label.pack(pady=5)

        # Status
        self.status_var = tk.StringVar(value="Load a video to begin")
        tk.Label(controls, textvariable=self.status_var, bg="#252525", fg="#aaa",
                 wraplength=260, justify=tk.LEFT).pack(pady=10, padx=15)

        # Progress bar for export
        self.progress_var = tk.DoubleVar(value=0)
        self.progress_bar = ttk.Progressbar(controls, variable=self.progress_var, maximum=100)
        self.progress_bar.pack(fill=tk.X, padx=15, pady=5)
        self.progress_bar.pack_forget()  # Hidden initially

        # Cancel export button
        self.cancel_btn = tk.Button(controls, text="Cancel Export", command=self._cancel_export,
                                     bg="#f44336", fg="white", relief=tk.FLAT)
        self.cancel_btn.pack(pady=5)
        self.cancel_btn.pack_forget()  # Hidden initially

        # Video canvas
        self.video_canvas = tk.Canvas(main_frame, bg="#0a0a0a", highlightthickness=0)
        self.video_canvas.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

    def _bind_mousewheel(self):
        self.sidebar_canvas.bind_all("<MouseWheel>", self._on_mousewheel)

    def _unbind_mousewheel(self):
        self.sidebar_canvas.unbind_all("<MouseWheel>")

    def _on_mousewheel(self, event):
        self.sidebar_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    def _on_base_overlay_change(self, selected_key):
        """Handle base overlay selection - only one allowed."""
        is_selected = self.overlay_vars[selected_key].get()

        if is_selected:
            # Uncheck all other base overlays
            for key, (_, _, cat, _) in OVERLAY_REGISTRY.items():
                if cat == "base" and key != selected_key:
                    self.overlay_vars[key].set(False)
            self.active_base_overlay = selected_key
        else:
            self.active_base_overlay = None

        self._update_overlay_ui()
        self._on_overlay_change()

    def _update_overlay_ui(self):
        """Update overlay checkbuttons to show conflicts."""
        for key, (_, _, cat, _) in OVERLAY_REGISTRY.items():
            cb = self.overlay_checkbuttons.get(key)
            if cb is None:
                continue

            if cat == "base":
                if self.active_base_overlay and self.active_base_overlay != key:
                    # Another base overlay is active - show as blocked
                    cb.config(fg="#ff6666", state=tk.DISABLED)
                else:
                    cb.config(fg="white", state=tk.NORMAL)
            else:
                # Additive overlays are always available
                cb.config(fg="white", state=tk.NORMAL)

    def _on_overlay_change(self):
        """Re-render current frame with new overlay settings."""
        if self.current_frame is not None and self.prev_frame is not None:
            display = self._apply_overlays(self.current_frame.copy(), for_export=False)
            self._display_frame(display)

    def _on_accuracy_change(self):
        """Re-render when accuracy settings change."""
        if self.current_frame is not None and self.prev_frame is not None:
            display = self._apply_overlays(self.current_frame.copy(), for_export=False)
            self._display_frame(display)

    def _on_quality_change(self):
        """Re-render when preview quality changes."""
        if self.current_frame is not None and self.prev_frame is not None:
            display = self._apply_overlays(self.current_frame.copy(), for_export=False)
            self._display_frame(display)

    def _get_preview_downscale(self):
        """Get downscale factor based on preview quality preset."""
        quality = self.preview_quality_var.get()
        quality_map = {
            "Ultra Fast": 0.25,   # 4x faster, 1/16th pixels
            "Fast": 0.4,          # 2.5x faster, ~1/6th pixels
            "Balanced": 0.5,      # 2x faster, 1/4th pixels
            "High Quality": 1.0   # Full resolution (slow)
        }
        return quality_map.get(quality, 0.5)

    def _has_dimension_changing_overlays(self):
        """Check if any enabled overlay changes frame dimensions."""
        dimension_changing = {
            "detection_silhouette_panel",
            "detection_silhouette_colored",
            "detection_silhouette_dark"
        }
        for key in dimension_changing:
            if key in self.overlay_vars and self.overlay_vars[key].get():
                return True
        return False

    def _load_video(self):
        path = filedialog.askopenfilename(filetypes=[
            ("Video files", "*.mp4 *.avi *.mov *.mkv *.webm *.wmv *.flv"),
            ("All files", "*.*")
        ])
        if not path:
            return
        if self.cap:
            self.cap.release()
        self.cap = cv2.VideoCapture(path)
        if not self.cap.isOpened():
            self.status_var.set("Failed to open video")
            return

        self.video_path = path
        self.frame_count = int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT))
        self.fps = self.cap.get(cv2.CAP_PROP_FPS) or 30.0
        self.video_width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.video_height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        self.current_idx = 0
        self.prev_frame = None

        self.slider.config(to=max(0, self.frame_count - 1), state=tk.NORMAL)
        self.play_btn.config(state=tk.NORMAL)
        self.export_btn.config(state=tk.NORMAL)

        self.status_var.set(f"Loaded: {os.path.basename(path)}\n{self.video_width}x{self.video_height} @ {self.fps:.1f}fps")
        # Clear preview cache on new video load to avoid stale cached frames/metrics
        try:
            cache = get_global_cache()
            if cache is not None:
                cache.clear()
        except Exception:
            pass
        self._show_frame(0)

    def _show_frame(self, idx):
        if self.cap is None:
            return
        # Auto-clear cache on large seeks to avoid serving stale per-frame cached data
        try:
            old_idx = getattr(self, "current_idx", 0)
            # threshold in frames; seeking more than this will clear cache
            SEEK_THRESHOLD = 64
            if abs(idx - old_idx) > SEEK_THRESHOLD:
                cache = get_global_cache()
                if cache is not None:
                    cache.clear()
        except Exception:
            pass
        self.cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
        ret, frame = self.cap.read()
        if not ret:
            return

        self.prev_frame = self.current_frame
        self.current_frame = frame.copy()
        self.current_idx = idx
        self.slider.set(idx)
        self.frame_label.config(text=f"Frame: {idx + 1}/{self.frame_count}")

        display_frame = self._apply_overlays(frame, for_export=False)
        self._display_frame(display_frame)

    def _apply_overlays(self, frame, for_export=False):
        """Apply enabled overlays. for_export=True uses full resolution."""
        # Get active overlays in correct order: base first (if any), then additives
        active_keys = []
        
        # Add base overlay first if selected
        if self.active_base_overlay and self.overlay_vars[self.active_base_overlay].get():
            active_keys.append(self.active_base_overlay)
        
        # Add additive overlays
        for key, (_, _, cat, _) in OVERLAY_REGISTRY.items():
            if cat == "additive" and self.overlay_vars[key].get():
                active_keys.append(key)

        if not active_keys:
            return frame

        if self.prev_frame is None:
            return frame

        try:
            # Determine what extra channels are needed
            needs_tracks = False
            needs_region_mask = False
            needs_roi_mask = False
            
            for key in active_keys:
                _, _, _, deps = OVERLAY_REGISTRY[key]
                if "tracks" in deps:
                    needs_tracks = True
                if "region_mask" in deps:
                    needs_region_mask = True
                if "roi_mask" in deps:
                    needs_roi_mask = True

            # Build pipeline - always start with flow
            plugins = [FarnebackFlowPlugin()]
            
            # Add particle tracker if any overlay needs tracks
            if needs_tracks:
                plugins.append(ParticleTrackerPlugin())
            
            # Add overlay plugins
            for key in active_keys:
                _, overlay_cls, _, _ = OVERLAY_REGISTRY[key]
                plugins.append(overlay_cls())
            # `Pipeline` was previously instantiated here but not used; skip.
            scenario = SCENARIOS.get(self.scenario_var.get(), Scenario.SMOKE_AIRFLOW)
            
            # Use CUDA if GPU boost enabled and available
            device = "cuda" if (self.gpu_boost_var.get() and self.gpu_available) else "cpu"
            
            mode = Mode.EXPORT if for_export else Mode.PREVIEW
            
            # Get preview downscale based on quality preset (only for Preview mode)
            preview_downscale = 1.0 if for_export else self._get_preview_downscale()
            
            config = RunConfig(
                mode=mode, 
                scenario=scenario, 
                device=device,
                preview_downscale=preview_downscale,
                high_quality_flow=self.high_quality_flow_var.get(),
                temporal_smoothing=self.temporal_smoothing_var.get(),
                subpixel_refinement=self.subpixel_refinement_var.get(),
                adaptive_threshold=self.adaptive_threshold_var.get()
            )

            # Build initial channels
            channels = (ChannelStore.empty()
                        .with_channel(ChannelName("prev_frame"), self.prev_frame)
                        .with_channel(ChannelName("frame"), frame.copy()))

            # First pass: compute flow
            # Try to use cached flow if available to avoid recompute during preview
            cache = get_global_cache()
            video_id = Path(self.video_path).stem if getattr(self, "video_path", None) else "local"
            cfg_tag = f"ds={preview_downscale}|hq={config.high_quality_flow}|subp={config.subpixel_refinement}|ts={config.temporal_smoothing}|advth={config.adaptive_threshold}|dev={config.device}"
            flow_key = f"flow:{video_id}:{self.current_idx}:{cfg_tag}"

            def _compute_flow():
                fr = FarnebackFlowPlugin().run(frame_index=self.current_idx, channels=channels, config=config)
                return fr.get(ChannelName("flow_uv"))

            if cache is not None and config.mode == Mode.PREVIEW:
                flow_uv = cache.get_or_compute(flow_key, _compute_flow, type="flow")
            else:
                flow_uv = _compute_flow()

            channels = channels.with_channel(ChannelName("flow_uv"), flow_uv)
            
            # Compute region_mask if needed
            if needs_region_mask:
                region_key = f"region:{video_id}:{self.current_idx}:{cfg_tag}"

                def _compute_region():
                    return compute_region_mask(flow_uv)

                if cache is not None and config.mode == Mode.PREVIEW:
                    region_mask = cache.get_or_compute(region_key, _compute_region, type="mask")
                else:
                    region_mask = _compute_region()

                channels = channels.with_channel(ChannelName("region_mask"), region_mask)
            
            # Compute roi_mask if needed
            if needs_roi_mask:
                roi_key = f"roi:{video_id}:{self.current_idx}:{cfg_tag}"

                def _compute_roi():
                    return compute_roi_mask(frame.shape, flow_uv)

                if cache is not None and config.mode == Mode.PREVIEW:
                    roi_mask = cache.get_or_compute(roi_key, _compute_roi, type="mask")
                else:
                    roi_mask = _compute_roi()

                channels = channels.with_channel(ChannelName("roi_mask"), roi_mask)
            
            # Compute tracks if needed
            if needs_tracks:
                tracks_key = f"tracks:{video_id}:{self.current_idx}:{cfg_tag}"

                def _compute_tracks():
                    tracker = ParticleTrackerPlugin()
                    tr = tracker.run(frame_index=self.current_idx, channels=channels, config=config)
                    return tr.get(ChannelName("tracks"))

                if cache is not None and config.mode == Mode.PREVIEW:
                    tracks = cache.get_or_compute(tracks_key, _compute_tracks, type="tracks")
                else:
                    tracks = _compute_tracks()

                channels = channels.with_channel(ChannelName("tracks"), tracks)
            
            # Now run overlays only (skip flow/tracker plugins)
            for key in active_keys:
                _, overlay_cls, _, _ = OVERLAY_REGISTRY[key]
                overlay = overlay_cls()
                channels = overlay.run(
                    frame_index=self.current_idx,
                    channels=channels,
                    config=config
                )

            return channels.get(ChannelName("frame"))

        except Exception as e:
            import traceback
            traceback.print_exc()
            self.status_var.set(f"Overlay error: {str(e)[:50]}")
            return frame

    def _display_frame(self, frame):
        if not _PIL_OK:
            return

        cw = max(100, self.video_canvas.winfo_width())
        ch = max(100, self.video_canvas.winfo_height())

        fh, fw = frame.shape[:2]
        scale = min(cw / fw, ch / fh)
        new_w, new_h = int(fw * scale), int(fh * scale)

        resized = cv2.resize(frame, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
        rgb = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)
        self.photo_image = ImageTk.PhotoImage(Image.fromarray(rgb))

        x, y = (cw - new_w) // 2, (ch - new_h) // 2
        self.video_canvas.delete("all")
        self.video_canvas.create_image(x, y, anchor="nw", image=self.photo_image)

    def _compute_flow_uv(self, frame, prev_frame, config):
        """Compute `flow_uv` for a pair of frames using the flow plugin."""
        try:
            channels = (ChannelStore.empty()
                        .with_channel(ChannelName("prev_frame"), prev_frame)
                        .with_channel(ChannelName("frame"), frame.copy()))
            flow_result = FarnebackFlowPlugin().run(frame_index=self.current_idx, channels=channels, config=config)
            flow_uv = flow_result.get(ChannelName("flow_uv"))
            return flow_uv
        except Exception:
            return None

    def _write_calibration(self, video_path, stats):
        """Write calibration JSON under .cache/<basename>.json with computed stats."""
        try:
            cache_dir = os.path.join(os.path.dirname(video_path), ".cache")
            os.makedirs(cache_dir, exist_ok=True)
            base = os.path.splitext(os.path.basename(video_path))[0]
            cache_path = os.path.join(cache_dir, f"{base}.json")
            import json
            with open(cache_path, "w", encoding="utf-8") as fh:
                json.dump(stats, fh, indent=2)
            return cache_path
        except Exception:
            return None

    def _on_slider(self, val):
        idx = int(float(val))
        if idx != self.current_idx and not self.playing:
            self._show_frame(idx)

    def _on_cache_change(self):
        try:
            enabled = bool(self.cache_enabled_var.get())
        except Exception:
            enabled = True
        try:
            mb = int(self.cache_size_var.get())
        except Exception:
            mb = 2048

        if enabled:
            try:
                cache = DetectionCache(max_bytes=mb * 1024 ** 2)
                cache.adjust_for_system()
                set_global_cache(cache)
                self.status_var.set(f"Preview cache enabled ({mb} MB)")
            except Exception:
                self.status_var.set("Failed to enable cache")
        else:
            # disable cache
            try:
                set_global_cache(None)
                self.status_var.set("Preview cache disabled")
            except Exception:
                self.status_var.set("Failed to disable cache")

    def _clear_cache(self):
        try:
            cache = get_global_cache()
            if cache is not None:
                cache.clear()
                self.status_var.set("Preview cache cleared")
            else:
                self.status_var.set("No preview cache to clear")
        except Exception:
            self.status_var.set("Failed to clear preview cache")

    def _cache_monitor(self):
        """Periodic monitor that auto-throttles or disables cache when system memory is low."""
        try:
            cache = get_global_cache()
            if cache is None:
                # nothing to do, reschedule
                self.after(5000, self._cache_monitor)
                return
            # Ask cache to adjust based on system state; ignore return value
            try:
                cache.adjust_for_system()
            except Exception:
                pass

            # If cache adjusted down to zero, disable it to avoid thrashing
            if cache.max_bytes == 0:
                set_global_cache(None)
                self.status_var.set("Preview cache disabled (low memory)")
            else:
                # Show a lightweight status if desired
                mb = cache.max_bytes // 1024 // 1024
                self.status_var.set(f"Preview cache: {mb} MB")
        finally:
            # Reschedule monitor
            try:
                self.after(5000, self._cache_monitor)
            except Exception:
                pass

    def _toggle_play(self):
        self.playing = not self.playing
        self.play_btn.config(text="⏸ Pause" if self.playing else "▶ Play",
                             bg="#FF9800" if self.playing else "#4CAF50")
        if self.playing:
            self._play_loop()

    def _play_loop(self):
        if not self.playing or self.cap is None:
            return
        if self.current_idx >= self.frame_count - 1:
            self.playing = False
            self.play_btn.config(text="▶ Play", bg="#4CAF50")
            return

        # Skip frames in ultra-fast mode for smoother playback on old hardware
        quality = self.preview_quality_var.get()
        frame_skip = 2 if quality == "Ultra Fast" else (1 if quality == "Fast" else 0)
        next_idx = self.current_idx + 1 + frame_skip
        
        self._show_frame(min(next_idx, self.frame_count - 1))
        
        # Adaptive delay based on quality and GPU
        if quality == "Ultra Fast":
            delay = max(1, int(500 / self.fps))  # Very fast
        elif self.gpu_boost_var.get() and self.gpu_available:
            delay = max(1, int(800 / self.fps))  # GPU accelerated
        else:
            delay = max(1, int(1000 / self.fps))  # Normal
        
        self.after(delay, self._play_loop)

    def _export_video(self):
        if self.video_path is None:
            return

        # Warn user if dimension-changing overlays are enabled
        if self._has_dimension_changing_overlays():
            response = messagebox.askyesno(
                "Dimension Change Detected",
                "You have enabled Detection Panel overlays that will make the output video wider.\n\n"
                "Output will be: Video + Panel side-by-side\n\n"
                "Continue with export?",
                icon='warning'
            )
            if not response:
                return

        # Get output path
        base, ext = os.path.splitext(self.video_path)
        default_name = f"{os.path.basename(base)}_overlay{ext}"
        
        output_path = filedialog.asksaveasfilename(
            initialfile=default_name,
            defaultextension=ext,
            filetypes=[
                ("Same format", f"*{ext}"),
                ("MP4", "*.mp4"),
                ("AVI", "*.avi"),
                ("All files", "*.*")
            ]
        )
        if not output_path:
            return

        self.exporting = True
        self.export_cancel = False
        self._show_export_ui(True)

        # Run export in thread
        threading.Thread(target=self._export_worker, args=(output_path,), daemon=True).start()

    def _show_export_ui(self, show):
        if show:
            self.progress_bar.pack(fill=tk.X, padx=15, pady=5)
            self.cancel_btn.pack(pady=5)
            self.export_btn.config(state=tk.DISABLED)
            self.play_btn.config(state=tk.DISABLED)
            self.slider.config(state=tk.DISABLED)
            self.passes_combo.config(state=tk.DISABLED)
        else:
            self.progress_bar.pack_forget()
            self.cancel_btn.pack_forget()
            self.export_btn.config(state=tk.NORMAL)
            self.play_btn.config(state=tk.NORMAL)
            self.slider.config(state=tk.NORMAL)
            self.passes_combo.config(state="readonly")

    def _cancel_export(self):
        self.export_cancel = True

    def _export_worker(self, output_path):
        """Export video with overlays at full resolution."""
        try:
            # Open source video
            cap = cv2.VideoCapture(self.video_path)
            if not cap.isOpened():
                self._export_done("Failed to open source video")
                return

            # Get video properties
            fps = cap.get(cv2.CAP_PROP_FPS)
            width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

            # Check if we need to process a test frame to determine output dimensions
            has_dimension_change = self._has_dimension_changing_overlays()
            output_width, output_height = width, height
            
            if has_dimension_change:
                # Process first frame to determine actual output dimensions
                cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                ret, test_frame = cap.read()
                if ret:
                    cap.set(cv2.CAP_PROP_POS_FRAMES, 1)
                    ret2, test_frame2 = cap.read()
                    if ret2:
                        orig_prev = self.prev_frame
                        orig_curr = self.current_frame
                        orig_idx = self.current_idx
                        
                        self.prev_frame = test_frame
                        self.current_frame = test_frame2
                        self.current_idx = 1
                        
                        processed_test = self._apply_overlays(test_frame2, for_export=True)
                        output_height, output_width = processed_test.shape[:2]
                        
                        self.prev_frame = orig_prev
                        self.current_frame = orig_curr
                        self.current_idx = orig_idx
                        
                        # Reset to beginning
                        cap.set(cv2.CAP_PROP_POS_FRAMES, 0)

            # Determine codec from output extension
            ext = os.path.splitext(output_path)[1].lower()
            if ext == ".mp4":
                fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            elif ext == ".avi":
                fourcc = cv2.VideoWriter_fourcc(*'XVID')
            elif ext == ".mov":
                fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            elif ext == ".mkv":
                fourcc = cv2.VideoWriter_fourcc(*'X264')
            else:
                fourcc = cv2.VideoWriter_fourcc(*'mp4v')

            # Create writer with actual output dimensions
            # Write to a temporary file and rename on success to avoid producing
            # partially-written/corrupted outputs if the process is interrupted.
            tmp_output = str(output_path) + ".part"
            writer = cv2.VideoWriter(tmp_output, fourcc, fps, (output_width, output_height))
            if not writer.isOpened():
                cap.release()
                self._export_done("Failed to create output video")
                return

            # Build export RunConfig for sampled flow computations
            scenario = SCENARIOS.get(self.scenario_var.get(), Scenario.SMOKE_AIRFLOW)
            device = "cuda" if (self.gpu_boost_var.get() and self.gpu_available) else "cpu"
            export_config = RunConfig(
                mode=Mode.EXPORT,
                scenario=scenario,
                device=device,
                preview_downscale=1.0,
                high_quality_flow=self.high_quality_flow_var.get(),
                temporal_smoothing=self.temporal_smoothing_var.get(),
                subpixel_refinement=self.subpixel_refinement_var.get(),
                adaptive_threshold=self.adaptive_threshold_var.get()
            )
            
            # Initialize key frame capture if enabled
            keyframe_capture = None
            if self.keyframe_var.get():
                try:
                    keyframe_count = int(self.keyframe_count_var.get())
                except Exception:
                    keyframe_count = 10
                keyframe_capture = KeyFrameCapture(num_frames=keyframe_count)
                self.status_var.set(f"Exporting and capturing {keyframe_count} key frames...")

            # Determine active overlays and dependencies so we know what to cache
            active_keys = []
            if self.active_base_overlay and self.overlay_vars[self.active_base_overlay].get():
                active_keys.append(self.active_base_overlay)
            for key, (_, _, cat, _) in OVERLAY_REGISTRY.items():
                if cat == "additive" and self.overlay_vars[key].get():
                    active_keys.append(key)

            needs_tracks = any("tracks" in OVERLAY_REGISTRY[k][3] for k in active_keys)
            needs_region_mask = any("region_mask" in OVERLAY_REGISTRY[k][3] for k in active_keys)
            needs_roi_mask = any("roi_mask" in OVERLAY_REGISTRY[k][3] for k in active_keys)

            # Prepare cache file path
            cache_dir = os.path.join(os.path.dirname(self.video_path), ".cache")
            os.makedirs(cache_dir, exist_ok=True)
            base = os.path.splitext(os.path.basename(self.video_path))[0]
            cache_file = os.path.join(cache_dir, f"{base}_passcache.pickle")

            # Number of passes (clamp between 1 and 5)
            try:
                num_passes = int(self.num_passes_var.get())
            except Exception:
                num_passes = 2
            num_passes = max(1, min(5, num_passes))

            # In-memory cache (frame_idx -> dict)
            frame_cache = {}

            prev_frame = None
            start_time = time.time()

            # Run passes: compute-only for early passes; render-only on final pass
            import pickle
            for pass_idx in range(num_passes):
                if self.export_cancel:
                    break
                # reset to start
                cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                prev_frame = None

                for frame_idx in range(total_frames):
                    if self.export_cancel:
                        break
                    ret, frame = cap.read()
                    if not ret:
                        break

                    # compute flow/tracks on early passes and cache
                    if prev_frame is not None and pass_idx < (num_passes - 1):
                        # compute flow
                        flow_uv = self._compute_flow_uv(frame, prev_frame, export_config)
                        entry = frame_cache.get(str(frame_idx), {})
                        entry["flow_uv"] = flow_uv

                        # region/roi masks
                        if needs_region_mask:
                            entry["region_mask"] = compute_region_mask(flow_uv, adaptive=self.adaptive_threshold_var.get())
                        if needs_roi_mask:
                            entry["roi_mask"] = compute_roi_mask(frame.shape, flow_uv, adaptive=self.adaptive_threshold_var.get())

                        # tracks
                        if needs_tracks:
                            channels = (ChannelStore.empty()
                                        .with_channel(ChannelName("prev_frame"), prev_frame)
                                        .with_channel(ChannelName("frame"), frame.copy())
                                        .with_channel(ChannelName("flow_uv"), flow_uv))
                            tracker = ParticleTrackerPlugin()
                            track_result = tracker.run(frame_index=frame_idx, channels=channels, config=export_config)
                            tracks = track_result.get(ChannelName("tracks"))
                            entry["tracks"] = tracks

                        frame_cache[str(frame_idx)] = entry

                    # final pass: render overlays using cached metrics where available
                    if prev_frame is not None and pass_idx == (num_passes - 1):
                        # Build channels and inject cache
                        channels = (ChannelStore.empty()
                                    .with_channel(ChannelName("prev_frame"), prev_frame)
                                    .with_channel(ChannelName("frame"), frame.copy()))

                        cached = frame_cache.get(str(frame_idx), {})
                        if "flow_uv" in cached and cached["flow_uv"] is not None:
                            channels = channels.with_channel(ChannelName("flow_uv"), cached["flow_uv"])
                        else:
                            # compute if missing
                            flow_uv = self._compute_flow_uv(frame, prev_frame, export_config)
                            if flow_uv is not None:
                                channels = channels.with_channel(ChannelName("flow_uv"), flow_uv)

                        if needs_region_mask and "region_mask" in cached:
                            channels = channels.with_channel(ChannelName("region_mask"), cached["region_mask"])
                        if needs_roi_mask and "roi_mask" in cached:
                            channels = channels.with_channel(ChannelName("roi_mask"), cached["roi_mask"])
                        if needs_tracks and "tracks" in cached:
                            channels = channels.with_channel(ChannelName("tracks"), cached["tracks"])

                        # Now run overlays only
                        for key in active_keys:
                            _, overlay_cls, _, _ = OVERLAY_REGISTRY[key]
                            overlay = overlay_cls()
                            channels = overlay.run(frame_index=frame_idx, channels=channels, config=export_config)

                        processed = channels.get(ChannelName("frame"))
                        
                        # Score frame for key frame capture
                        if keyframe_capture is not None:
                            flow_uv = channels.get(ChannelName("flow_uv")) if channels.has(ChannelName("flow_uv")) else None
                            vorticity = channels.get(ChannelName("vorticity")) if channels.has(ChannelName("vorticity")) else None
                            divergence = channels.get(ChannelName("divergence")) if channels.has(ChannelName("divergence")) else None
                            
                            particle_count = 0
                            if channels.has(ChannelName("tracks")):
                                tracks = channels.get(ChannelName("tracks"))
                                if tracks:
                                    particle_count = len(tracks)
                            
                            keyframe_capture.score_frame(
                                frame_index=frame_idx,
                                flow_uv=flow_uv,
                                particle_count=particle_count,
                                vorticity=vorticity,
                                divergence=divergence,
                            )
                    else:
                        processed = frame

                    # write only on final pass
                    if pass_idx == (num_passes - 1):
                        try:
                            # Validate frame dimensions before writing
                            if processed.shape[1] != output_width or processed.shape[0] != output_height:
                                processed = cv2.resize(processed, (output_width, output_height), interpolation=cv2.INTER_LINEAR)
                            writer.write(processed)
                        except Exception:
                            # If overlay rendering failed for this frame, fall back to raw frame
                            try:
                                fallback = frame
                                if fallback.shape[1] != output_width or fallback.shape[0] != output_height:
                                    fallback = cv2.resize(fallback, (output_width, output_height), interpolation=cv2.INTER_LINEAR)
                                writer.write(fallback)
                            except Exception:
                                # give up on this frame but continue
                                pass

                    prev_frame = frame.copy()

                    # Update progress: combine pass and frame progress
                    overall = ((pass_idx + (frame_idx + 1) / max(1, total_frames)) / max(1, num_passes)) * 100
                    elapsed = time.time() - start_time
                    fps_actual = (frame_idx + 1) / elapsed if elapsed > 0 else 0
                    eta = ((total_frames - frame_idx - 1) / fps_actual if fps_actual > 0 else 0) + ((num_passes - pass_idx - 1) * total_frames / max(1, fps_actual))
                    self.after(0, lambda p=overall, f=frame_idx, e=eta: self._update_export_progress(p, f, total_frames, e))

                # Persist cache after each compute pass
                if pass_idx < (num_passes - 1):
                    try:
                        with open(cache_file, "wb") as fh:
                            pickle.dump(frame_cache, fh)
                    except Exception:
                        pass

            cap.release()
            # Ensure writer is released before any file operations
            try:
                writer.release()
            except Exception:
                pass
            # After export, derive calibration from cached frames (if any)
            try:
                mags_p50 = []
                mags_p90 = []
                region_areas = []
                for k, v in frame_cache.items():
                    flow_uv = v.get("flow_uv")
                    if flow_uv is None:
                        continue
                    mag = np.sqrt(flow_uv[..., 0]**2 + flow_uv[..., 1]**2)
                    mags_p50.append(float(np.median(mag)))
                    mags_p90.append(float(np.percentile(mag, 90)))
                    if "region_mask" in v and v["region_mask"] is not None:
                        labels = v["region_mask"]
                        if labels.max() > 0:
                            counts = np.bincount(labels.ravel())
                            areas = counts[1:]
                            if areas.size > 0:
                                region_areas.append(float(np.median(areas)))

                if len(mags_p50) > 0:
                    p50 = float(np.median(mags_p50))
                    p90 = float(np.median(mags_p90)) if mags_p90 else p50
                    median_region_area = float(np.median(region_areas)) if region_areas else 0.0
                    recommended_max_dist = max(3, int(round(3.0 * p50)))
                    colorbar_min = max(0.0, p50 * 0.1)
                    colorbar_max = p90
                    stats = {
                        "sampled_frames": len(mags_p50),
                        "flow_p50": p50,
                        "flow_p90": p90,
                        "recommended_max_dist": recommended_max_dist,
                        "median_region_area": median_region_area,
                        "colorbar_range": [colorbar_min, colorbar_max]
                    }
                    cache_path = self._write_calibration(self.video_path, stats)
                    if cache_path:
                        self.status_var.set(f"Export complete — calibration saved: {os.path.basename(cache_path)}")
            except Exception:
                pass
            if self.export_cancel:
                # Remove temp file if it exists
                try:
                    if os.path.exists(tmp_output):
                        os.remove(tmp_output)
                except Exception:
                    pass
                self._export_done("Export cancelled")
            else:
                # Rename temporary file to final path atomically where possible
                try:
                    if os.path.exists(tmp_output):
                        try:
                            os.replace(tmp_output, output_path)
                        except Exception:
                            # last resort
                            os.rename(tmp_output, output_path)
                except Exception:
                    pass

                # Extract key frames if enabled
                if keyframe_capture is not None:
                    self.status_var.set("Extracting key frames...")
                    try:
                        keyframes_dir = Path(self.video_path).parent / (Path(self.video_path).stem + "_keyframes")
                        saved_frames = extract_keyframes_to_dir(
                            Path(self.video_path),
                            keyframe_capture.get_top_frame_indices(),
                            keyframes_dir,
                            keyframe_capture.get_top_frames(),
                        )
                        self.status_var.set(f"Extracted {len(saved_frames)} key frames")
                        
                        # Create composite grid if requested
                        if self.keyframe_grid_var.get():
                            self.status_var.set("Creating key frames composite grid...")
                            grid_path = keyframes_dir.parent / (keyframes_dir.name + "_grid.jpg")
                            
                            # Load the saved frames for grid
                            frames_dict = {}
                            cap_grid = cv2.VideoCapture(str(self.video_path))
                            frame_idx = 0
                            for target_idx in keyframe_capture.get_top_frame_indices():
                                while frame_idx < target_idx:
                                    ret, _ = cap_grid.read()
                                    if not ret:
                                        break
                                    frame_idx += 1
                                if frame_idx == target_idx:
                                    ret, frame = cap_grid.read()
                                    if ret:
                                        frames_dict[target_idx] = frame
                                    frame_idx += 1
                            cap_grid.release()
                            
                            if frames_dict:
                                save_keyframe_grid(frames_dict, grid_path, grid_shape=(2, 5), tile_size=(256, 256))
                                self.status_var.set("Key frames grid saved")
                        
                        # Print report
                        print("\n" + keyframe_capture.report())
                    except Exception as e:
                        print(f"Warning: failed to extract key frames: {e}")
                
                self._export_done(f"Export complete!\nSaved to: {os.path.basename(output_path)}")

        except Exception as e:
            import traceback
            traceback.print_exc()
            self._export_done(f"Export failed: {str(e)}")

    def _update_export_progress(self, progress, frame, total, eta):
        self.progress_var.set(progress)
        self.status_var.set(f"Exporting: {frame + 1}/{total} ({progress:.1f}%)\nETA: {int(eta)}s")

    def _export_done(self, message):
        def finish():
            self.exporting = False
            self._show_export_ui(False)
            self.status_var.set(message)
            self.progress_var.set(0)
        self.after(0, finish)

    def destroy(self):
        self.playing = False
        self.export_cancel = True
        if self.cap:
            self.cap.release()
        super().destroy()


if __name__ == "__main__":
    if not _PIL_OK:
        print("Pillow required. Install with: pip install Pillow", file=sys.stderr)
        sys.exit(1)
    app = OpticalFlowGUI()
    app.mainloop()
