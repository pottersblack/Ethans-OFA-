# Optical Flow Analyzer (Scaffold)

This workspace is the starting scaffold for a Windows optical-flow analyzer for Samsung Z Flip 3 slow‑mo videos.

## Goals (high level)

- Analyze motion inside a clear container (stabilization + interior masking)
- Compute optical flow and relative/unitless metrics
- Export video with overlays burned-in
- Keep **Preview** and **Export** modes strictly separated

## Run (scaffold)

The current implementation is a **pass-through** pipeline to validate video I/O and the plugin/channel skeleton.

## Notes

- CUDA optical flow is not provided by pip wheels; it requires building OpenCV with CUDA.
- Export mode will later recompute from raw frames and ignore Preview shortcuts.
- Cache format: the CLI supports `--cache-format` with `json` (default) or `pickle` for two-pass caches.
# Optical Flow Analyzer (Scaffold)

This workspace is the starting scaffold for a Windows optical-flow analyzer for Samsung Z Flip 3 slow‑mo videos.

## Goals (high level)

- Analyze motion inside a clear container (stabilization + interior masking)
- Compute optical flow and relative/unitless metrics
- Export video with overlays burned-in
- Keep **Preview** and **Export** modes strictly separated

## Run (scaffold)

The current implementation is a **pass-through** pipeline to validate video I/O and the plugin/channel skeleton.

Create/activate your venv, then:

```bash
pip install -r requirements.txt
python src/main.py --input path\\to\\video.mp4 --output out.mp4 --mode preview --scenario smoke_airflow
```

## Notes

- CUDA optical flow is not provided by pip wheels; it requires building OpenCV with CUDA.
- Export mode will later recompute from raw frames and ignore Preview shortcuts.
## ✨ Key Frame Capture Feature

Automatically extract the **10 most valuable frames** from your video based on motion metrics.

### Quick Start

**GUI Mode:**
```bash
python src/ui.py
# Check "Enable Key Frame Capture" → Click Export
```

**CLI Mode:**
```bash
# Extract 10 key frames
python src/main.py --input video.mp4 --capture-keyframes

# Export video + capture key frames
python src/main.py --input video.mp4 --output out.mp4 --mode export --capture-keyframes

# Create composite grid (2×5 summary image)
python src/main.py --input video.mp4 --capture-keyframes --keyframes-grid
```

### Scoring Metrics

Each frame is scored on 4 metrics (equal weight):
- **Optical Flow**: Motion activity and turbulence
- **Particle Count**: Number of detected objects
- **Vorticity**: Rotational motion intensity
- **Divergence**: Expansion/compression activity

Frames with 3+ high-value metrics get a 20% score bonus.

### Output

```
video_keyframes/                    # Extracted frames directory
├── keyframe_000142_0.847.jpg      # High-quality frame
├── keyframe_000142_0.847.txt      # Metadata (score, metrics)
└── ...

video_keyframes_grid.jpg            # Optional 2×5 composite (1280×512)
video_keyframes_report.txt          # Ranked list of frames
```

### Use Cases
- Extract key moments for scientific papers
- Create visual summaries for presentations
- Identify highest-turbulence regions
- Build frame collections for manual analysis

### Documentation

- **Quick Start**: See [KEYFRAME_QUICK_START.md](docs/KEYFRAME_QUICK_START.md)
- **Full Guide**: See [keyframe_capture.md](docs/keyframe_capture.md)
- **Technical**: See [KEYFRAME_IMPLEMENTATION.md](docs/KEYFRAME_IMPLEMENTATION.md)

### Options

**GUI:**
- ☑ Enable Key Frame Capture
- 📊 Num. Frames (1-50, default: 10)
- 🖼️ Save Composite Grid

**CLI:**
```
--capture-keyframes          Enable key frame capture
--keyframes-dir PATH         Output directory
--keyframes-count N          Number of frames (default: 10)
--keyframes-grid             Create composite grid image
```