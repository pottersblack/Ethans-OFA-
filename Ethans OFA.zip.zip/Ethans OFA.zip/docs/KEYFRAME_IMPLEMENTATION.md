# Key Frame Capture Implementation Details

## Architecture Overview

The key frame capture feature is integrated into the pipeline as a **post-processing step** that runs parallel to the main video processing:

```
Video Processing Flow:
├── Frame Loading (VideoCapture)
├── Optical Flow Computation
├── Particle Tracking (optional)
├── Overlay Rendering
├── Frame Output
└── Key Frame Scoring ← NEW (happens during final pass)
    └── Key Frame Extraction (after export completes)
```

## Components

### 1. Core Module: `src/pipeline/keyframe_capture.py`

**Class: `KeyFrameCapture`**

```python
class KeyFrameCapture:
    def __init__(self, num_frames: int = 10, score_weights: dict = None)
    def score_frame(self, frame_index: int, flow_uv, particle_count, ...) -> FrameScore
    def get_top_frames() -> list[FrameScore]
    def get_top_frame_indices() -> list[int]
    def report() -> str
    def save_report(path: str) -> None
```

**Class: `FrameScore`**

```python
@dataclass
class FrameScore:
    frame_index: int
    score: float
    flow_magnitude: float = 0.0
    particle_count: int = 0
    vorticity_energy: float = 0.0
    divergence_energy: float = 0.0
    description: str = ""
```

### 2. Extraction Module: `src/pipeline/keyframe_extract.py`

**Functions:**
- `extract_keyframes_to_dir()` - Save selected frames to disk with metadata
- `create_keyframe_grid()` - Create a composite image grid
- `save_keyframe_grid()` - Save grid to file

## Integration Points

### CLI Integration (`src/main.py`)

**New arguments:**
```
--capture-keyframes           # Enable key frame capture
--keyframes-dir PATH          # Output directory
--keyframes-count N           # Number of frames (default: 10)
--keyframes-grid              # Create composite grid
```

**Process flow:**
1. Parse arguments
2. Initialize `KeyFrameCapture` if `--capture-keyframes` is set
3. Pass instance to `process_capture()`
4. During final pass, score each frame
5. After export, extract and save frames

### GUI Integration (`src/ui.py`)

**New UI Controls:**
- Checkbox: "Enable Key Frame Capture"
- Spinbox: "Num. Frames" (1-50)
- Checkbox: "Save Composite Grid"

**Export flow:**
1. User enables key frame capture and clicks Export
2. `KeyFrameCapture` instance created with settings
3. During multi-pass export, frames are scored
4. After export completes:
   - Print ranking report
   - Extract frame images
   - (Optional) Create composite grid
5. Display completion status

## Scoring Algorithm

### Step 1: Compute Component Scores

**Flow Score:**
```python
mag = sqrt(flow_uv[..., 0]**2 + flow_uv[..., 1]**2)
flow_mean = mean(mag)
flow_std = std(mag)
flow_score = min(1.0, (flow_mean + 0.5 * flow_std) / 100.0)
```

**Particle Score:**
```python
particle_score = min(1.0, particle_count / 100.0)
```

**Vorticity Score:**
```python
vort_score = min(1.0, mean(abs(vorticity)))
```

**Divergence Score:**
```python
div_score = min(1.0, mean(abs(divergence)))
```

### Step 2: Weighted Sum

```python
score = w_flow × flow_score + w_particles × particle_score 
      + w_vorticity × vort_score + w_divergence × div_score
```

Default: all weights = 0.25 (equal importance)

### Step 3: Apply Multi-Signal Boost

```python
num_high_metrics = count([
    flow_magnitude > 1.0,
    particle_count > 5,
    vorticity_energy > 0.1,
    divergence_energy > 0.1,
])

if num_high_metrics >= 3:
    score *= 1.2  # 20% bonus for complex frames
```

### Step 4: Select Top N

```python
sorted_frames = sorted(frame_scores, key=lambda x: x.score, reverse=True)
top_n = sorted_frames[:num_frames]
```

## Data Flow Diagram

```
Input Video
    ↓
┌───────────────────────────────┐
│ Frame Processing (per frame)  │
├───────────────────────────────┤
│ 1. Read frame                 │
│ 2. Compute optical flow       │
│ 3. Run particle tracker       │
│ 4. Render overlays            │
│ 5. [NEW] Score frame         │ ← KeyFrameCapture.score_frame()
│ 6. Write to output video      │
└───────────────────────────────┘
    ↓
Frame Scores Collected
    ↓
┌───────────────────────────────┐
│ Post-Export Processing        │
├───────────────────────────────┤
│ 1. Sort frames by score       │
│ 2. Extract top 10             │
│ 3. Save images + metadata     │
│ 4. [Optional] Create grid     │
│ 5. Generate report            │
└───────────────────────────────┘
    ↓
Output:
├── {video}_keyframes/
│   ├── keyframe_000142_0.847.jpg
│   ├── keyframe_000142_0.847.txt
│   ├── ...
│   └── keyframe_000089_0.751.jpg
├── {video}_keyframes_grid.jpg (optional)
└── {video}_keyframes_report.txt
```

## Performance Characteristics

### Memory Usage
- Per-frame: ~10 KB per score (negligible)
- Total: 10 frames × 10 KB = 100 KB for top frames

### Computation Time
- Scoring per frame: ~1-2 ms (negligible vs. flow computation)
- Extraction per frame: ~10-50 ms (disk I/O bound)
- Grid creation: ~100 ms

### Example Timings (1080p, 30 FPS, 30 min video)

| Operation | Time |
|-----------|------|
| Video export | ~1 hour 50 min |
| Key frame scoring | ~30 sec (overhead) |
| Key frame extraction | ~1 min |
| Grid creation | ~1 sec |
| **Total** | ~1 hour 52 min |

## Design Decisions

### Why Post-Processing?
- **Separation of concerns**: Scoring doesn't affect rendering
- **Efficiency**: Reuses computed metrics (flow, tracks, etc.)
- **Flexibility**: Can adjust scoring after export

### Why Score During Export?
- **No extra passes**: Piggyback on existing frame processing
- **Full metrics available**: All overlays have computed values
- **Real-time responsiveness**: Don't need to re-read video

### Why Not Store All Metrics?
- **Memory efficiency**: Only store scores, not full arrays
- **Simplicity**: No need for large matrix operations
- **Reproducibility**: Scores can be recomputed from video

## Extensibility

### Adding New Scoring Metrics

1. Modify `KeyFrameCapture.score_frame()`:
```python
def score_frame(self, ..., new_metric=None):
    # Compute component score
    new_score = self._score_new_metric(new_metric)
    
    # Add to total
    score += self.weights.get('new_metric', 0.0) * new_score
```

2. Update UI/CLI to pass new metric from channels

### Custom Scoring Functions

Users can override scoring:
```python
class CustomKeyFrameCapture(KeyFrameCapture):
    def score_frame(self, **kwargs):
        # Custom scoring logic
        return FrameScore(...)
```

## Testing

### Unit Tests (`tests/test_keyframe_capture.py`)

Covers:
- Basic initialization
- Frame scoring with various metrics
- Top frame selection
- Grid creation
- Report generation

Run:
```bash
python -m pytest tests/test_keyframe_capture.py -v
```

### Integration Testing

Manually verify:
1. CLI mode extracts key frames correctly
2. GUI mode displays progress and results
3. Extracted frames have correct metadata
4. Grid image has correct layout
5. Report lists frames in correct order

## Known Limitations

1. **No temporal diversity**: May select consecutive similar frames
   - *Future*: Add frame-to-frame similarity check
   
2. **Fixed metrics**: Cannot customize which metrics to use
   - *Future*: Configuration file for metric selection
   
3. **Simple grid layout**: Fixed 2×5 grid
   - *Future*: Configurable grid dimensions
   
4. **No clustering**: No grouping of similar key frames
   - *Future*: k-means clustering for diverse selection

## Compatibility

- ✅ Works with all overlay types
- ✅ Works with particle tracking
- ✅ Works with multi-pass export
- ✅ Works with cache files
- ✅ Works with custom scenarios
- ✅ GPU/CPU agnostic

## Future Enhancements

Priority 1:
- [ ] Temporal diversity enforcement
- [ ] Configurable grid dimensions
- [ ] Per-metric weighting in UI

Priority 2:
- [ ] Visual similarity clustering
- [ ] Automatic metric detection
- [ ] Batch key frame extraction

Priority 3:
- [ ] Machine learning-based scoring
- [ ] Custom scorer plugins
- [ ] Interactive frame selection tool
