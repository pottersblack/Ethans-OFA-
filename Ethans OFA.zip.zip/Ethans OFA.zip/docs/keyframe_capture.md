# Key Frame Capture Feature

## Overview

The Key Frame Capture feature automatically identifies and extracts the **10 most valuable frames** from a video based on computed metrics. This helps you quickly see the frames with the most interesting motion, particle activity, and turbulence.

## How It Works

### Scoring Metrics

Each frame is scored based on four metrics:

1. **Optical Flow Magnitude** (25% weight)
   - Mean flow magnitude + standard deviation
   - Indicates overall motion activity and turbulence
   - Normalized to 0-1 range

2. **Particle Count** (25% weight)
   - Number of detected particles/tracks
   - Shows frames with most detected features
   - Normalized: count / 100

3. **Vorticity Energy** (25% weight)
   - Mean absolute vorticity
   - Identifies rotational motion regions
   - Indicates turbulent swirling

4. **Divergence Energy** (25% weight)
   - Mean absolute divergence
   - Shows expansion/compression regions
   - Indicates expansion or collapse of fluid

### Bonus Scoring

Frames with **3+ high-value metrics** receive a 20% score boost:
- Flow magnitude > 1.0
- Particle count > 5
- Vorticity energy > 0.1
- Divergence energy > 0.1

This ensures multi-signal frames with complex motion are prioritized.

## Usage

### GUI Mode

1. **Enable Key Frame Capture**
   - Check "Enable Key Frame Capture" in the Key Frame Capture section
   
2. **Configure Options**
   - Set "Num. Frames" to desired count (default: 10)
   - Enable "Save Composite Grid" to create a visual summary

3. **Export**
   - Click Export to process the video
   - Key frames are automatically extracted after export completes

4. **Results**
   - Key frames are saved to a directory named `{video}_keyframes/`
   - Each frame has a score and metadata file
   - A report is printed showing frame rankings
   - Optional grid image `{video}_keyframes_grid.jpg`

### CLI Mode

```bash
# Extract 10 key frames with default settings
python src/main.py --input video.mp4 --capture-keyframes

# Specify output directory for key frames
python src/main.py --input video.mp4 --capture-keyframes --keyframes-dir ./key_frames

# Capture 15 frames instead of 10
python src/main.py --input video.mp4 --capture-keyframes --keyframes-count 15

# Save composite grid image
python src/main.py --input video.mp4 --capture-keyframes --keyframes-grid

# Full export with key frame capture
python src/main.py --input video.mp4 --output output.mp4 --mode export --capture-keyframes --keyframes-grid
```

## Output Files

### Key Frame Images
- **Filename**: `keyframe_{frame_index:06d}_{score:.3f}.jpg`
- **Location**: `{video}_keyframes/` directory
- **Format**: JPG (original video resolution)

### Metadata Files
For each key frame, a metadata file is created:
- **Filename**: `keyframe_{frame_index:06d}_{score:.3f}.txt`
- **Contents**:
  ```
  Frame Index: 142
  Score: 0.847632
  Flow Magnitude: 2.451200
  Particle Count: 12
  Vorticity Energy: 0.123456
  Divergence Energy: 0.098765
  Metrics: flow=2.45 | particles=12 | vort=0.123 | div=0.099
  ```

### Composite Grid
- **Filename**: `{video}_keyframes_grid.jpg`
- **Layout**: 2 rows × 5 columns (10 frames total)
- **Tile Size**: 256×256 pixels
- **Total**: 1280×512 pixels
- **Optional**: Only created if --keyframes-grid flag is set

### Report File
- **Filename**: `{video}_keyframes_report.txt`
- **Contents**: Ranked list of top frames with scores and metrics

## Algorithm Details

### Frame Scoring Formula

```
score = w_flow × flow_score + w_particles × particle_score + w_vort × vort_score + w_div × div_score

# Each component is normalized to [0, 1]:
flow_score = min(1.0, (mean_mag + 0.5 × std_mag) / 100.0)
particle_score = min(1.0, particle_count / 100.0)
vort_score = min(1.0, mean(|vorticity|))
div_score = min(1.0, mean(|divergence|))

# Multi-signal bonus
if high_metrics ≥ 3:
    score *= 1.2
```

### Customization

To change scoring weights, modify the `KeyFrameCapture` initialization:

```python
from pipeline.keyframe_capture import KeyFrameCapture

weights = {
    'flow': 0.4,        # Emphasize motion
    'particles': 0.2,
    'vorticity': 0.2,
    'divergence': 0.2,
}

kfc = KeyFrameCapture(num_frames=10, score_weights=weights)
```

## Integration with Analysis Pipeline

Key frame capture works with all overlay modes:
- **Preview mode**: Frames are scored but not extracted (fast)
- **Export mode**: Frames are extracted after overlay processing

The feature respects:
- All optical flow settings
- Particle tracker parameters
- Custom weight configurations
- Frame range limits (max-frames)

## Performance

- **Scoring**: ~1ms per frame (negligible overhead)
- **Extraction**: ~10-50ms per frame (disk I/O dependent)
- **Total overhead**: ~5-10% of export time

For a 30-minute 1080p video at 30 FPS:
- Scoring: ~54 seconds
- Extraction of 10 frames: ~5 seconds
- Total: ~1 minute additional time

## Limitations

1. **Maximum Frames**: Limited by system memory when storing all metrics
2. **Video Length**: Works best on videos with significant motion
3. **Static Content**: May not select frames from pure static scenes
4. **Custom Metrics**: Currently uses predefined metrics only

## Examples

### Identify Most Turbulent Frames
Use this to find regions with maximum flow complexity:
```bash
python src/main.py --input turbulence.mp4 --capture-keyframes --keyframes-count 5
```

### Create Visual Summary
Extract frames for a conference presentation:
```bash
python src/main.py --input data.mp4 --capture-keyframes --keyframes-grid
```
Then use the composite grid image in your slides.

### Batch Processing
Extract key frames from multiple videos:
```bash
for video in *.mp4; do
    python src/main.py --input "$video" --capture-keyframes --keyframes-grid
done
```

## Troubleshooting

**Issue**: No key frames extracted
- **Cause**: Video has no motion/particles
- **Fix**: Check that overlays are enabled and flow is detected

**Issue**: Key frames all look identical
- **Cause**: Low-motion or high-fps video
- **Fix**: Reduce video frame rate or use different scenario

**Issue**: Grid image is black
- **Cause**: Frame extraction failed
- **Fix**: Check disk space and directory permissions

## Future Enhancements

Potential improvements:
- [ ] Custom scoring functions
- [ ] Temporal diversity (avoid consecutive similar frames)
- [ ] Automatic scenario detection
- [ ] Interactive frame selection GUI
- [ ] Key frame clustering by visual similarity
