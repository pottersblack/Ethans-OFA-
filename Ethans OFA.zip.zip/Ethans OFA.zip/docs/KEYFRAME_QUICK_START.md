# Key Frame Capture Feature - Quick Start Guide

## What is Key Frame Capture?

Key Frame Capture automatically selects and saves **10 frames with the most valuable motion data** from your video. This helps you:
- Identify the most interesting moments in your video
- Create a visual summary of key events
- Extract high-quality frames for presentation/analysis
- Find regions with peak turbulence or particle activity

## Quick Start

### GUI Mode (Easiest)

1. Open the application: `python src/ui.py`
2. Load your video
3. Check **"Enable Key Frame Capture"** in the sidebar
4. (Optional) Adjust "Num. Frames" if you want more/fewer key frames
5. (Optional) Check "Save Composite Grid" to create a summary image
6. Click **Export**
7. Key frames will be automatically extracted to `{video}_keyframes/`

### Command Line Mode

```bash
# Basic usage (extracts 10 frames)
python src/main.py --input your_video.mp4 --capture-keyframes

# Export video AND capture key frames
python src/main.py --input your_video.mp4 --output output.mp4 --mode export --capture-keyframes

# Capture 15 frames instead of 10
python src/main.py --input your_video.mp4 --capture-keyframes --keyframes-count 15

# Create composite grid image
python src/main.py --input your_video.mp4 --capture-keyframes --keyframes-grid
```

## What You Get

### Extracted Frames
- **Location**: `{video_name}_keyframes/` directory
- **Files**: 
  - `keyframe_000001_0.842.jpg` (frame image)
  - `keyframe_000001_0.842.txt` (metadata)
- **Metadata includes**: score, flow magnitude, particle count, vorticity, divergence

### Composite Grid (Optional)
- **File**: `{video_name}_keyframes_grid.jpg`
- **Layout**: 2×5 grid of the 10 best frames
- **Size**: 1280×512 pixels
- **Use case**: Quick visual summary for presentations

### Report
- **File**: `{video_name}_keyframes_report.txt`
- **Contents**: Ranked list of all captured frames with scores

## Scoring Algorithm

Each frame is rated on 4 metrics (equal weight):

| Metric | Measures | Why It Matters |
|--------|----------|---|
| **Optical Flow** | Motion magnitude | Shows most active regions |
| **Particles** | Detected objects | Frames with most features |
| **Vorticity** | Rotational motion | Turbulent swirling |
| **Divergence** | Expansion/compression | Dynamic changes |

**Bonus**: Frames with **3+ high-value metrics** get a 20% score boost

## Example Results

```
Top 10 Key Frames:
-----------
 1. Frame 142 | Score: 0.8476 | flow=2.45 | particles=12 | vort=0.123 | div=0.099
 2. Frame 139 | Score: 0.8342 | flow=2.38 | particles=10 | vort=0.118 | div=0.094
 3. Frame 145 | Score: 0.8201 | flow=2.31 | particles=11 | vort=0.115 | div=0.092
 ...
```

Each frame is saved as high-quality JPG at your video's original resolution.

## Common Uses

### 1. Scientific Paper Figures
Extract key frames showing critical moments:
```bash
python src/main.py --input experiment.mp4 --capture-keyframes --keyframes-count 5
```

### 2. Conference Presentations
Create visual summary:
```bash
python src/main.py --input demo.mp4 --capture-keyframes --keyframes-grid
```
Use the grid image in your slides.

### 3. Manual Review
Extract top frames for detailed analysis:
```bash
python src/main.py --input data.mp4 --capture-keyframes
# Then review images in `data_keyframes/` directory
```

### 4. Batch Processing
Process multiple videos:
```powershell
Get-ChildItem *.mp4 | ForEach-Object {
    python src/main.py --input $_.FullName --capture-keyframes --keyframes-grid
}
```

## Customization

### Change Number of Frames

**GUI**: Set "Num. Frames" spinbox (1-50)

**CLI**: 
```bash
python src/main.py --input video.mp4 --capture-keyframes --keyframes-count 20
```

### Custom Output Location

**CLI**:
```bash
python src/main.py --input video.mp4 --capture-keyframes --keyframes-dir "C:\MyFrames"
```

### Adjust Scoring Weights (Advanced)

Edit `src/pipeline/keyframe_capture.py` and modify the `KeyFrameCapture.__init__()` weights:

```python
# Default: equal weight (0.25 each)
# Change to emphasize motion:
weights = {
    'flow': 0.4,
    'particles': 0.2,
    'vorticity': 0.2,
    'divergence': 0.2,
}
```

## Performance

- **Overhead**: ~5-10% additional export time
- **Storage**: ~1-10 MB per 10 extracted frames (depends on resolution)
- **Speed**: Real-time scoring during video processing

Example: 30-minute 1080p video
- Export time: ~2 hours
- Key frame capture: +~6 minutes
- Total: ~2 hours 6 minutes

## Tips & Tricks

✅ **Best Practices**
- Use with high-quality flow settings for better scoring
- Enable particle tracking if analyzing particle-heavy flows
- Use grid option to quickly evaluate results
- Process one video at a time for consistent scoring

❌ **Avoid**
- Using on static/non-moving video (no motion = low scores)
- Capturing too many frames (>50) from short videos
- Processing very high resolution videos without GPU

## Troubleshooting

| Problem | Solution |
|---------|----------|
| No key frames extracted | Check that flow detection works (try preview mode first) |
| All frames look similar | Video may be low-motion; try lower fps or different scenario |
| Grid image is black | Ensure extraction completed; check disk space |
| Very slow processing | Enable GPU boost in GUI or use `--device cuda` |

## See Also

- [Detailed Key Frame Capture Documentation](keyframe_capture.md)
- [Main CLI Arguments](../README.md)
- [Overlay Documentation](overlays/)

## Need Help?

1. Check that your video loads in preview mode first
2. Ensure optical flow is enabled (visible in preview)
3. Start with default settings (10 frames, no grid)
4. Check `problem.txt` for error messages
