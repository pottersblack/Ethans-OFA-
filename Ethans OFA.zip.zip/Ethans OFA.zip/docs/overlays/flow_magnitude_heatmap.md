# Overlay Documentation: Flow Magnitude Heatmap

## Description
The Flow Magnitude Heatmap overlay visualizes the speed of optical flow vectors as a color-coded heatmap. Higher speeds are mapped to warmer colors (red/yellow), lower speeds to cooler colors (blue/green).

## Legend
A colorbar is displayed at the bottom right, with "Low" and "High" labels indicating the range of flow magnitudes.

## Example
![Flow Magnitude Heatmap Example](example_flow_magnitude_heatmap.png)

## Usage
- Enable the overlay in the GUI sidebar or via CLI overlay selection.
- The overlay requires the `flow_uv` channel (computed by the flow plugin).
- In Preview mode, the overlay auto-scales to fit VRAM limits.

## User Guidance
- Use this overlay to quickly identify regions of high/low motion.
- For quantitative analysis, refer to the legend and consider enabling the Quantitative Metrics HUD overlay.

---

*Document each overlay in a similar format. Add sample images after running on real data.*
