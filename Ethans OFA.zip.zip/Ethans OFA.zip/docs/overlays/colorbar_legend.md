# Overlay Documentation: Colorbar/Legend

## Description
The Colorbar/Legend overlay displays a pull-up colorbar for overlays, with adjustable position.

## Legend
A colorbar is displayed at the selected position, labeled "Low" and "High".

## Example
![Colorbar Legend Example](example_colorbar_legend.png)

## Usage
- Enable the overlay in the GUI sidebar or via CLI overlay selection.
- The overlay requires the `frame` channel.
- Position is adjustable (e.g., bottomright, topleft).
- In Preview mode, overlay settings auto-populate Export (except scaling/quantization).

## User Guidance
- Use this overlay to provide a color reference for other overlays.
- For quantitative analysis, combine with Quantitative Metrics HUD overlay.

---

*Document each overlay in a similar format. Add sample images after running on real data.*
