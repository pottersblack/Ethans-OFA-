# Overlay Documentation: Vorticity Map

## Description
The Vorticity Map overlay visualizes the curl (rotation) of the optical flow field. Regions of high vorticity indicate swirling or rotational motion.

## Legend
A colorbar is displayed at the bottom right, with "Low" and "High" labels and a "Vorticity" label indicating the range of vorticity values.

## Example
![Vorticity Map Example](example_vorticity_map.png)

## Usage
- Enable the overlay in the GUI sidebar or via CLI overlay selection.
- The overlay requires the `flow_uv` channel (computed by the flow plugin).
- In Preview mode, the overlay auto-scales for performance.

## User Guidance
- Use this overlay to identify regions of rotational flow, such as eddies or vortices.
- For quantitative analysis, refer to the legend and consider enabling the Quantitative Metrics HUD overlay.

---

*Document each overlay in a similar format. Add sample images after running on real data.*
