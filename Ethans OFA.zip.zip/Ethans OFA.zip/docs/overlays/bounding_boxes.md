# Overlay Documentation: Bounding Boxes

## Description
The Bounding Boxes overlay draws rectangles around segmented regions, labeling each with its region index. Useful for inspecting detected objects, bubbles, or turbulent regions.

## Legend
Color squares are displayed at the bottom left, each labeled with its region index.

## Example
![Bounding Boxes Example](example_bounding_boxes.png)

## Usage
- Enable the overlay in the GUI sidebar or via CLI overlay selection.
- The overlay requires the `region_mask` channel (segmentation labels).
- In Preview mode, the overlay auto-scales for performance.

## User Guidance
- Use this overlay to inspect region extents and bounding geometry.
- For quantitative analysis, combine with ROI Mask + Stats overlay.

---

*Document each overlay in a similar format. Add sample images after running on real data.*
