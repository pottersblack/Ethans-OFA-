# Overlay Documentation: Field Vector Density Plot

## Description
The Field Vector Density Plot overlay bins the flow field and colors each bin by local magnitude/density. Opacity is adjustable for blending.

## Legend
A colorbar is displayed at the bottom right, labeled "Vector Density".

## Example
![Field Vector Density Example](example_field_vector_density.png)

## Usage
- Enable the overlay in the GUI sidebar or via CLI overlay selection.
- The overlay requires the `flow_uv` channel (optical flow).
- Opacity is adjustable for blending.
- In Preview mode, overlay settings auto-populate Export (except scaling/quantization).

## User Guidance
- Use this overlay to inspect spatial distribution of flow magnitude.
- For quantitative analysis, combine with Quantitative Metrics HUD overlay.

---

*Document each overlay in a similar format. Add sample images after running on real data.*
