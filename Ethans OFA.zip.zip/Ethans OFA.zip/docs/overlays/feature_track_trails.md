# Overlay Documentation: Feature Track Trails

## Description
The Feature Track Trails overlay visualizes the history of tracked features as trails over the frame. Each track is shown as a colored line, with the most recent position marked.

## Legend
A label is displayed at the bottom left: "Feature Track Trails".

## Example
![Feature Track Trails Example](example_feature_track_trails.png)

## Usage
- Enable the overlay in the GUI sidebar or via CLI overlay selection.
- The overlay requires the `tracks` channel (list of feature tracks).
- In Preview mode, the overlay auto-scales for performance.

## User Guidance
- Use this overlay to inspect feature or particle tracking results.
- For quantitative analysis, combine with Track Metrics HUD overlay.

---

*Document each overlay in a similar format. Add sample images after running on real data.*
