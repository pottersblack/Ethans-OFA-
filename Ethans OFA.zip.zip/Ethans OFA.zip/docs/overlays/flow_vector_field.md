# Overlay Documentation: Flow Vector Field

## Description
The Flow Vector Field overlay visualizes optical flow vectors as arrows (quiver plot) over the frame. Arrow direction shows flow direction; color encodes direction (HSV), and length encodes speed.

## Legend
A scale arrow is shown at the bottom left, indicating the pixel length for arrows. "Direction: HSV" label explains color coding.

## Example
![Flow Vector Field Example](example_flow_vector_field.png)

## Usage
- Enable the overlay in the GUI sidebar or via CLI overlay selection.
- The overlay requires the `flow_uv` channel (computed by the flow plugin).
- In Preview mode, grid spacing auto-scales for performance.

## User Guidance
- Use this overlay to inspect local flow direction and magnitude.
- For dense scenes, increase grid spacing to reduce clutter.

---

*Document each overlay in a similar format. Add sample images after running on real data.*
