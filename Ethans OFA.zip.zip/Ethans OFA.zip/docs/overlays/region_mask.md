# Overlay Documentation: Region Mask

## Description
The Region Mask overlay visualizes segmentation masks, coloring each region with a distinct color. Useful for inspecting container, ROI, or object segmentation.

## Legend
Color squares are displayed at the bottom left, each labeled with its region index.

## Example
![Region Mask Example](example_region_mask.png)

## Usage
- Enable the overlay in the GUI sidebar or via CLI overlay selection.
- The overlay requires the `region_mask` channel (segmentation labels).
- In Preview mode, the overlay auto-scales for performance.

## User Guidance
- Use this overlay to inspect segmentation results and region boundaries.
- For quantitative analysis, combine with ROI Mask + Stats overlay.

---

*Document each overlay in a similar format. Add sample images after running on real data.*
