# Overlay Documentation: Error/Warning Overlay

## Description

The Error/Warning Overlay displays on-frame error or warning regions, icons, or pipeline status. It visualizes VRAM, threshold, or pipeline errors as colored regions or warning icons.

## Legend

- Red rectangle: Error region
- Orange circle with '!': Warning location

## Usage

- Enable the overlay in the GUI sidebar or via CLI overlay selection.
- Requires the `frame` channel. Optionally uses `error_mask` and/or `error_list` channels.
- Opacity and legend display are adjustable.
- In Preview mode, overlay is qualitative if `error_mask` is missing.

## User Guidance

- Use this overlay to highlight pipeline errors, VRAM issues, or threshold failures.
- For quantitative metrics, combine with Quantitative Metrics HUD overlay.

---

*Document each overlay in a similar format. Add sample images after running on real data.*
