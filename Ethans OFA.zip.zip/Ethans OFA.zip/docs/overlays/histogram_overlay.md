# Overlay Documentation: Histogram Overlay

## Description
The Histogram Overlay displays a histogram of the flow magnitude (|V|) as an inset in the frame. Opacity is adjustable for blending.

## Legend
A label is displayed near the inset: "Histogram: |V|".

## Example
![Histogram Overlay Example](example_histogram_overlay.png)

## Usage
- Enable the overlay in the GUI sidebar or via CLI overlay selection.
- The overlay requires the `flow_uv` channel (optical flow).
- Opacity is adjustable for blending.
- In Preview mode, overlay settings auto-populate Export (except scaling/quantization).

## User Guidance
- Use this overlay to inspect the distribution of flow magnitudes.
- For quantitative analysis, combine with Quantitative Metrics HUD overlay.

---

*Document each overlay in a similar format. Add sample images after running on real data.*
