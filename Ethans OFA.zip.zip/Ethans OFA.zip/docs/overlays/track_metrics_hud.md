# Overlay Documentation: Track Metrics HUD

## Description
The Track Metrics HUD overlay displays speed and direction (angle) for each tracked feature, labeling the most recent position of each track.

## Legend
A label is displayed at the bottom left: "Track Metrics HUD: V=speed, θ=angle".

## Example
![Track Metrics HUD Example](example_track_metrics_hud.png)

## Usage
- Enable the overlay in the GUI sidebar or via CLI overlay selection.
- The overlay requires the `tracks` channel (list of feature tracks).
- In Preview mode, the overlay auto-scales for performance.

## User Guidance
- Use this overlay to inspect per-track speed and direction.
- For more detailed metrics, combine with Quantitative Metrics HUD overlay.

---

*Document each overlay in a similar format. Add sample images after running on real data.*
