# Overlay Documentation: Particle/Bubble Tracking

## Description
The Particle/Bubble Tracking overlay visualizes detected particles and bubbles, labeling and counting each. Opacity is adjustable for blending.

## Legend
A green circle = bubble, yellow = particle. Count is shown at top left.

## Example
![Particle Bubble Tracking Example](example_particle_bubble_tracking.png)

## Usage
- Enable the overlay in the GUI sidebar or via CLI overlay selection.
- The overlay requires the `tracks` channel (list of detected particles/bubbles).
- Opacity is adjustable for blending.
- In Preview mode, overlay settings auto-populate Export (except scaling/quantization).

## User Guidance
- Use this overlay to inspect particle/bubble detection and tracking.
- For quantitative analysis, combine with Quantitative Metrics HUD overlay.

---

*Document each overlay in a similar format. Add sample images after running on real data.*
