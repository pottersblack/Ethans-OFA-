# Overlay Documentation: Centroid Labels

## Description
The Centroid Labels overlay computes and labels the center of each segmented region. Useful for tracking region centers and object positions.

## Legend
Color squares are displayed at the bottom left, each labeled with its region index.

## Example
![Centroid Labels Example](example_centroid_labels.png)

## Usage
- Enable the overlay in the GUI sidebar or via CLI overlay selection.
- The overlay requires the `region_mask` channel (segmentation labels).
- In Preview mode, the overlay auto-scales for performance.

## User Guidance
- Use this overlay to inspect region centers and track object positions.
- For quantitative analysis, combine with Track Metrics HUD overlay.

---

*Document each overlay in a similar format. Add sample images after running on real data.*
