# Overlay Documentation: Shear/Strain Rate Map

## Description
The Shear/Strain Rate Map overlay visualizes sliding or stretching motion in the optical flow field. High values indicate regions of strong shear or strain.

## Legend
A colorbar is displayed at the bottom right, with "Low" and "High" labels and a "Shear/Strain" label indicating the range of values.

## Example
![Shear Strain Map Example](example_shear_strain_map.png)

## Usage
- Enable the overlay in the GUI sidebar or via CLI overlay selection.
- The overlay requires the `flow_uv` channel (computed by the flow plugin).
- In Preview mode, the overlay auto-scales for performance.

## User Guidance
- Use this overlay to identify regions of sliding or stretching motion, such as shear layers or strain zones.
- For quantitative analysis, refer to the legend and consider enabling the Quantitative Metrics HUD overlay.

---

*Document each overlay in a similar format. Add sample images after running on real data.*
