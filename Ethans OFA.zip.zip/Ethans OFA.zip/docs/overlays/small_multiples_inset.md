# Overlay Documentation: Small Multiples/Inset Views

## Description
The Small Multiples/Inset Views overlay displays insets of derived fields (e.g., flow magnitude, vorticity) in the frame corners. Opacity is adjustable for blending.

## Legend
A label is displayed at the bottom left: "Insets: |V|=magnitude, curl=vorticity".

## Example
![Small Multiples Inset Example](example_small_multiples_inset.png)

## Usage
- Enable the overlay in the GUI sidebar or via CLI overlay selection.
- The overlay requires the `flow_uv` channel (optical flow).
- Opacity is adjustable for blending.
- In Preview mode, overlay settings auto-populate Export (except scaling/quantization).

## User Guidance
- Use this overlay to inspect multiple derived fields at a glance.
- For quantitative analysis, combine with Quantitative Metrics HUD overlay.

---

*Document each overlay in a similar format. Add sample images after running on real data.*
