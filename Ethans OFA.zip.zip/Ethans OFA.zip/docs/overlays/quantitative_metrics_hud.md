# Overlay Documentation: Quantitative Metrics HUD

## Description
The Quantitative Metrics HUD overlay displays mean and max flow magnitude (|V|) and, if available, per-region means as on-frame labels.

## Legend
A label is displayed at the bottom left: "Quantitative Metrics: |V|=flow mag".

## Example
![Quantitative Metrics HUD Example](example_quantitative_metrics_hud.png)

## Usage
- Enable the overlay in the GUI sidebar or via CLI overlay selection.
- The overlay requires the `flow_uv` channel (optical flow). If `region_mask` is present, per-region stats are shown.
- In Preview mode, overlay settings auto-populate Export (except scaling/quantization).

## User Guidance
- Use this overlay to inspect global and per-region flow statistics.
- For more detailed analysis, export metrics as JSON.

---

*Document each overlay in a similar format. Add sample images after running on real data.*
