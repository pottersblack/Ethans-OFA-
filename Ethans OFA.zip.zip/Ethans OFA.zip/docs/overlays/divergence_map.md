# Overlay Documentation: Divergence Map

## Description
The Divergence Map overlay visualizes the expansion or contraction of the optical flow field. Positive divergence indicates regions where flow is spreading out; negative divergence shows contraction.

## Legend
A colorbar is displayed at the bottom right, with "Low" and "High" labels and a "Divergence" label indicating the range of divergence values.

## Example
![Divergence Map Example](example_divergence_map.png)

## Usage
- Enable the overlay in the GUI sidebar or via CLI overlay selection.
- The overlay requires the `flow_uv` channel (computed by the flow plugin).
- In Preview mode, the overlay auto-scales for performance.

## User Guidance
- Use this overlay to identify regions of expansion (e.g., bubbles, jets) or contraction (e.g., sinks).
- For quantitative analysis, refer to the legend and consider enabling the Quantitative Metrics HUD overlay.

---

*Document each overlay in a similar format. Add sample images after running on real data.*
