# Overlay Documentation: ROI Mask + Stats

## Description
The ROI Mask + Stats overlay visualizes the region of interest (ROI) mask and displays area and mean flow statistics for the ROI.

## Legend
A colored square is displayed at the bottom left, labeled "ROI".

## Example
![ROI Mask Stats Example](example_roi_mask_stats.png)

## Usage
- Enable the overlay in the GUI sidebar or via CLI overlay selection.
- The overlay requires the `roi_mask` and `flow_uv` channels.
- In Preview mode, the overlay auto-scales for performance.

## User Guidance
- Use this overlay to inspect ROI segmentation and basic flow statistics.
- For advanced metrics, combine with Quantitative Metrics HUD overlay.

---

*Document each overlay in a similar format. Add sample images after running on real data.*
