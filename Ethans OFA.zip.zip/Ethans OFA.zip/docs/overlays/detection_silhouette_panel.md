# Detection Silhouette Panel Overlay

**Purpose:** Improves data interpretability by displaying a clean, simplified view of detected objects in a separate white panel next to the video.

## What It Does

The Detection Silhouette Panel creates a side-by-side view with:
- **Left side:** Original video with overlays
- **Right side (or left):** Clean white/black panel showing simplified outlines or filled shadows of detections

This makes it much easier to see "what was actually detected" without visual clutter from the video content.

## How It Works

The overlay automatically uses the best available detection data:

1. **Priority 1: Particle Tracks** (most accurate)
   - Uses `tracks` channel from ParticleTrackerPlugin
   - Draws circles at current particle positions
   - Shows track IDs as labels

2. **Priority 2: Region Mask** (connected components)
   - Uses `region_mask` channel (motion-based segmentation)
   - Draws bounding boxes or contours around regions
   - Shows region labels

3. **Priority 3: Flow Magnitude** (high-motion areas)
   - Uses `flow_uv` channel to find significant motion
   - Thresholds at 85th percentile to find top motion areas
   - Draws contours around motion regions

## Available Variants

The overlay comes in 3 preset configurations:

### 1. **Detection Panel (Black Outlines)**
- White background
- Black outline style (hollow shapes)
- Best for clean, minimalist view
- Easy to see individual shapes

### 2. **Detection Panel (Colored Filled)**
- White background
- Colored filled shapes
- Each detection gets a unique color
- Best for tracking multiple objects

### 3. **Detection Panel (Dark Mode)**
- Black background
- Colored filled shapes
- Good for dark UI themes
- High contrast for presentations

## Configuration Options

The base class `DetectionSilhouettePanelOverlay` supports:

```python
DetectionSilhouettePanelOverlay(
    panel_position="right",      # "right" or "left"
    panel_width_ratio=0.35,      # 0.1 to 1.0 (35% of video width)
    style="outline",             # "outline" or "filled"
    colored=False,               # True for colors, False for black
    background="white"           # "white", "black", or "gray"
)
```

## Usage Tips

1. **For tracking particles/bubbles:**
   - Enable tracking overlays to get `tracks` channel
   - Use "Colored Filled" variant to distinguish individual tracks

2. **For motion analysis:**
   - Works standalone with just flow data
   - Use "Black Outlines" for simplest view

3. **For presentations:**
   - "Dark Mode" variant looks great on projectors
   - Adjust panel width with `panel_width_ratio` parameter

4. **Reduce clutter:**
   - Disable other visual overlays on the video side
   - Let the panel show just the detection data
   - Keep HUD/metrics overlays for numbers

## Example Workflow

**Before (cluttered):**
- Video + Flow Heatmap + Bounding Boxes + Track Trails + Labels
- Hard to see what's actually detected

**After (with Detection Panel):**
- Video (clean or with single base overlay)
- Detection Panel showing simplified shapes
- Much clearer what the algorithm sees

## Technical Notes

- The panel scales detections proportionally to maintain aspect ratio
- Labels are hidden if more than 30-50 detections (to avoid clutter)
- Works in both Preview and Export modes
- No performance impact (simple drawing operations)
- Compatible with all other additive overlays

## Channel Dependencies

- **Required:** `frame` (always available)
- **Optional:** `tracks`, `region_mask`, `flow_uv` (uses whatever is available)
- Works as a standalone overlay or combined with tracking/region plugins
