# Overlay Documentation: Temporal Motion Heatmap

## Description
The Temporal Motion Heatmap overlay accumulates motion magnitude over time, visualizing persistent or repeated motion as a heatmap. Opacity is adjustable for blending.

## Legend
A colorbar is displayed at the bottom right, labeled "Accum Motion".

## Example
![Temporal Motion Heatmap Example](example_temporal_motion_heatmap.png)

## Usage
- Enable the overlay in the GUI sidebar or via CLI overlay selection.
- The overlay requires the `flow_uv` channel (optical flow).
- Opacity is adjustable for blending.
- In Preview mode, overlay settings auto-populate Export (except scaling/quantization).

## User Guidance
- Use this overlay to identify regions of persistent or repeated motion.
- For quantitative analysis, combine with Quantitative Metrics HUD overlay.

---

*Document each overlay in a similar format. Add sample images after running on real data.*
