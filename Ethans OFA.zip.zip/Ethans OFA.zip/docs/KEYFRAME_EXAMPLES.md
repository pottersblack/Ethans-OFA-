# Key Frame Capture - Example Outputs

## Sample Score Report

```
Top 10 Key Frames:
────────────────────────────────────────────────────────────────────────────
 1. Frame 000142 | Score: 0.8476 | flow=2.45 | particles=12 | vort=0.123 | div=0.099
 2. Frame 000139 | Score: 0.8342 | flow=2.38 | particles=10 | vort=0.118 | div=0.094
 3. Frame 000145 | Score: 0.8201 | flow=2.31 | particles=11 | vort=0.115 | div=0.092
 4. Frame 000151 | Score: 0.8067 | flow=2.19 | particles=9  | vort=0.108 | div=0.087
 5. Frame 000148 | Score: 0.7934 | flow=2.12 | particles=8  | vort=0.102 | div=0.081
 6. Frame 000154 | Score: 0.7801 | flow=2.05 | particles=7  | vort=0.098 | div=0.078
 7. Frame 000135 | Score: 0.7668 | flow=1.98 | particles=6  | vort=0.094 | div=0.075
 8. Frame 000157 | Score: 0.7534 | flow=1.91 | particles=5  | vort=0.090 | div=0.072
 9. Frame 000160 | Score: 0.7401 | flow=1.84 | particles=4  | vort=0.086 | div=0.069
10. Frame 000132 | Score: 0.7268 | flow=1.77 | particles=3  | vort=0.082 | div=0.066
```

## Sample Metadata File

**File:** `keyframe_000142_0.847.txt`

```
Frame Index: 142
Score: 0.847632
Flow Magnitude: 2.451200
Particle Count: 12
Vorticity Energy: 0.123456
Divergence Energy: 0.099876
Metrics: flow=2.45 | particles=12 | vort=0.123 | div=0.100
```

## CLI Output Examples

### Example 1: Basic Key Frame Capture

```bash
$ python src/main.py --input video.mp4 --capture-keyframes

GPU: Available ✓
Selected device: cuda
Enabling key frame capture (capturing 10 frames)

Processing video: video.mp4
Frame 1/1234...
Frame 100/1234...
Frame 500/1234...
Frame 1000/1234...
Frame 1234/1234... Done!

Top 10 Key Frames:
────────────────────────────────────────────────────────────────────────────
 1. Frame 000142 | Score: 0.8476 | flow=2.45 | particles=12 | vort=0.123 | div=0.099
 2. Frame 000139 | Score: 0.8342 | flow=2.38 | particles=10 | vort=0.118 | div=0.094
 [... 8 more frames ...]
Saved key frames report to: video_keyframes_report.txt
Extracted 10 key frames to: video_keyframes/
```

### Example 2: Export with Key Frame Grid

```bash
$ python src/main.py --input data.mp4 --output output.mp4 --mode export --capture-keyframes --keyframes-grid

GPU: Available ✓
Selected device: cuda
Enabling key frame capture (capturing 10 frames)

Pass 1/2 (compute flow, tracks)
Frame 1/5000... (Scoring frames)
Frame 500/5000...
Frame 1000/5000...
[... progress ...]

Pass 2/2 (render + extract)
Frame 1/5000... (Drawing overlays, scoring frames)
Frame 500/5000...
[... progress ...]

Saved key frames report to: data_keyframes_report.txt
Extracted 10 key frame images
Creating key frames composite grid...
Saved key frames grid to: data_keyframes_grid.jpg

Export complete!
Saved to: output.mp4
```

### Example 3: Custom Count and Directory

```bash
$ python src/main.py --input video.mp4 --capture-keyframes --keyframes-count 20 --keyframes-dir ./analysis/frames

GPU: Available ✓
Enabling key frame capture (capturing 20 frames)

Processing...
Extracting key frames to: ./analysis/frames
Saved 20 key frame images

Top 20 Key Frames:
────────────────────────────────────────────────────────────────────────────
 1. Frame 000142 | Score: 0.8476 | ...
 2. Frame 000139 | Score: 0.8342 | ...
 [... 18 more ...]
```

## Output File Structure

After running with key frame capture, the directory structure is:

```
my_video.mp4                       # Original video
my_video_output.mp4                # Exported video (optional)

my_video_keyframes/                # Key frames directory
├── keyframe_000142_0.847.jpg      # Frame image
├── keyframe_000142_0.847.txt      # Metadata
├── keyframe_000139_0.834.jpg
├── keyframe_000139_0.834.txt
├── keyframe_000145_0.820.jpg
├── keyframe_000145_0.820.txt
├── keyframe_000151_0.807.jpg
├── keyframe_000151_0.807.txt
├── keyframe_000148_0.793.jpg
├── keyframe_000148_0.793.txt
├── keyframe_000154_0.780.jpg
├── keyframe_000154_0.780.txt
├── keyframe_000135_0.767.jpg
├── keyframe_000135_0.767.txt
├── keyframe_000157_0.753.jpg
├── keyframe_000157_0.753.txt
├── keyframe_000160_0.740.jpg
├── keyframe_000160_0.740.txt
├── keyframe_000132_0.727.jpg
└── keyframe_000132_0.727.txt

my_video_keyframes_grid.jpg        # Composite grid (2×5, 1280×512)
my_video_keyframes_report.txt      # Ranking report
```

## Scoring Algorithm Example

**Frame 142 Calculation:**

```
Input: flow_uv, particles=12, vorticity field, divergence field

Step 1: Compute component scores
  flow_magnitude = mean(√(u² + v²)) = 2.45
  flow_std = std(√(u² + v²)) = 0.8
  flow_score = min(1.0, (2.45 + 0.5*0.8) / 100) = min(1.0, 0.029) = 0.029

  particle_score = min(1.0, 12 / 100) = 0.120

  vorticity_score = min(1.0, mean(|∂v/∂x - ∂u/∂y|)) = 0.123

  divergence_score = min(1.0, mean(|∂u/∂x + ∂v/∂y|)) = 0.100

Step 2: Weighted sum (equal 0.25 each)
  score = 0.25 × 0.029 + 0.25 × 0.120 + 0.25 × 0.123 + 0.25 × 0.100
        = 0.007 + 0.030 + 0.031 + 0.025
        = 0.093

Step 3: Multi-signal bonus (3+ high-value metrics)
  flow_magnitude (2.45) > 1.0 ✓
  particle_count (12) > 5 ✓
  vorticity_energy (0.123) > 0.1 ✓
  divergence_energy (0.100) = 0.1 ✓

  4 high metrics detected → apply 1.2× bonus
  score = 0.093 × 1.2 = 0.112

Step 4: Final score
  score ≈ 0.847 (after normalization across all frames)
```

## Visual Example: Composite Grid

The `_keyframes_grid.jpg` output is a 2×5 grid:

```
┌─────────┬─────────┬─────────┬─────────┬─────────┐
│ Frame   │ Frame   │ Frame   │ Frame   │ Frame   │ 256×256 each
│  142    │  139    │  145    │  151    │  148    │ tile
│  0.847  │  0.834  │  0.820  │  0.807  │  0.793  │
└─────────┴─────────┴─────────┴─────────┴─────────┘
┌─────────┬─────────┬─────────┬─────────┬─────────┐
│ Frame   │ Frame   │ Frame   │ Frame   │ Frame   │
│  154    │  135    │  157    │  160    │  132    │
│  0.780  │  0.767  │  0.753  │  0.740  │  0.727  │
└─────────┴─────────┴─────────┴─────────┴─────────┘

Total size: 1280 × 512 pixels
Format: JPG (high quality)
```

## GUI Example Output

**After clicking Export with "Enable Key Frame Capture":**

```
Status bar updates:
1. "Exporting and capturing 10 key frames..."
2. "Pass 1/2: Computing flow..."
3. "Pass 2/2: Drawing overlays and scoring frames..."
4. "Extracting key frames..."
5. "Creating key frames composite grid..."
6. "Export complete!"

Then displays:
- Extracted 10 key frame images
- Report printed to console:

  Top 10 Key Frames:
  ────────────────────────────────────────────────────────
   1. Frame 000142 | Score: 0.8476 | ...
   ...
```

## Performance Metrics Example

**Processing 30-minute video (54,000 frames) at 1080p:**

```
CPU Time:
  Video reading:      45 min
  Flow computation:   50 min
  Overlay rendering:  20 min
  Key frame scoring:  30 sec (negligible)
  Key frame extraction: 5 min
  ────────────────────────────
  Total:              ~2 hours

GPU Time (with CUDA):
  Flow computation:   10 min (5× faster)
  ────────────────────────────
  Total:              ~1.5 hours (25% faster)

Key frame scoring overhead: 
  Scoring:   30 sec / 2 hours = 0.25%
  Extraction: 5 min / 2 hours = 4%
  Total:     ~4% additional time
```

## Error Handling Example

**Missing directory (auto-created):**
```
No output directory at "video_keyframes/"
Creating directory...
Saved 10 key frame images to: video_keyframes/
```

**Out of disk space:**
```
Warning: failed to extract key frames: No space left on device
Completed export, but could not save key frames
Check available disk space (need ~10 MB)
```

**No motion detected:**
```
Warning: all frames have zero score
Key frame extraction skipped
Consider enabling particle tracker or checking video content
```

---

These examples demonstrate how the key frame capture feature integrates seamlessly with both GUI and CLI workflows.
